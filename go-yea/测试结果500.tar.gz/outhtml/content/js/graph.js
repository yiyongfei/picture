/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 0 : 0;
        var yOffset = options.yaxis.mode === "time" ? 0 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 26.0, "minX": 0.0, "maxY": 1196.0, "series": [{"data": [[0.0, 26.0], [0.1, 32.0], [0.2, 37.0], [0.3, 41.0], [0.4, 44.0], [0.5, 47.0], [0.6, 50.0], [0.7, 52.0], [0.8, 52.0], [0.9, 52.0], [1.0, 52.0], [1.1, 52.0], [1.2, 53.0], [1.3, 53.0], [1.4, 53.0], [1.5, 53.0], [1.6, 53.0], [1.7, 53.0], [1.8, 54.0], [1.9, 54.0], [2.0, 54.0], [2.1, 54.0], [2.2, 54.0], [2.3, 55.0], [2.4, 55.0], [2.5, 55.0], [2.6, 55.0], [2.7, 56.0], [2.8, 56.0], [2.9, 56.0], [3.0, 56.0], [3.1, 57.0], [3.2, 57.0], [3.3, 57.0], [3.4, 58.0], [3.5, 58.0], [3.6, 58.0], [3.7, 58.0], [3.8, 59.0], [3.9, 59.0], [4.0, 59.0], [4.1, 60.0], [4.2, 60.0], [4.3, 60.0], [4.4, 60.0], [4.5, 61.0], [4.6, 61.0], [4.7, 61.0], [4.8, 61.0], [4.9, 62.0], [5.0, 62.0], [5.1, 62.0], [5.2, 63.0], [5.3, 63.0], [5.4, 63.0], [5.5, 63.0], [5.6, 64.0], [5.7, 64.0], [5.8, 64.0], [5.9, 65.0], [6.0, 65.0], [6.1, 65.0], [6.2, 65.0], [6.3, 66.0], [6.4, 66.0], [6.5, 66.0], [6.6, 66.0], [6.7, 67.0], [6.8, 67.0], [6.9, 67.0], [7.0, 67.0], [7.1, 68.0], [7.2, 68.0], [7.3, 68.0], [7.4, 69.0], [7.5, 69.0], [7.6, 69.0], [7.7, 69.0], [7.8, 70.0], [7.9, 70.0], [8.0, 70.0], [8.1, 71.0], [8.2, 71.0], [8.3, 71.0], [8.4, 71.0], [8.5, 72.0], [8.6, 72.0], [8.7, 72.0], [8.8, 73.0], [8.9, 73.0], [9.0, 73.0], [9.1, 73.0], [9.2, 74.0], [9.3, 74.0], [9.4, 74.0], [9.5, 75.0], [9.6, 75.0], [9.7, 75.0], [9.8, 76.0], [9.9, 76.0], [10.0, 76.0], [10.1, 76.0], [10.2, 77.0], [10.3, 77.0], [10.4, 77.0], [10.5, 77.0], [10.6, 78.0], [10.7, 78.0], [10.8, 78.0], [10.9, 78.0], [11.0, 79.0], [11.1, 79.0], [11.2, 79.0], [11.3, 79.0], [11.4, 79.0], [11.5, 80.0], [11.6, 80.0], [11.7, 80.0], [11.8, 80.0], [11.9, 80.0], [12.0, 81.0], [12.1, 81.0], [12.2, 81.0], [12.3, 81.0], [12.4, 82.0], [12.5, 82.0], [12.6, 82.0], [12.7, 82.0], [12.8, 82.0], [12.9, 83.0], [13.0, 83.0], [13.1, 83.0], [13.2, 83.0], [13.3, 84.0], [13.4, 84.0], [13.5, 84.0], [13.6, 84.0], [13.7, 84.0], [13.8, 85.0], [13.9, 85.0], [14.0, 85.0], [14.1, 85.0], [14.2, 86.0], [14.3, 86.0], [14.4, 86.0], [14.5, 86.0], [14.6, 86.0], [14.7, 87.0], [14.8, 87.0], [14.9, 87.0], [15.0, 87.0], [15.1, 87.0], [15.2, 88.0], [15.3, 88.0], [15.4, 88.0], [15.5, 88.0], [15.6, 89.0], [15.7, 89.0], [15.8, 89.0], [15.9, 89.0], [16.0, 89.0], [16.1, 90.0], [16.2, 90.0], [16.3, 90.0], [16.4, 90.0], [16.5, 91.0], [16.6, 91.0], [16.7, 91.0], [16.8, 91.0], [16.9, 92.0], [17.0, 92.0], [17.1, 92.0], [17.2, 92.0], [17.3, 92.0], [17.4, 93.0], [17.5, 93.0], [17.6, 93.0], [17.7, 93.0], [17.8, 94.0], [17.9, 94.0], [18.0, 94.0], [18.1, 94.0], [18.2, 94.0], [18.3, 95.0], [18.4, 95.0], [18.5, 95.0], [18.6, 95.0], [18.7, 96.0], [18.8, 96.0], [18.9, 96.0], [19.0, 96.0], [19.1, 97.0], [19.2, 97.0], [19.3, 97.0], [19.4, 97.0], [19.5, 98.0], [19.6, 98.0], [19.7, 98.0], [19.8, 98.0], [19.9, 99.0], [20.0, 99.0], [20.1, 99.0], [20.2, 99.0], [20.3, 99.0], [20.4, 100.0], [20.5, 100.0], [20.6, 100.0], [20.7, 100.0], [20.8, 101.0], [20.9, 101.0], [21.0, 101.0], [21.1, 101.0], [21.2, 102.0], [21.3, 102.0], [21.4, 102.0], [21.5, 102.0], [21.6, 103.0], [21.7, 103.0], [21.8, 103.0], [21.9, 103.0], [22.0, 103.0], [22.1, 104.0], [22.2, 104.0], [22.3, 104.0], [22.4, 104.0], [22.5, 105.0], [22.6, 105.0], [22.7, 105.0], [22.8, 105.0], [22.9, 105.0], [23.0, 106.0], [23.1, 106.0], [23.2, 106.0], [23.3, 106.0], [23.4, 106.0], [23.5, 107.0], [23.6, 107.0], [23.7, 107.0], [23.8, 107.0], [23.9, 107.0], [24.0, 108.0], [24.1, 108.0], [24.2, 108.0], [24.3, 108.0], [24.4, 108.0], [24.5, 109.0], [24.6, 109.0], [24.7, 109.0], [24.8, 109.0], [24.9, 109.0], [25.0, 110.0], [25.1, 110.0], [25.2, 110.0], [25.3, 110.0], [25.4, 111.0], [25.5, 111.0], [25.6, 111.0], [25.7, 111.0], [25.8, 111.0], [25.9, 112.0], [26.0, 112.0], [26.1, 112.0], [26.2, 112.0], [26.3, 112.0], [26.4, 113.0], [26.5, 113.0], [26.6, 113.0], [26.7, 113.0], [26.8, 114.0], [26.9, 114.0], [27.0, 114.0], [27.1, 114.0], [27.2, 114.0], [27.3, 115.0], [27.4, 115.0], [27.5, 115.0], [27.6, 115.0], [27.7, 115.0], [27.8, 116.0], [27.9, 116.0], [28.0, 116.0], [28.1, 116.0], [28.2, 117.0], [28.3, 117.0], [28.4, 117.0], [28.5, 117.0], [28.6, 117.0], [28.7, 118.0], [28.8, 118.0], [28.9, 118.0], [29.0, 118.0], [29.1, 119.0], [29.2, 119.0], [29.3, 119.0], [29.4, 119.0], [29.5, 119.0], [29.6, 120.0], [29.7, 120.0], [29.8, 120.0], [29.9, 120.0], [30.0, 121.0], [30.1, 121.0], [30.2, 121.0], [30.3, 121.0], [30.4, 122.0], [30.5, 122.0], [30.6, 122.0], [30.7, 122.0], [30.8, 123.0], [30.9, 123.0], [31.0, 123.0], [31.1, 123.0], [31.2, 124.0], [31.3, 124.0], [31.4, 124.0], [31.5, 124.0], [31.6, 124.0], [31.7, 125.0], [31.8, 125.0], [31.9, 125.0], [32.0, 125.0], [32.1, 126.0], [32.2, 126.0], [32.3, 126.0], [32.4, 126.0], [32.5, 127.0], [32.6, 127.0], [32.7, 127.0], [32.8, 128.0], [32.9, 128.0], [33.0, 128.0], [33.1, 128.0], [33.2, 128.0], [33.3, 129.0], [33.4, 129.0], [33.5, 129.0], [33.6, 129.0], [33.7, 130.0], [33.8, 130.0], [33.9, 130.0], [34.0, 130.0], [34.1, 131.0], [34.2, 131.0], [34.3, 131.0], [34.4, 131.0], [34.5, 131.0], [34.6, 132.0], [34.7, 132.0], [34.8, 132.0], [34.9, 132.0], [35.0, 133.0], [35.1, 133.0], [35.2, 133.0], [35.3, 133.0], [35.4, 134.0], [35.5, 134.0], [35.6, 134.0], [35.7, 134.0], [35.8, 134.0], [35.9, 135.0], [36.0, 135.0], [36.1, 135.0], [36.2, 135.0], [36.3, 136.0], [36.4, 136.0], [36.5, 136.0], [36.6, 136.0], [36.7, 137.0], [36.8, 137.0], [36.9, 137.0], [37.0, 137.0], [37.1, 138.0], [37.2, 138.0], [37.3, 138.0], [37.4, 138.0], [37.5, 138.0], [37.6, 139.0], [37.7, 139.0], [37.8, 139.0], [37.9, 139.0], [38.0, 140.0], [38.1, 140.0], [38.2, 140.0], [38.3, 140.0], [38.4, 141.0], [38.5, 141.0], [38.6, 141.0], [38.7, 141.0], [38.8, 142.0], [38.9, 142.0], [39.0, 142.0], [39.1, 142.0], [39.2, 142.0], [39.3, 143.0], [39.4, 143.0], [39.5, 143.0], [39.6, 143.0], [39.7, 144.0], [39.8, 144.0], [39.9, 144.0], [40.0, 144.0], [40.1, 145.0], [40.2, 145.0], [40.3, 145.0], [40.4, 145.0], [40.5, 146.0], [40.6, 146.0], [40.7, 146.0], [40.8, 146.0], [40.9, 147.0], [41.0, 147.0], [41.1, 147.0], [41.2, 147.0], [41.3, 148.0], [41.4, 148.0], [41.5, 148.0], [41.6, 148.0], [41.7, 149.0], [41.8, 149.0], [41.9, 149.0], [42.0, 149.0], [42.1, 150.0], [42.2, 150.0], [42.3, 150.0], [42.4, 150.0], [42.5, 151.0], [42.6, 151.0], [42.7, 151.0], [42.8, 151.0], [42.9, 152.0], [43.0, 152.0], [43.1, 152.0], [43.2, 152.0], [43.3, 153.0], [43.4, 153.0], [43.5, 153.0], [43.6, 154.0], [43.7, 154.0], [43.8, 154.0], [43.9, 154.0], [44.0, 155.0], [44.1, 155.0], [44.2, 155.0], [44.3, 155.0], [44.4, 156.0], [44.5, 156.0], [44.6, 156.0], [44.7, 156.0], [44.8, 157.0], [44.9, 157.0], [45.0, 157.0], [45.1, 157.0], [45.2, 158.0], [45.3, 158.0], [45.4, 158.0], [45.5, 158.0], [45.6, 159.0], [45.7, 159.0], [45.8, 159.0], [45.9, 159.0], [46.0, 160.0], [46.1, 160.0], [46.2, 160.0], [46.3, 160.0], [46.4, 161.0], [46.5, 161.0], [46.6, 161.0], [46.7, 161.0], [46.8, 162.0], [46.9, 162.0], [47.0, 162.0], [47.1, 162.0], [47.2, 163.0], [47.3, 163.0], [47.4, 163.0], [47.5, 164.0], [47.6, 164.0], [47.7, 164.0], [47.8, 164.0], [47.9, 165.0], [48.0, 165.0], [48.1, 165.0], [48.2, 165.0], [48.3, 166.0], [48.4, 166.0], [48.5, 166.0], [48.6, 166.0], [48.7, 167.0], [48.8, 167.0], [48.9, 167.0], [49.0, 167.0], [49.1, 168.0], [49.2, 168.0], [49.3, 168.0], [49.4, 169.0], [49.5, 169.0], [49.6, 169.0], [49.7, 169.0], [49.8, 170.0], [49.9, 170.0], [50.0, 170.0], [50.1, 170.0], [50.2, 171.0], [50.3, 171.0], [50.4, 171.0], [50.5, 171.0], [50.6, 172.0], [50.7, 172.0], [50.8, 172.0], [50.9, 173.0], [51.0, 173.0], [51.1, 173.0], [51.2, 173.0], [51.3, 174.0], [51.4, 174.0], [51.5, 174.0], [51.6, 175.0], [51.7, 175.0], [51.8, 175.0], [51.9, 175.0], [52.0, 176.0], [52.1, 176.0], [52.2, 176.0], [52.3, 177.0], [52.4, 177.0], [52.5, 177.0], [52.6, 177.0], [52.7, 178.0], [52.8, 178.0], [52.9, 178.0], [53.0, 179.0], [53.1, 179.0], [53.2, 179.0], [53.3, 179.0], [53.4, 180.0], [53.5, 180.0], [53.6, 180.0], [53.7, 181.0], [53.8, 181.0], [53.9, 181.0], [54.0, 181.0], [54.1, 182.0], [54.2, 182.0], [54.3, 182.0], [54.4, 183.0], [54.5, 183.0], [54.6, 183.0], [54.7, 183.0], [54.8, 184.0], [54.9, 184.0], [55.0, 184.0], [55.1, 185.0], [55.2, 185.0], [55.3, 185.0], [55.4, 185.0], [55.5, 186.0], [55.6, 186.0], [55.7, 186.0], [55.8, 187.0], [55.9, 187.0], [56.0, 187.0], [56.1, 188.0], [56.2, 188.0], [56.3, 188.0], [56.4, 188.0], [56.5, 189.0], [56.6, 189.0], [56.7, 189.0], [56.8, 190.0], [56.9, 190.0], [57.0, 190.0], [57.1, 191.0], [57.2, 191.0], [57.3, 191.0], [57.4, 191.0], [57.5, 192.0], [57.6, 192.0], [57.7, 192.0], [57.8, 193.0], [57.9, 193.0], [58.0, 193.0], [58.1, 194.0], [58.2, 194.0], [58.3, 194.0], [58.4, 194.0], [58.5, 195.0], [58.6, 195.0], [58.7, 195.0], [58.8, 196.0], [58.9, 196.0], [59.0, 196.0], [59.1, 197.0], [59.2, 197.0], [59.3, 197.0], [59.4, 198.0], [59.5, 198.0], [59.6, 198.0], [59.7, 199.0], [59.8, 199.0], [59.9, 199.0], [60.0, 199.0], [60.1, 200.0], [60.2, 200.0], [60.3, 200.0], [60.4, 201.0], [60.5, 201.0], [60.6, 202.0], [60.7, 202.0], [60.8, 202.0], [60.9, 203.0], [61.0, 203.0], [61.1, 203.0], [61.2, 204.0], [61.3, 204.0], [61.4, 204.0], [61.5, 205.0], [61.6, 205.0], [61.7, 205.0], [61.8, 206.0], [61.9, 206.0], [62.0, 206.0], [62.1, 207.0], [62.2, 207.0], [62.3, 207.0], [62.4, 208.0], [62.5, 208.0], [62.6, 208.0], [62.7, 209.0], [62.8, 209.0], [62.9, 209.0], [63.0, 210.0], [63.1, 210.0], [63.2, 210.0], [63.3, 211.0], [63.4, 211.0], [63.5, 211.0], [63.6, 212.0], [63.7, 212.0], [63.8, 212.0], [63.9, 213.0], [64.0, 213.0], [64.1, 213.0], [64.2, 214.0], [64.3, 214.0], [64.4, 214.0], [64.5, 215.0], [64.6, 215.0], [64.7, 215.0], [64.8, 216.0], [64.9, 216.0], [65.0, 217.0], [65.1, 217.0], [65.2, 217.0], [65.3, 218.0], [65.4, 218.0], [65.5, 218.0], [65.6, 219.0], [65.7, 219.0], [65.8, 219.0], [65.9, 220.0], [66.0, 220.0], [66.1, 221.0], [66.2, 221.0], [66.3, 221.0], [66.4, 222.0], [66.5, 222.0], [66.6, 222.0], [66.7, 223.0], [66.8, 223.0], [66.9, 224.0], [67.0, 224.0], [67.1, 224.0], [67.2, 225.0], [67.3, 225.0], [67.4, 226.0], [67.5, 226.0], [67.6, 226.0], [67.7, 227.0], [67.8, 227.0], [67.9, 228.0], [68.0, 228.0], [68.1, 228.0], [68.2, 229.0], [68.3, 229.0], [68.4, 230.0], [68.5, 230.0], [68.6, 230.0], [68.7, 231.0], [68.8, 231.0], [68.9, 232.0], [69.0, 232.0], [69.1, 232.0], [69.2, 233.0], [69.3, 233.0], [69.4, 234.0], [69.5, 234.0], [69.6, 234.0], [69.7, 235.0], [69.8, 235.0], [69.9, 236.0], [70.0, 236.0], [70.1, 236.0], [70.2, 237.0], [70.3, 237.0], [70.4, 238.0], [70.5, 238.0], [70.6, 238.0], [70.7, 239.0], [70.8, 239.0], [70.9, 240.0], [71.0, 240.0], [71.1, 241.0], [71.2, 241.0], [71.3, 241.0], [71.4, 242.0], [71.5, 242.0], [71.6, 243.0], [71.7, 243.0], [71.8, 244.0], [71.9, 244.0], [72.0, 244.0], [72.1, 245.0], [72.2, 245.0], [72.3, 246.0], [72.4, 246.0], [72.5, 247.0], [72.6, 247.0], [72.7, 248.0], [72.8, 248.0], [72.9, 249.0], [73.0, 249.0], [73.1, 250.0], [73.2, 250.0], [73.3, 251.0], [73.4, 251.0], [73.5, 251.0], [73.6, 252.0], [73.7, 252.0], [73.8, 253.0], [73.9, 253.0], [74.0, 254.0], [74.1, 254.0], [74.2, 255.0], [74.3, 255.0], [74.4, 256.0], [74.5, 256.0], [74.6, 257.0], [74.7, 257.0], [74.8, 258.0], [74.9, 258.0], [75.0, 259.0], [75.1, 259.0], [75.2, 260.0], [75.3, 260.0], [75.4, 261.0], [75.5, 261.0], [75.6, 262.0], [75.7, 262.0], [75.8, 263.0], [75.9, 263.0], [76.0, 264.0], [76.1, 264.0], [76.2, 265.0], [76.3, 265.0], [76.4, 266.0], [76.5, 266.0], [76.6, 267.0], [76.7, 267.0], [76.8, 268.0], [76.9, 268.0], [77.0, 269.0], [77.1, 269.0], [77.2, 270.0], [77.3, 270.0], [77.4, 271.0], [77.5, 272.0], [77.6, 272.0], [77.7, 273.0], [77.8, 273.0], [77.9, 274.0], [78.0, 274.0], [78.1, 275.0], [78.2, 275.0], [78.3, 276.0], [78.4, 277.0], [78.5, 277.0], [78.6, 278.0], [78.7, 278.0], [78.8, 279.0], [78.9, 279.0], [79.0, 280.0], [79.1, 280.0], [79.2, 281.0], [79.3, 282.0], [79.4, 282.0], [79.5, 283.0], [79.6, 283.0], [79.7, 284.0], [79.8, 285.0], [79.9, 285.0], [80.0, 286.0], [80.1, 286.0], [80.2, 287.0], [80.3, 288.0], [80.4, 288.0], [80.5, 289.0], [80.6, 289.0], [80.7, 290.0], [80.8, 291.0], [80.9, 291.0], [81.0, 292.0], [81.1, 293.0], [81.2, 293.0], [81.3, 294.0], [81.4, 295.0], [81.5, 295.0], [81.6, 296.0], [81.7, 296.0], [81.8, 297.0], [81.9, 298.0], [82.0, 298.0], [82.1, 299.0], [82.2, 300.0], [82.3, 300.0], [82.4, 301.0], [82.5, 302.0], [82.6, 302.0], [82.7, 303.0], [82.8, 304.0], [82.9, 304.0], [83.0, 305.0], [83.1, 306.0], [83.2, 306.0], [83.3, 307.0], [83.4, 308.0], [83.5, 308.0], [83.6, 309.0], [83.7, 310.0], [83.8, 310.0], [83.9, 311.0], [84.0, 312.0], [84.1, 313.0], [84.2, 313.0], [84.3, 314.0], [84.4, 315.0], [84.5, 315.0], [84.6, 316.0], [84.7, 317.0], [84.8, 317.0], [84.9, 318.0], [85.0, 319.0], [85.1, 320.0], [85.2, 320.0], [85.3, 321.0], [85.4, 322.0], [85.5, 323.0], [85.6, 323.0], [85.7, 324.0], [85.8, 325.0], [85.9, 326.0], [86.0, 326.0], [86.1, 327.0], [86.2, 328.0], [86.3, 329.0], [86.4, 330.0], [86.5, 331.0], [86.6, 331.0], [86.7, 332.0], [86.8, 333.0], [86.9, 334.0], [87.0, 335.0], [87.1, 336.0], [87.2, 336.0], [87.3, 337.0], [87.4, 338.0], [87.5, 339.0], [87.6, 340.0], [87.7, 341.0], [87.8, 342.0], [87.9, 343.0], [88.0, 344.0], [88.1, 344.0], [88.2, 345.0], [88.3, 346.0], [88.4, 347.0], [88.5, 348.0], [88.6, 349.0], [88.7, 350.0], [88.8, 351.0], [88.9, 352.0], [89.0, 353.0], [89.1, 354.0], [89.2, 355.0], [89.3, 356.0], [89.4, 357.0], [89.5, 358.0], [89.6, 359.0], [89.7, 360.0], [89.8, 361.0], [89.9, 362.0], [90.0, 363.0], [90.1, 364.0], [90.2, 365.0], [90.3, 366.0], [90.4, 367.0], [90.5, 368.0], [90.6, 370.0], [90.7, 371.0], [90.8, 372.0], [90.9, 373.0], [91.0, 374.0], [91.1, 376.0], [91.2, 377.0], [91.3, 378.0], [91.4, 379.0], [91.5, 380.0], [91.6, 382.0], [91.7, 383.0], [91.8, 384.0], [91.9, 386.0], [92.0, 387.0], [92.1, 388.0], [92.2, 390.0], [92.3, 391.0], [92.4, 393.0], [92.5, 394.0], [92.6, 395.0], [92.7, 397.0], [92.8, 398.0], [92.9, 400.0], [93.0, 401.0], [93.1, 403.0], [93.2, 404.0], [93.3, 406.0], [93.4, 408.0], [93.5, 409.0], [93.6, 411.0], [93.7, 413.0], [93.8, 414.0], [93.9, 416.0], [94.0, 418.0], [94.1, 419.0], [94.2, 421.0], [94.3, 423.0], [94.4, 425.0], [94.5, 427.0], [94.6, 429.0], [94.7, 431.0], [94.8, 433.0], [94.9, 435.0], [95.0, 437.0], [95.1, 440.0], [95.2, 442.0], [95.3, 444.0], [95.4, 447.0], [95.5, 449.0], [95.6, 452.0], [95.7, 454.0], [95.8, 457.0], [95.9, 460.0], [96.0, 463.0], [96.1, 465.0], [96.2, 468.0], [96.3, 471.0], [96.4, 474.0], [96.5, 477.0], [96.6, 480.0], [96.7, 484.0], [96.8, 487.0], [96.9, 491.0], [97.0, 494.0], [97.1, 498.0], [97.2, 502.0], [97.3, 506.0], [97.4, 510.0], [97.5, 515.0], [97.6, 520.0], [97.7, 525.0], [97.8, 530.0], [97.9, 535.0], [98.0, 541.0], [98.1, 546.0], [98.2, 553.0], [98.3, 559.0], [98.4, 567.0], [98.5, 575.0], [98.6, 583.0], [98.7, 591.0], [98.8, 600.0], [98.9, 610.0], [99.0, 620.0], [99.1, 632.0], [99.2, 645.0], [99.3, 660.0], [99.4, 677.0], [99.5, 694.0], [99.6, 718.0], [99.7, 753.0], [99.8, 804.0], [99.9, 881.0], [100.0, 1196.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 38.0, "minX": 0.0, "maxY": 485675.0, "series": [{"data": [[0.0, 485675.0], [500.0, 14287.0], [1000.0, 38.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 500, "maxX": 1000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 14196.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 485804.0, "series": [{"data": [[1.0, 14196.0]], "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[0.0, 485804.0]], "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 64.3555932203389, "minX": 1.49380476E12, "maxY": 500.0, "series": [{"data": [[1.49380494E12, 499.9895875867708], [1.49380476E12, 64.3555932203389], [1.49380488E12, 500.0], [1.493805E12, 370.9521625967055], [1.49380482E12, 341.6953846476358]], "isOverall": false, "label": "性能测试", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.493805E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 47.4, "minX": 1.0, "maxY": 352.5909090909091, "series": [{"data": [[2.0, 53.0], [3.0, 48.733333333333334], [4.0, 48.66666666666667], [5.0, 53.25], [6.0, 52.24999999999999], [7.0, 53.0], [8.0, 50.36363636363636], [9.0, 52.764705882352935], [10.0, 50.0], [11.0, 53.0], [12.0, 47.4], [13.0, 53.0], [14.0, 190.46153846153845], [15.0, 61.333333333333336], [16.0, 52.699999999999996], [17.0, 298.40909090909093], [18.0, 352.5909090909091], [19.0, 90.50000000000001], [20.0, 119.25000000000001], [21.0, 114.0], [22.0, 61.0], [23.0, 99.05405405405403], [24.0, 81.75], [25.0, 74.54761904761907], [26.0, 70.42553191489363], [27.0, 84.65116279069768], [28.0, 78.64102564102564], [29.0, 101.30000000000005], [30.0, 65.77777777777776], [31.0, 67.99999999999997], [32.0, 65.92592592592592], [33.0, 148.4090909090909], [34.0, 56.6938775510204], [35.0, 64.70454545454545], [36.0, 138.16666666666669], [37.0, 81.96], [38.0, 85.08333333333329], [39.0, 90.1777777777778], [40.0, 89.74999999999997], [41.0, 74.96874999999999], [42.0, 54.67647058823529], [43.0, 166.97297297297297], [44.0, 104.21678321678321], [45.0, 72.22727272727275], [46.0, 63.33636363636363], [47.0, 59.45918367346938], [48.0, 66.91860465116282], [49.0, 60.386554621848724], [50.0, 63.21379310344827], [51.0, 70.97590361445782], [52.0, 61.66923076923075], [53.0, 58.67469879518071], [54.0, 61.160583941605836], [55.0, 65.07563025210081], [56.0, 63.48920863309353], [57.0, 66.07142857142857], [58.0, 141.59459459459455], [59.0, 77.4431818181818], [60.0, 70.8484848484848], [61.0, 83.97647058823529], [62.0, 75.17241379310349], [63.0, 69.90163934426229], [64.0, 68.8412698412698], [65.0, 61.638888888888886], [66.0, 82.97487437185931], [67.0, 81.85611510791365], [68.0, 66.35294117647058], [69.0, 71.47692307692313], [70.0, 70.09868421052633], [71.0, 68.04605263157892], [72.0, 70.88732394366194], [73.0, 88.85057471264368], [74.0, 82.71515151515153], [75.0, 86.17741935483869], [76.0, 92.91397849462363], [77.0, 79.9508771929825], [78.0, 62.4242424242424], [79.0, 80.90551181102362], [80.0, 72.33333333333336], [81.0, 66.44000000000005], [82.0, 74.43984962406016], [83.0, 80.11864406779662], [84.0, 86.12142857142857], [85.0, 74.48295454545445], [86.0, 71.49668874172185], [87.0, 76.97222222222219], [88.0, 69.93269230769232], [89.0, 74.70207253886011], [90.0, 60.313725490196056], [91.0, 66.61206896551722], [92.0, 86.00719424460432], [93.0, 92.84027777777774], [94.0, 99.90721649484534], [95.0, 83.62162162162161], [96.0, 77.3987341772152], [97.0, 80.67264573991031], [98.0, 75.46948356807509], [99.0, 84.39423076923079], [100.0, 99.75572519083971], [101.0, 85.3020134228188], [102.0, 73.86731391585762], [103.0, 75.7127071823204], [104.0, 70.66876971608836], [105.0, 75.0663716814159], [106.0, 78.29237288135596], [107.0, 81.86713286713287], [108.0, 87.23316062176156], [109.0, 73.42786069651746], [110.0, 79.79615384615384], [111.0, 74.9377990430622], [112.0, 90.65745856353587], [113.0, 74.75601374570446], [114.0, 82.70807453416147], [115.0, 84.39634146341456], [116.0, 80.84108527131784], [117.0, 113.48214285714285], [118.0, 95.47], [119.0, 83.5846994535519], [120.0, 97.6904761904762], [121.0, 113.66666666666664], [122.0, 96.91351351351351], [123.0, 125.51984126984131], [124.0, 84.05263157894734], [125.0, 80.4875], [126.0, 80.04301075268816], [127.0, 79.86854460093892], [128.0, 92.11864406779657], [129.0, 83.84800000000006], [130.0, 83.77130044843054], [131.0, 88.82246376811595], [132.0, 89.38493723849372], [133.0, 86.48543689320387], [134.0, 88.53939393939393], [135.0, 92.17412935323381], [136.0, 98.16417910447767], [137.0, 93.98722044728437], [138.0, 103.61926605504586], [139.0, 109.46551724137932], [140.0, 99.02189781021897], [141.0, 80.96170212765958], [142.0, 85.44468085106384], [143.0, 73.82335329341322], [144.0, 81.27800829875518], [145.0, 75.90836653386457], [146.0, 109.7991071428572], [147.0, 84.98648648648647], [148.0, 80.20403022670027], [149.0, 108.87557603686638], [150.0, 103.18037974683546], [151.0, 78.92776523702028], [152.0, 148.34939759036138], [153.0, 60.46067415730337], [156.0, 188.6079027355623], [157.0, 196.34104046242777], [158.0, 108.22522522522526], [159.0, 91.09318996415767], [155.0, 71.69999999999999], [154.0, 70.66666666666664], [160.0, 109.69811320754721], [161.0, 88.56474820143887], [162.0, 84.99390243902437], [163.0, 86.15343915343914], [164.0, 80.61333333333341], [165.0, 103.02242152466371], [166.0, 75.30708661417317], [167.0, 85.97009966777408], [168.0, 94.59114139693362], [169.0, 105.92307692307699], [170.0, 87.807881773399], [171.0, 108.989898989899], [172.0, 111.61111111111113], [173.0, 101.51363636363635], [174.0, 100.14062499999993], [175.0, 129.84046692607015], [176.0, 133.26470588235298], [177.0, 130.39130434782598], [178.0, 90.14285714285714], [179.0, 99.34068627450982], [180.0, 104.90257879656158], [181.0, 115.44303797468356], [182.0, 113.3661971830986], [183.0, 88.4761904761905], [184.0, 176.3257575757576], [185.0, 104.1047619047619], [186.0, 161.20245398773002], [187.0, 137.86829268292686], [188.0, 147.2549019607842], [189.0, 84.2081109925294], [190.0, 91.25742574257423], [191.0, 198.89017341040454], [192.0, 121.90353697749195], [193.0, 127.45226130653266], [194.0, 128.96994535519136], [195.0, 108.53875968992244], [196.0, 81.46628131021185], [197.0, 106.30645161290325], [198.0, 113.58680555555547], [199.0, 130.6160714285714], [200.0, 185.85365853658533], [201.0, 125.04705882352945], [202.0, 143.66666666666666], [203.0, 108.54810495626829], [204.0, 89.22027290448348], [205.0, 118.22897196261677], [206.0, 137.45959595959604], [207.0, 137.0600858369099], [208.0, 128.12962962962968], [209.0, 121.69973890339432], [210.0, 112.26874999999994], [211.0, 111.34020618556706], [212.0, 97.01590457256466], [213.0, 113.6770334928229], [214.0, 97.39473684210533], [215.0, 124.95121951219511], [216.0, 90.15151515151507], [217.0, 91.06218905472639], [218.0, 105.18442622950819], [219.0, 118.17889908256875], [220.0, 113.41647058823531], [221.0, 105.27127659574471], [222.0, 112.0087209302326], [223.0, 137.40000000000006], [224.0, 126.50403225806458], [225.0, 122.00308641975306], [226.0, 165.79213483146074], [227.0, 150.5779220779219], [228.0, 114.87833827893166], [229.0, 106.22040072859745], [230.0, 114.68437499999997], [231.0, 105.51644736842107], [232.0, 132.4521739130435], [233.0, 116.9036144578313], [234.0, 135.7204724409451], [235.0, 92.7965895249695], [236.0, 162.07792207792204], [237.0, 127.74021352313166], [238.0, 127.74271844660205], [239.0, 165.97685185185185], [240.0, 144.01785714285717], [241.0, 114.81614349775785], [242.0, 129.08413461538433], [243.0, 174.50787401574814], [244.0, 127.3815789473684], [245.0, 149.79146919431273], [246.0, 184.32432432432415], [247.0, 133.67149758454119], [248.0, 137.9589041095891], [249.0, 118.61627906976739], [250.0, 118.45501730103807], [251.0, 142.09279999999993], [252.0, 136.360248447205], [253.0, 110.98194945848378], [254.0, 108.6498740554156], [255.0, 139.6666666666667], [257.0, 156.21481481481487], [256.0, 111.01320132013196], [258.0, 149.44339622641513], [259.0, 119.10576923076921], [260.0, 144.5879120879121], [261.0, 108.65542521994126], [262.0, 107.2844311377246], [263.0, 116.71493902439022], [264.0, 118.18306010928967], [270.0, 176.69890109890108], [271.0, 147.78958785249463], [268.0, 174.80693069306932], [269.0, 145.0773809523809], [265.0, 126.70129870129874], [266.0, 107.10335195530716], [267.0, 169.39622641509422], [273.0, 123.1880424300869], [272.0, 129.09262435677527], [274.0, 107.19470046082944], [275.0, 155.65175718849852], [276.0, 108.29936305732488], [277.0, 170.81786941580742], [278.0, 110.9932432432433], [279.0, 194.88967971530238], [280.0, 103.02373887240353], [286.0, 104.27672955974853], [287.0, 160.95600000000002], [284.0, 101.8269018743108], [285.0, 205.11059907834112], [281.0, 127.93508936970824], [282.0, 131.97902097902107], [283.0, 112.95938104448734], [289.0, 155.75555555555556], [288.0, 211.84079601990047], [290.0, 155.83886255924187], [291.0, 207.78947368421046], [292.0, 209.1288888888889], [293.0, 153.63925729442963], [294.0, 139.58004158004175], [295.0, 188.72508591065306], [296.0, 172.18888888888893], [302.0, 146.55061728395071], [303.0, 142.31372549019616], [300.0, 172.6591337099812], [301.0, 146.61931818181833], [297.0, 173.1024258760107], [298.0, 208.94117647058823], [299.0, 172.4557522123893], [305.0, 193.17127071823205], [304.0, 155.78977272727272], [306.0, 155.55337690631805], [307.0, 161.9346049046321], [308.0, 161.32734153263945], [309.0, 140.84986595174263], [310.0, 160.17391304347828], [311.0, 160.3796068796067], [312.0, 140.90079365079353], [318.0, 131.12349397590367], [319.0, 128.14539007092222], [316.0, 188.22442244224413], [317.0, 185.04075235109724], [313.0, 136.03759398496246], [314.0, 214.4953271028038], [315.0, 171.8181818181819], [321.0, 124.75947281713358], [320.0, 152.24894514767936], [322.0, 148.96806722689075], [323.0, 166.72870662460576], [324.0, 139.07317073170742], [325.0, 134.63088057901112], [326.0, 185.1616871704745], [327.0, 136.08991825613086], [328.0, 122.12448132780095], [334.0, 109.4855195911413], [335.0, 188.85185185185173], [332.0, 165.84664536741204], [333.0, 132.34710743801628], [329.0, 107.95826771653552], [330.0, 118.0971202710335], [331.0, 142.67010309278334], [337.0, 168.49872122762144], [336.0, 177.38117647058817], [338.0, 131.79123711340205], [339.0, 221.7771428571429], [340.0, 209.98473282442743], [341.0, 171.24610591900316], [342.0, 128.062], [343.0, 176.76315789473688], [344.0, 140.02012072434593], [350.0, 152.61154177433218], [351.0, 176.00000000000028], [348.0, 199.07801418439706], [349.0, 155.50000000000017], [345.0, 141.38663171690686], [346.0, 205.16056338028162], [347.0, 159.33858267716545], [353.0, 154.6330083565459], [352.0, 165.7298136645963], [354.0, 159.31283422459904], [355.0, 219.1213389121339], [356.0, 136.1837416481072], [357.0, 141.38666666666674], [358.0, 171.78085991678225], [359.0, 201.50000000000009], [360.0, 161.0384615384614], [366.0, 211.525641025641], [367.0, 283.36024844720504], [364.0, 127.75956284153003], [365.0, 112.2776659959759], [361.0, 208.048275862069], [362.0, 169.24352331606232], [363.0, 151.7130203720107], [369.0, 207.3183023872679], [368.0, 161.92630241423126], [370.0, 163.92380952380952], [371.0, 175.77182539682534], [372.0, 165.77572016460903], [373.0, 172.70934256055347], [374.0, 201.5946745562129], [375.0, 158.78716981132067], [376.0, 215.42929292929293], [382.0, 188.1552587646075], [383.0, 178.3411764705881], [380.0, 149.64545454545456], [381.0, 133.65114273393678], [377.0, 169.05673758865254], [378.0, 198.24137931034483], [379.0, 167.42227979274628], [385.0, 179.56234718826408], [384.0, 161.98170731707302], [386.0, 158.7214225232852], [387.0, 143.49894067796592], [388.0, 167.9719251336899], [389.0, 186.10687022900757], [390.0, 152.90945406125158], [391.0, 188.89739663093408], [392.0, 142.58605664488036], [398.0, 176.7717121588089], [399.0, 204.77720207253873], [396.0, 228.2917271407833], [397.0, 151.630969609262], [393.0, 184.02391304347833], [394.0, 173.2647928994083], [395.0, 133.8832354859752], [401.0, 190.58778625954196], [400.0, 235.2060810810811], [402.0, 171.9641304347825], [403.0, 181.03499079189692], [404.0, 152.45033112582792], [405.0, 131.71943711521553], [406.0, 191.12019524100046], [407.0, 219.74926253687315], [408.0, 224.43092783505165], [414.0, 175.74811083123421], [415.0, 181.83016759776532], [412.0, 212.15447154471536], [413.0, 184.71712355979363], [409.0, 184.69275786393538], [410.0, 234.0229885057472], [411.0, 185.57377049180312], [417.0, 221.97358490566037], [416.0, 179.12396694214868], [418.0, 197.2577319587628], [419.0, 177.5074455899199], [420.0, 188.70311252992832], [421.0, 289.32663316582887], [422.0, 125.02970297029697], [423.0, 224.88939051918734], [424.0, 223.75733855185902], [430.0, 185.59539473684194], [431.0, 182.77923627684945], [428.0, 208.63718820861664], [429.0, 203.65140845070428], [425.0, 258.94177215189876], [426.0, 157.2355743779773], [427.0, 182.76755852842803], [433.0, 221.21663442940047], [432.0, 226.52314814814824], [434.0, 172.6605744125328], [435.0, 198.6430379746836], [436.0, 172.33242134062934], [437.0, 174.05006765899873], [438.0, 216.63696060037512], [439.0, 269.2764705882352], [440.0, 263.67818574514035], [446.0, 179.4285714285715], [447.0, 241.61002444987795], [444.0, 139.35663082437267], [445.0, 144.95431472081208], [441.0, 169.46747967479666], [442.0, 153.60444078947376], [443.0, 239.2838283828385], [449.0, 134.38146964856216], [448.0, 291.8701298701297], [450.0, 173.41632231404947], [451.0, 183.2103758169935], [452.0, 221.37920489296636], [453.0, 198.2512396694216], [454.0, 179.49128919860647], [455.0, 160.20797227036405], [456.0, 155.67327887981335], [462.0, 181.01871657754015], [463.0, 212.47117794486218], [460.0, 187.2245922208281], [461.0, 235.7302052785922], [457.0, 223.68271334792104], [458.0, 153.20870337477794], [459.0, 222.66187050359719], [465.0, 190.67706821480428], [464.0, 184.93852459016392], [466.0, 239.86776859504135], [467.0, 226.32089552238813], [468.0, 181.5779625779627], [469.0, 233.68421052631584], [470.0, 207.11183144246354], [471.0, 305.86885245901675], [472.0, 329.10126582278525], [478.0, 283.3405017921148], [479.0, 204.38655462184875], [476.0, 183.97933070866137], [477.0, 217.2075812274369], [473.0, 233.24109867751798], [474.0, 183.7388211382115], [475.0, 216.50294695481344], [481.0, 224.0428954423595], [480.0, 177.7810712428496], [482.0, 178.22222222222214], [483.0, 187.001246882793], [484.0, 263.59782608695645], [485.0, 205.48057259713707], [486.0, 246.7351916376305], [487.0, 203.84218570882737], [488.0, 205.3932926829266], [494.0, 201.5547645125957], [495.0, 206.1821705426356], [492.0, 218.87443946188336], [493.0, 193.65512820512842], [489.0, 224.31516183986378], [490.0, 273.7168949771688], [491.0, 182.00602409638554], [496.0, 206.06233421750636], [497.0, 221.9593435285342], [498.0, 219.05436390532563], [499.0, 221.70831973898896], [500.0, 234.243162073076], [1.0, 55.714285714285715]], "isOverall": false, "label": "HTTP请求", "isController": false}, {"data": [[428.85462199999995, 200.25778599999663]], "isOverall": false, "label": "HTTP请求-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 500.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 21928.333333333332, "minX": 1.49380476E12, "maxY": 1555359.9, "series": [{"data": [[1.49380494E12, 1555359.9], [1.49380476E12, 64605.0], [1.49380488E12, 1291662.0], [1.493805E12, 1518754.05], [1.49380482E12, 1044619.05]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.49380494E12, 527922.7666666667], [1.49380476E12, 21928.333333333332], [1.49380488E12, 438418.0], [1.493805E12, 515497.95], [1.49380482E12, 354566.2833333333]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.493805E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 87.5374576271186, "minX": 1.49380476E12, "maxY": 254.4153696168155, "series": [{"data": [[1.49380494E12, 211.1057996930496], [1.49380476E12, 87.5374576271186], [1.49380488E12, 254.4153696168155], [1.493805E12, 143.58891556535943], [1.49380482E12, 206.50170337215093]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.493805E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 87.52627118644065, "minX": 1.49380476E12, "maxY": 254.41152085452725, "series": [{"data": [[1.49380494E12, 211.10211768350146], [1.49380476E12, 87.52627118644065], [1.49380488E12, 254.41152085452725], [1.493805E12, 143.58557740142322], [1.49380482E12, 206.4780553255278]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.493805E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.21330362872119163, "minX": 1.49380476E12, "maxY": 0.4374576271186439, "series": [{"data": [[1.49380494E12, 0.2991368750088057], [1.49380476E12, 0.4374576271186439], [1.49380488E12, 0.32488131570023526], [1.493805E12, 0.21330362872119163], [1.49380482E12, 0.2760615939370407]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.493805E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 26.0, "minX": 1.49380476E12, "maxY": 1196.0, "series": [{"data": [[1.49380494E12, 848.0], [1.49380476E12, 1196.0], [1.49380488E12, 1107.0], [1.493805E12, 1196.0], [1.49380482E12, 1087.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.49380494E12, 26.0], [1.49380476E12, 30.0], [1.49380488E12, 27.0], [1.493805E12, 26.0], [1.49380482E12, 27.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.49380494E12, 323.0], [1.49380476E12, 122.0], [1.49380488E12, 442.0], [1.493805E12, 127.0], [1.49380482E12, 495.90000000000146]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.49380494E12, 461.0], [1.49380476E12, 310.97999999999956], [1.49380488E12, 668.0], [1.493805E12, 193.0], [1.49380482E12, 842.9800000000032]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.49380494E12, 366.0], [1.49380476E12, 157.94999999999982], [1.49380488E12, 532.0], [1.493805E12, 147.0], [1.49380482E12, 595.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.493805E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 71.0, "minX": 5900.0, "maxY": 263.0, "series": [{"data": [[35399.0, 263.0], [18699.0, 71.0], [22042.0, 182.0], [5900.0, 76.0], [57960.0, 221.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 57960.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 70.5, "minX": 5900.0, "maxY": 263.0, "series": [{"data": [[35399.0, 263.0], [18699.0, 70.5], [22042.0, 182.0], [5900.0, 76.0], [57960.0, 221.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 57960.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 99.86666666666666, "minX": 1.49380476E12, "maxY": 2367.3333333333335, "series": [{"data": [[1.49380494E12, 2367.3333333333335], [1.49380476E12, 99.86666666666666], [1.49380488E12, 1966.0], [1.493805E12, 2303.35], [1.49380482E12, 1596.7833333333333]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.493805E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 98.33333333333333, "minX": 1.49380476E12, "maxY": 2367.366666666667, "series": [{"data": [[1.49380494E12, 2367.366666666667], [1.49380476E12, 98.33333333333333], [1.49380488E12, 1966.0], [1.493805E12, 2311.65], [1.49380482E12, 1589.9833333333333]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.493805E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 98.33333333333333, "minX": 1.49380476E12, "maxY": 2367.366666666667, "series": [{"data": [[1.49380494E12, 2367.366666666667], [1.49380476E12, 98.33333333333333], [1.49380488E12, 1966.0], [1.493805E12, 2311.65], [1.49380482E12, 1589.9833333333333]], "isOverall": false, "label": "HTTP请求-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.493805E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
