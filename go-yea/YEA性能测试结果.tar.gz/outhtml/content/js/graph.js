/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 0 : 0;
        var yOffset = options.yaxis.mode === "time" ? 0 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 27.0, "minX": 0.0, "maxY": 10056.0, "series": [{"data": [[0.0, 27.0], [0.1, 51.0], [0.2, 52.0], [0.3, 52.0], [0.4, 52.0], [0.5, 52.0], [0.6, 52.0], [0.7, 52.0], [0.8, 52.0], [0.9, 52.0], [1.0, 53.0], [1.1, 53.0], [1.2, 53.0], [1.3, 53.0], [1.4, 53.0], [1.5, 53.0], [1.6, 53.0], [1.7, 53.0], [1.8, 53.0], [1.9, 53.0], [2.0, 53.0], [2.1, 53.0], [2.2, 53.0], [2.3, 53.0], [2.4, 53.0], [2.5, 54.0], [2.6, 54.0], [2.7, 54.0], [2.8, 54.0], [2.9, 54.0], [3.0, 54.0], [3.1, 54.0], [3.2, 54.0], [3.3, 54.0], [3.4, 54.0], [3.5, 54.0], [3.6, 54.0], [3.7, 55.0], [3.8, 55.0], [3.9, 55.0], [4.0, 55.0], [4.1, 55.0], [4.2, 55.0], [4.3, 55.0], [4.4, 55.0], [4.5, 55.0], [4.6, 55.0], [4.7, 56.0], [4.8, 56.0], [4.9, 56.0], [5.0, 56.0], [5.1, 56.0], [5.2, 56.0], [5.3, 56.0], [5.4, 56.0], [5.5, 56.0], [5.6, 57.0], [5.7, 57.0], [5.8, 57.0], [5.9, 57.0], [6.0, 57.0], [6.1, 57.0], [6.2, 57.0], [6.3, 57.0], [6.4, 57.0], [6.5, 58.0], [6.6, 58.0], [6.7, 58.0], [6.8, 58.0], [6.9, 58.0], [7.0, 58.0], [7.1, 58.0], [7.2, 58.0], [7.3, 59.0], [7.4, 59.0], [7.5, 59.0], [7.6, 59.0], [7.7, 59.0], [7.8, 59.0], [7.9, 59.0], [8.0, 59.0], [8.1, 60.0], [8.2, 60.0], [8.3, 60.0], [8.4, 60.0], [8.5, 60.0], [8.6, 60.0], [8.7, 60.0], [8.8, 60.0], [8.9, 61.0], [9.0, 61.0], [9.1, 61.0], [9.2, 61.0], [9.3, 61.0], [9.4, 61.0], [9.5, 61.0], [9.6, 61.0], [9.7, 62.0], [9.8, 62.0], [9.9, 62.0], [10.0, 62.0], [10.1, 62.0], [10.2, 62.0], [10.3, 63.0], [10.4, 63.0], [10.5, 63.0], [10.6, 63.0], [10.7, 63.0], [10.8, 63.0], [10.9, 63.0], [11.0, 64.0], [11.1, 64.0], [11.2, 64.0], [11.3, 64.0], [11.4, 64.0], [11.5, 64.0], [11.6, 65.0], [11.7, 65.0], [11.8, 65.0], [11.9, 65.0], [12.0, 65.0], [12.1, 65.0], [12.2, 66.0], [12.3, 66.0], [12.4, 66.0], [12.5, 66.0], [12.6, 66.0], [12.7, 67.0], [12.8, 67.0], [12.9, 67.0], [13.0, 67.0], [13.1, 68.0], [13.2, 68.0], [13.3, 68.0], [13.4, 68.0], [13.5, 68.0], [13.6, 69.0], [13.7, 69.0], [13.8, 69.0], [13.9, 70.0], [14.0, 70.0], [14.1, 70.0], [14.2, 70.0], [14.3, 71.0], [14.4, 71.0], [14.5, 71.0], [14.6, 71.0], [14.7, 72.0], [14.8, 72.0], [14.9, 72.0], [15.0, 72.0], [15.1, 73.0], [15.2, 73.0], [15.3, 73.0], [15.4, 74.0], [15.5, 74.0], [15.6, 74.0], [15.7, 74.0], [15.8, 75.0], [15.9, 75.0], [16.0, 75.0], [16.1, 76.0], [16.2, 76.0], [16.3, 76.0], [16.4, 77.0], [16.5, 77.0], [16.6, 77.0], [16.7, 78.0], [16.8, 78.0], [16.9, 78.0], [17.0, 78.0], [17.1, 79.0], [17.2, 79.0], [17.3, 79.0], [17.4, 79.0], [17.5, 80.0], [17.6, 80.0], [17.7, 80.0], [17.8, 80.0], [17.9, 80.0], [18.0, 81.0], [18.1, 81.0], [18.2, 81.0], [18.3, 81.0], [18.4, 81.0], [18.5, 82.0], [18.6, 82.0], [18.7, 82.0], [18.8, 82.0], [18.9, 82.0], [19.0, 83.0], [19.1, 83.0], [19.2, 83.0], [19.3, 83.0], [19.4, 83.0], [19.5, 83.0], [19.6, 84.0], [19.7, 84.0], [19.8, 84.0], [19.9, 84.0], [20.0, 84.0], [20.1, 85.0], [20.2, 85.0], [20.3, 85.0], [20.4, 85.0], [20.5, 85.0], [20.6, 85.0], [20.7, 86.0], [20.8, 86.0], [20.9, 86.0], [21.0, 86.0], [21.1, 86.0], [21.2, 86.0], [21.3, 87.0], [21.4, 87.0], [21.5, 87.0], [21.6, 87.0], [21.7, 87.0], [21.8, 87.0], [21.9, 88.0], [22.0, 88.0], [22.1, 88.0], [22.2, 88.0], [22.3, 88.0], [22.4, 88.0], [22.5, 89.0], [22.6, 89.0], [22.7, 89.0], [22.8, 89.0], [22.9, 89.0], [23.0, 89.0], [23.1, 90.0], [23.2, 90.0], [23.3, 90.0], [23.4, 90.0], [23.5, 90.0], [23.6, 90.0], [23.7, 91.0], [23.8, 91.0], [23.9, 91.0], [24.0, 91.0], [24.1, 91.0], [24.2, 91.0], [24.3, 92.0], [24.4, 92.0], [24.5, 92.0], [24.6, 92.0], [24.7, 92.0], [24.8, 93.0], [24.9, 93.0], [25.0, 93.0], [25.1, 93.0], [25.2, 93.0], [25.3, 93.0], [25.4, 94.0], [25.5, 94.0], [25.6, 94.0], [25.7, 94.0], [25.8, 94.0], [25.9, 94.0], [26.0, 95.0], [26.1, 95.0], [26.2, 95.0], [26.3, 95.0], [26.4, 95.0], [26.5, 95.0], [26.6, 96.0], [26.7, 96.0], [26.8, 96.0], [26.9, 96.0], [27.0, 96.0], [27.1, 96.0], [27.2, 97.0], [27.3, 97.0], [27.4, 97.0], [27.5, 97.0], [27.6, 97.0], [27.7, 97.0], [27.8, 98.0], [27.9, 98.0], [28.0, 98.0], [28.1, 98.0], [28.2, 98.0], [28.3, 99.0], [28.4, 99.0], [28.5, 99.0], [28.6, 99.0], [28.7, 99.0], [28.8, 99.0], [28.9, 100.0], [29.0, 100.0], [29.1, 100.0], [29.2, 100.0], [29.3, 100.0], [29.4, 100.0], [29.5, 101.0], [29.6, 101.0], [29.7, 101.0], [29.8, 101.0], [29.9, 101.0], [30.0, 102.0], [30.1, 102.0], [30.2, 102.0], [30.3, 102.0], [30.4, 102.0], [30.5, 102.0], [30.6, 103.0], [30.7, 103.0], [30.8, 103.0], [30.9, 103.0], [31.0, 103.0], [31.1, 104.0], [31.2, 104.0], [31.3, 104.0], [31.4, 104.0], [31.5, 104.0], [31.6, 104.0], [31.7, 105.0], [31.8, 105.0], [31.9, 105.0], [32.0, 105.0], [32.1, 105.0], [32.2, 105.0], [32.3, 106.0], [32.4, 106.0], [32.5, 106.0], [32.6, 106.0], [32.7, 106.0], [32.8, 106.0], [32.9, 107.0], [33.0, 107.0], [33.1, 107.0], [33.2, 107.0], [33.3, 107.0], [33.4, 107.0], [33.5, 107.0], [33.6, 108.0], [33.7, 108.0], [33.8, 108.0], [33.9, 108.0], [34.0, 108.0], [34.1, 108.0], [34.2, 109.0], [34.3, 109.0], [34.4, 109.0], [34.5, 109.0], [34.6, 109.0], [34.7, 109.0], [34.8, 110.0], [34.9, 110.0], [35.0, 110.0], [35.1, 110.0], [35.2, 110.0], [35.3, 110.0], [35.4, 111.0], [35.5, 111.0], [35.6, 111.0], [35.7, 111.0], [35.8, 111.0], [35.9, 111.0], [36.0, 112.0], [36.1, 112.0], [36.2, 112.0], [36.3, 112.0], [36.4, 112.0], [36.5, 112.0], [36.6, 112.0], [36.7, 113.0], [36.8, 113.0], [36.9, 113.0], [37.0, 113.0], [37.1, 113.0], [37.2, 113.0], [37.3, 113.0], [37.4, 114.0], [37.5, 114.0], [37.6, 114.0], [37.7, 114.0], [37.8, 114.0], [37.9, 114.0], [38.0, 115.0], [38.1, 115.0], [38.2, 115.0], [38.3, 115.0], [38.4, 115.0], [38.5, 115.0], [38.6, 115.0], [38.7, 116.0], [38.8, 116.0], [38.9, 116.0], [39.0, 116.0], [39.1, 116.0], [39.2, 116.0], [39.3, 117.0], [39.4, 117.0], [39.5, 117.0], [39.6, 117.0], [39.7, 117.0], [39.8, 117.0], [39.9, 117.0], [40.0, 118.0], [40.1, 118.0], [40.2, 118.0], [40.3, 118.0], [40.4, 118.0], [40.5, 118.0], [40.6, 119.0], [40.7, 119.0], [40.8, 119.0], [40.9, 119.0], [41.0, 119.0], [41.1, 119.0], [41.2, 119.0], [41.3, 120.0], [41.4, 120.0], [41.5, 120.0], [41.6, 120.0], [41.7, 120.0], [41.8, 120.0], [41.9, 121.0], [42.0, 121.0], [42.1, 121.0], [42.2, 121.0], [42.3, 121.0], [42.4, 121.0], [42.5, 121.0], [42.6, 122.0], [42.7, 122.0], [42.8, 122.0], [42.9, 122.0], [43.0, 122.0], [43.1, 122.0], [43.2, 123.0], [43.3, 123.0], [43.4, 123.0], [43.5, 123.0], [43.6, 123.0], [43.7, 123.0], [43.8, 124.0], [43.9, 124.0], [44.0, 124.0], [44.1, 124.0], [44.2, 124.0], [44.3, 124.0], [44.4, 124.0], [44.5, 125.0], [44.6, 125.0], [44.7, 125.0], [44.8, 125.0], [44.9, 125.0], [45.0, 125.0], [45.1, 125.0], [45.2, 126.0], [45.3, 126.0], [45.4, 126.0], [45.5, 126.0], [45.6, 126.0], [45.7, 126.0], [45.8, 127.0], [45.9, 127.0], [46.0, 127.0], [46.1, 127.0], [46.2, 127.0], [46.3, 127.0], [46.4, 128.0], [46.5, 128.0], [46.6, 128.0], [46.7, 128.0], [46.8, 128.0], [46.9, 128.0], [47.0, 128.0], [47.1, 129.0], [47.2, 129.0], [47.3, 129.0], [47.4, 129.0], [47.5, 129.0], [47.6, 129.0], [47.7, 130.0], [47.8, 130.0], [47.9, 130.0], [48.0, 130.0], [48.1, 130.0], [48.2, 130.0], [48.3, 130.0], [48.4, 131.0], [48.5, 131.0], [48.6, 131.0], [48.7, 131.0], [48.8, 131.0], [48.9, 131.0], [49.0, 131.0], [49.1, 132.0], [49.2, 132.0], [49.3, 132.0], [49.4, 132.0], [49.5, 132.0], [49.6, 132.0], [49.7, 133.0], [49.8, 133.0], [49.9, 133.0], [50.0, 133.0], [50.1, 133.0], [50.2, 133.0], [50.3, 133.0], [50.4, 134.0], [50.5, 134.0], [50.6, 134.0], [50.7, 134.0], [50.8, 134.0], [50.9, 134.0], [51.0, 135.0], [51.1, 135.0], [51.2, 135.0], [51.3, 135.0], [51.4, 135.0], [51.5, 135.0], [51.6, 135.0], [51.7, 136.0], [51.8, 136.0], [51.9, 136.0], [52.0, 136.0], [52.1, 136.0], [52.2, 136.0], [52.3, 136.0], [52.4, 137.0], [52.5, 137.0], [52.6, 137.0], [52.7, 137.0], [52.8, 137.0], [52.9, 137.0], [53.0, 138.0], [53.1, 138.0], [53.2, 138.0], [53.3, 138.0], [53.4, 138.0], [53.5, 138.0], [53.6, 139.0], [53.7, 139.0], [53.8, 139.0], [53.9, 139.0], [54.0, 139.0], [54.1, 139.0], [54.2, 139.0], [54.3, 140.0], [54.4, 140.0], [54.5, 140.0], [54.6, 140.0], [54.7, 140.0], [54.8, 140.0], [54.9, 140.0], [55.0, 141.0], [55.1, 141.0], [55.2, 141.0], [55.3, 141.0], [55.4, 141.0], [55.5, 141.0], [55.6, 142.0], [55.7, 142.0], [55.8, 142.0], [55.9, 142.0], [56.0, 142.0], [56.1, 142.0], [56.2, 143.0], [56.3, 143.0], [56.4, 143.0], [56.5, 143.0], [56.6, 143.0], [56.7, 143.0], [56.8, 143.0], [56.9, 144.0], [57.0, 144.0], [57.1, 144.0], [57.2, 144.0], [57.3, 144.0], [57.4, 144.0], [57.5, 145.0], [57.6, 145.0], [57.7, 145.0], [57.8, 145.0], [57.9, 145.0], [58.0, 145.0], [58.1, 145.0], [58.2, 146.0], [58.3, 146.0], [58.4, 146.0], [58.5, 146.0], [58.6, 146.0], [58.7, 147.0], [58.8, 147.0], [58.9, 147.0], [59.0, 147.0], [59.1, 147.0], [59.2, 147.0], [59.3, 148.0], [59.4, 148.0], [59.5, 148.0], [59.6, 148.0], [59.7, 148.0], [59.8, 148.0], [59.9, 149.0], [60.0, 149.0], [60.1, 149.0], [60.2, 149.0], [60.3, 149.0], [60.4, 149.0], [60.5, 150.0], [60.6, 150.0], [60.7, 150.0], [60.8, 150.0], [60.9, 150.0], [61.0, 150.0], [61.1, 151.0], [61.2, 151.0], [61.3, 151.0], [61.4, 151.0], [61.5, 151.0], [61.6, 152.0], [61.7, 152.0], [61.8, 152.0], [61.9, 152.0], [62.0, 152.0], [62.1, 152.0], [62.2, 153.0], [62.3, 153.0], [62.4, 153.0], [62.5, 153.0], [62.6, 153.0], [62.7, 154.0], [62.8, 154.0], [62.9, 154.0], [63.0, 154.0], [63.1, 154.0], [63.2, 155.0], [63.3, 155.0], [63.4, 155.0], [63.5, 155.0], [63.6, 155.0], [63.7, 155.0], [63.8, 156.0], [63.9, 156.0], [64.0, 156.0], [64.1, 156.0], [64.2, 156.0], [64.3, 157.0], [64.4, 157.0], [64.5, 157.0], [64.6, 157.0], [64.7, 157.0], [64.8, 158.0], [64.9, 158.0], [65.0, 158.0], [65.1, 158.0], [65.2, 158.0], [65.3, 158.0], [65.4, 159.0], [65.5, 159.0], [65.6, 159.0], [65.7, 159.0], [65.8, 159.0], [65.9, 160.0], [66.0, 160.0], [66.1, 160.0], [66.2, 160.0], [66.3, 160.0], [66.4, 161.0], [66.5, 161.0], [66.6, 161.0], [66.7, 161.0], [66.8, 161.0], [66.9, 162.0], [67.0, 162.0], [67.1, 162.0], [67.2, 162.0], [67.3, 162.0], [67.4, 163.0], [67.5, 163.0], [67.6, 163.0], [67.7, 163.0], [67.8, 163.0], [67.9, 164.0], [68.0, 164.0], [68.1, 164.0], [68.2, 164.0], [68.3, 164.0], [68.4, 165.0], [68.5, 165.0], [68.6, 165.0], [68.7, 165.0], [68.8, 165.0], [68.9, 166.0], [69.0, 166.0], [69.1, 166.0], [69.2, 166.0], [69.3, 166.0], [69.4, 167.0], [69.5, 167.0], [69.6, 167.0], [69.7, 167.0], [69.8, 167.0], [69.9, 168.0], [70.0, 168.0], [70.1, 168.0], [70.2, 168.0], [70.3, 168.0], [70.4, 169.0], [70.5, 169.0], [70.6, 169.0], [70.7, 169.0], [70.8, 169.0], [70.9, 170.0], [71.0, 170.0], [71.1, 170.0], [71.2, 170.0], [71.3, 171.0], [71.4, 171.0], [71.5, 171.0], [71.6, 171.0], [71.7, 171.0], [71.8, 172.0], [71.9, 172.0], [72.0, 172.0], [72.1, 172.0], [72.2, 172.0], [72.3, 173.0], [72.4, 173.0], [72.5, 173.0], [72.6, 173.0], [72.7, 174.0], [72.8, 174.0], [72.9, 174.0], [73.0, 174.0], [73.1, 174.0], [73.2, 175.0], [73.3, 175.0], [73.4, 175.0], [73.5, 175.0], [73.6, 176.0], [73.7, 176.0], [73.8, 176.0], [73.9, 176.0], [74.0, 177.0], [74.1, 177.0], [74.2, 177.0], [74.3, 177.0], [74.4, 178.0], [74.5, 178.0], [74.6, 178.0], [74.7, 178.0], [74.8, 179.0], [74.9, 179.0], [75.0, 179.0], [75.1, 179.0], [75.2, 180.0], [75.3, 180.0], [75.4, 180.0], [75.5, 180.0], [75.6, 181.0], [75.7, 181.0], [75.8, 181.0], [75.9, 181.0], [76.0, 182.0], [76.1, 182.0], [76.2, 182.0], [76.3, 182.0], [76.4, 183.0], [76.5, 183.0], [76.6, 183.0], [76.7, 183.0], [76.8, 184.0], [76.9, 184.0], [77.0, 184.0], [77.1, 184.0], [77.2, 185.0], [77.3, 185.0], [77.4, 185.0], [77.5, 186.0], [77.6, 186.0], [77.7, 186.0], [77.8, 186.0], [77.9, 187.0], [78.0, 187.0], [78.1, 187.0], [78.2, 188.0], [78.3, 188.0], [78.4, 188.0], [78.5, 188.0], [78.6, 189.0], [78.7, 189.0], [78.8, 189.0], [78.9, 190.0], [79.0, 190.0], [79.1, 190.0], [79.2, 191.0], [79.3, 191.0], [79.4, 191.0], [79.5, 192.0], [79.6, 192.0], [79.7, 192.0], [79.8, 193.0], [79.9, 193.0], [80.0, 193.0], [80.1, 194.0], [80.2, 194.0], [80.3, 194.0], [80.4, 195.0], [80.5, 195.0], [80.6, 195.0], [80.7, 196.0], [80.8, 196.0], [80.9, 196.0], [81.0, 197.0], [81.1, 197.0], [81.2, 197.0], [81.3, 198.0], [81.4, 198.0], [81.5, 198.0], [81.6, 199.0], [81.7, 199.0], [81.8, 199.0], [81.9, 200.0], [82.0, 200.0], [82.1, 201.0], [82.2, 201.0], [82.3, 201.0], [82.4, 202.0], [82.5, 202.0], [82.6, 202.0], [82.7, 203.0], [82.8, 203.0], [82.9, 203.0], [83.0, 204.0], [83.1, 204.0], [83.2, 205.0], [83.3, 205.0], [83.4, 205.0], [83.5, 206.0], [83.6, 206.0], [83.7, 207.0], [83.8, 207.0], [83.9, 208.0], [84.0, 208.0], [84.1, 208.0], [84.2, 209.0], [84.3, 209.0], [84.4, 210.0], [84.5, 210.0], [84.6, 211.0], [84.7, 211.0], [84.8, 211.0], [84.9, 212.0], [85.0, 212.0], [85.1, 213.0], [85.2, 213.0], [85.3, 214.0], [85.4, 214.0], [85.5, 215.0], [85.6, 215.0], [85.7, 216.0], [85.8, 216.0], [85.9, 217.0], [86.0, 217.0], [86.1, 218.0], [86.2, 218.0], [86.3, 219.0], [86.4, 219.0], [86.5, 220.0], [86.6, 220.0], [86.7, 221.0], [86.8, 221.0], [86.9, 222.0], [87.0, 222.0], [87.1, 223.0], [87.2, 224.0], [87.3, 224.0], [87.4, 225.0], [87.5, 225.0], [87.6, 226.0], [87.7, 226.0], [87.8, 227.0], [87.9, 228.0], [88.0, 228.0], [88.1, 229.0], [88.2, 230.0], [88.3, 230.0], [88.4, 231.0], [88.5, 232.0], [88.6, 232.0], [88.7, 233.0], [88.8, 234.0], [88.9, 234.0], [89.0, 235.0], [89.1, 236.0], [89.2, 236.0], [89.3, 237.0], [89.4, 238.0], [89.5, 239.0], [89.6, 239.0], [89.7, 240.0], [89.8, 241.0], [89.9, 242.0], [90.0, 243.0], [90.1, 244.0], [90.2, 244.0], [90.3, 245.0], [90.4, 246.0], [90.5, 247.0], [90.6, 248.0], [90.7, 249.0], [90.8, 250.0], [90.9, 252.0], [91.0, 252.0], [91.1, 253.0], [91.2, 254.0], [91.3, 256.0], [91.4, 257.0], [91.5, 258.0], [91.6, 259.0], [91.7, 260.0], [91.8, 262.0], [91.9, 263.0], [92.0, 264.0], [92.1, 266.0], [92.2, 267.0], [92.3, 269.0], [92.4, 270.0], [92.5, 272.0], [92.6, 273.0], [92.7, 275.0], [92.8, 277.0], [92.9, 279.0], [93.0, 280.0], [93.1, 282.0], [93.2, 284.0], [93.3, 286.0], [93.4, 289.0], [93.5, 291.0], [93.6, 294.0], [93.7, 296.0], [93.8, 299.0], [93.9, 302.0], [94.0, 305.0], [94.1, 308.0], [94.2, 311.0], [94.3, 315.0], [94.4, 318.0], [94.5, 321.0], [94.6, 325.0], [94.7, 329.0], [94.8, 333.0], [94.9, 339.0], [95.0, 345.0], [95.1, 350.0], [95.2, 357.0], [95.3, 363.0], [95.4, 374.0], [95.5, 384.0], [95.6, 395.0], [95.7, 405.0], [95.8, 416.0], [95.9, 430.0], [96.0, 443.0], [96.1, 455.0], [96.2, 472.0], [96.3, 490.0], [96.4, 509.0], [96.5, 530.0], [96.6, 554.0], [96.7, 575.0], [96.8, 596.0], [96.9, 616.0], [97.0, 641.0], [97.1, 665.0], [97.2, 693.0], [97.3, 726.0], [97.4, 755.0], [97.5, 781.0], [97.6, 813.0], [97.7, 842.0], [97.8, 878.0], [97.9, 912.0], [98.0, 949.0], [98.1, 993.0], [98.2, 1032.0], [98.3, 1069.0], [98.4, 1102.0], [98.5, 1157.0], [98.6, 1221.0], [98.7, 1312.0], [98.8, 1399.0], [98.9, 1538.0], [99.0, 1683.0], [99.1, 1854.0], [99.2, 2007.0], [99.3, 2127.0], [99.4, 2389.0], [99.5, 4523.0], [99.6, 10010.0], [99.7, 10010.0], [99.8, 10010.0], [99.9, 10011.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 289031.0, "series": [{"data": [[0.0, 289031.0], [4500.0, 91.0], [10000.0, 1418.0], [2500.0, 132.0], [1500.0, 962.0], [3000.0, 1.0], [3500.0, 2.0], [500.0, 5316.0], [1000.0, 2276.0], [2000.0, 725.0], [4000.0, 46.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 500, "maxX": 10000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1400.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 289047.0, "series": [{"data": [[1.0, 7578.0]], "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[3.0, 1400.0]], "isOverall": false, "label": "Requests in error", "isController": false}, {"data": [[0.0, 289047.0]], "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[2.0, 1975.0]], "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 158.02748665696313, "minX": 1.49360514E12, "maxY": 300.0, "series": [{"data": [[1.4936052E12, 300.0], [1.49360538E12, 158.02748665696313], [1.49360526E12, 299.8258454500894], [1.49360514E12, 190.69309434548302], [1.49360532E12, 282.6390451050181]], "isOverall": false, "label": "性能测试", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49360538E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 52.301886792452834, "minX": 1.0, "maxY": 1508.427884615385, "series": [{"data": [[2.0, 52.74626865671643], [3.0, 52.693548387096754], [4.0, 56.458333333333336], [5.0, 52.301886792452834], [6.0, 52.68421052631579], [7.0, 55.55072463768116], [8.0, 52.88888888888891], [9.0, 53.78481012658226], [10.0, 54.77272727272727], [11.0, 53.07563025210084], [12.0, 54.30952380952381], [13.0, 53.449438202247194], [14.0, 54.00826446280991], [15.0, 53.64625850340136], [16.0, 54.00000000000001], [17.0, 54.015873015873005], [18.0, 54.48529411764704], [19.0, 56.20754716981132], [20.0, 54.701923076923066], [21.0, 58.56060606060608], [22.0, 60.981132075471685], [23.0, 56.66836734693878], [24.0, 56.64606741573034], [25.0, 57.875], [26.0, 59.10852713178296], [27.0, 58.988235294117636], [28.0, 53.65853658536585], [29.0, 53.63636363636362], [30.0, 55.64363636363638], [31.0, 55.58974358974358], [32.0, 56.64984227129338], [33.0, 57.64705882352941], [34.0, 57.734177215189895], [35.0, 61.01438848920863], [36.0, 57.227272727272705], [37.0, 60.21111111111111], [38.0, 59.25185185185187], [39.0, 56.66783216783218], [40.0, 58.00490196078429], [41.0, 55.64900662251655], [42.0, 56.08928571428568], [43.0, 57.47126436781607], [44.0, 56.38095238095237], [45.0, 57.50000000000001], [46.0, 54.927083333333336], [47.0, 57.76303317535545], [48.0, 55.37606837606838], [49.0, 54.937499999999986], [50.0, 66.99999999999996], [51.0, 59.32926829268291], [52.0, 200.07692307692304], [53.0, 61.581818181818186], [54.0, 197.50000000000003], [55.0, 204.32848837209303], [56.0, 63.49572649572648], [57.0, 64.08247422680417], [58.0, 62.07758620689657], [59.0, 59.140983606557405], [60.0, 130.22516556291384], [61.0, 59.82608695652169], [62.0, 69.03937007874018], [63.0, 65.77011494252878], [64.0, 65.519313304721], [65.0, 60.47647058823529], [66.0, 59.067010309278345], [67.0, 58.661538461538456], [68.0, 59.17491749174919], [69.0, 107.3036144578313], [70.0, 57.80434782608696], [71.0, 292.65088757396444], [72.0, 201.70289855072463], [73.0, 167.28108108108108], [74.0, 61.52000000000001], [75.0, 61.519417475728154], [76.0, 61.39130434782609], [77.0, 72.34626865671642], [78.0, 60.89235127478755], [79.0, 63.672727272727236], [80.0, 58.53174603174606], [81.0, 61.101265822784825], [82.0, 58.30588235294117], [83.0, 75.16444444444446], [84.0, 63.323943661971875], [85.0, 65.69465648854961], [86.0, 66.0598290598291], [87.0, 59.49489795918365], [88.0, 58.623255813953485], [89.0, 60.0597014925373], [90.0, 61.08000000000002], [91.0, 61.011834319526635], [92.0, 59.56756756756757], [93.0, 60.219626168224295], [94.0, 65.71707317073167], [95.0, 67.04379562043796], [96.0, 75.92926045016081], [97.0, 65.31746031746029], [98.0, 64.76071428571426], [99.0, 64.06214689265542], [100.0, 74.9719298245614], [101.0, 74.79629629629632], [102.0, 67.99141630901286], [103.0, 66.7190775681342], [104.0, 64.06652806652802], [105.0, 82.46153846153845], [106.0, 86.43203883495148], [107.0, 86.71428571428568], [108.0, 71.93470790378011], [109.0, 73.04810126582277], [110.0, 74.3295880149812], [111.0, 99.88505747126436], [112.0, 79.3252427184466], [113.0, 80.60913705583758], [114.0, 68.38436482084688], [115.0, 76.90043290043288], [116.0, 88.0189873417722], [117.0, 70.52071005917158], [118.0, 68.47150259067357], [119.0, 72.28846153846156], [120.0, 76.3607038123168], [121.0, 71.54035087719295], [122.0, 75.76699029126209], [123.0, 80.77803738317758], [124.0, 82.57657657657657], [125.0, 84.7704081632653], [126.0, 365.11286089238854], [127.0, 76.36781609195404], [128.0, 76.07514450867055], [129.0, 89.80916030534351], [130.0, 83.38764044943821], [131.0, 80.95495495495501], [132.0, 84.92268041237115], [133.0, 81.04088050314465], [134.0, 111.39130434782611], [135.0, 97.73575129533683], [136.0, 87.14957264957263], [137.0, 84.30288461538461], [138.0, 82.07427055702912], [139.0, 82.03571428571429], [140.0, 82.49999999999999], [141.0, 80.98962962962965], [142.0, 87.79812206572768], [143.0, 78.99340659340668], [144.0, 102.54140127388533], [145.0, 81.65411436541149], [146.0, 96.82181818181822], [147.0, 84.43646408839791], [148.0, 179.0639269406393], [149.0, 85.77272727272728], [150.0, 88.5573770491803], [151.0, 111.33689839572187], [152.0, 94.31630170316298], [153.0, 93.7905660377359], [154.0, 98.46743295019155], [155.0, 90.57587548638132], [156.0, 160.129963898917], [157.0, 175.45224719101134], [158.0, 145.69072164948452], [159.0, 99.78032786885248], [160.0, 103.78546712802773], [161.0, 1508.427884615385], [162.0, 776.9349112426037], [163.0, 81.7372881355932], [164.0, 103.53608247422679], [165.0, 287.6121212121211], [166.0, 106.75845410628021], [167.0, 114.12328767123286], [168.0, 1020.9921259842528], [169.0, 93.24358974358974], [170.0, 97.82876712328763], [171.0, 93.31012658227849], [172.0, 97.34760705289672], [173.0, 100.06837606837598], [174.0, 94.76162790697674], [175.0, 227.23529411764707], [176.0, 112.64705882352942], [177.0, 184.65085388994305], [178.0, 114.87719298245612], [179.0, 218.3038548752832], [180.0, 123.90116279069765], [181.0, 137.30000000000004], [182.0, 126.91941391941384], [183.0, 110.81355932203394], [184.0, 103.48288973384037], [185.0, 106.41717791411045], [186.0, 114.41397849462363], [187.0, 143.80483271375468], [188.0, 100.77044854881257], [189.0, 128.68852459016395], [190.0, 137.968115942029], [191.0, 112.55172413793105], [192.0, 130.58749999999998], [193.0, 123.14463452566108], [194.0, 110.46363636363634], [195.0, 155.77721518987346], [196.0, 193.44646924829172], [197.0, 130.37759336099597], [198.0, 106.18784530386742], [199.0, 108.20320855614975], [200.0, 139.96800947867294], [201.0, 108.96666666666664], [202.0, 118.90430622009569], [203.0, 127.81735159817357], [204.0, 149.08241758241755], [205.0, 190.61923076923077], [206.0, 112.512315270936], [207.0, 127.58194444444443], [208.0, 140.007894736842], [209.0, 136.06878306878306], [210.0, 151.34117647058824], [211.0, 124.16249999999998], [212.0, 129.64437689969603], [213.0, 121.55956678700362], [214.0, 144.576923076923], [215.0, 146.19999999999996], [216.0, 163.87179487179512], [217.0, 153.62376237623766], [218.0, 172.1793478260869], [219.0, 202.2655601659751], [220.0, 197.0978593272171], [221.0, 146.20253164556962], [222.0, 137.11389521640086], [223.0, 175.30664652567975], [224.0, 113.30283911671916], [225.0, 197.24270833333316], [226.0, 144.6917057902975], [227.0, 156.3349693251535], [228.0, 139.0828157349897], [229.0, 158.0612691466083], [230.0, 166.1436170212765], [231.0, 131.26651480637807], [232.0, 148.12423625254578], [233.0, 186.84834123222743], [234.0, 237.87000000000003], [235.0, 203.23421588594692], [236.0, 154.38095238095238], [237.0, 215.16738197424868], [238.0, 145.43296703296707], [239.0, 159.46361746361748], [240.0, 285.5989399293286], [241.0, 145.46874999999997], [242.0, 166.13661202185799], [243.0, 162.98472505091635], [244.0, 153.55870445344124], [245.0, 164.53703703703695], [246.0, 378.8684684684681], [247.0, 99.27786752827147], [248.0, 189.19649805447477], [249.0, 189.31641791044777], [250.0, 258.87668593449], [251.0, 145.62681159420302], [252.0, 377.9572446555821], [253.0, 94.85024154589374], [254.0, 208.96790757381228], [255.0, 133.40501792114705], [257.0, 130.2452830188679], [256.0, 126.06912442396317], [258.0, 189.96332046332057], [259.0, 151.8245989304813], [260.0, 627.8435374149657], [261.0, 142.01677852349], [262.0, 206.65766871165647], [263.0, 138.2303030303029], [264.0, 228.67370272647304], [270.0, 241.2741935483871], [271.0, 424.5114893617025], [268.0, 238.0661538461539], [269.0, 527.8955847255367], [265.0, 267.10843373493987], [266.0, 112.88073394495407], [267.0, 300.48495788207015], [273.0, 407.85696517412924], [272.0, 424.0709764918629], [274.0, 148.61363636363635], [275.0, 185.6173752310536], [276.0, 193.2717086834733], [277.0, 691.2505747126431], [278.0, 609.7755443886102], [279.0, 208.49844236760117], [280.0, 195.5465465465464], [286.0, 175.04638218923947], [287.0, 292.0079588014988], [284.0, 184.36912751677838], [285.0, 388.37557755775555], [281.0, 537.6654275092936], [282.0, 370.61239824671304], [283.0, 190.9303135888499], [289.0, 307.2700854700856], [288.0, 275.02185619258813], [290.0, 173.6053719008265], [291.0, 177.75630252100828], [292.0, 363.6573581560278], [293.0, 311.85278126306935], [294.0, 174.28863450531477], [295.0, 181.98031496063], [296.0, 244.54575196810072], [300.0, 223.4476269473028], [297.0, 237.91610942249247], [298.0, 212.64580335731384], [299.0, 193.78400705806774], [1.0, 53.0]], "isOverall": false, "label": "HTTP请求", "isController": false}, {"data": [[260.9930900000025, 217.5284900000028]], "isOverall": false, "label": "HTTP请求-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 300.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 154098.75, "minX": 1.49360514E12, "maxY": 954473.1666666666, "series": [{"data": [[1.4936052E12, 844633.05], [1.49360538E12, 455898.13333333336], [1.49360526E12, 954473.1666666666], [1.49360514E12, 494000.9666666667], [1.49360532E12, 585612.65]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.4936052E12, 282352.5], [1.49360538E12, 154098.75], [1.49360526E12, 319635.0], [1.49360514E12, 169005.0], [1.49360532E12, 194658.75]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49360538E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 124.40382439716996, "minX": 1.49360514E12, "maxY": 323.47486514403886, "series": [{"data": [[1.4936052E12, 233.7587185886501], [1.49360538E12, 167.45638039786567], [1.49360526E12, 211.62580810792056], [1.49360514E12, 124.40382439716996], [1.49360532E12, 323.47486514403886]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49360538E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 121.9541693471466, "minX": 1.49360514E12, "maxY": 252.81078082558676, "series": [{"data": [[1.4936052E12, 176.2524000052816], [1.49360538E12, 136.6050460941286], [1.49360526E12, 158.11657759003057], [1.49360514E12, 121.9541693471466], [1.49360532E12, 252.81078082558676]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49360538E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.23658466248142, "minX": 1.49360514E12, "maxY": 0.5702016144458496, "series": [{"data": [[1.4936052E12, 0.3910655099103388], [1.49360538E12, 0.3311014070839388], [1.49360526E12, 0.31488785679277315], [1.49360514E12, 0.23658466248142], [1.49360532E12, 0.5702016144458496]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49360538E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 27.0, "minX": 1.49360514E12, "maxY": 10037.0, "series": [{"data": [[1.4936052E12, 10037.0], [1.49360538E12, 10010.0], [1.49360526E12, 10009.0], [1.49360514E12, 544.0], [1.49360532E12, 10011.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.4936052E12, 28.0], [1.49360538E12, 27.0], [1.49360526E12, 27.0], [1.49360514E12, 28.0], [1.49360532E12, 27.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.4936052E12, 476.0], [1.49360538E12, 107.0], [1.49360526E12, 234.0], [1.49360514E12, 234.0], [1.49360532E12, 842.9000000000015]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.4936052E12, 1713.9900000000016], [1.49360538E12, 468.9900000000016], [1.49360526E12, 453.0], [1.49360514E12, 341.0], [1.49360532E12, 2446.9900000000016]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.4936052E12, 1003.0], [1.49360538E12, 129.95000000000073], [1.49360526E12, 294.0], [1.49360514E12, 267.9500000000007], [1.49360532E12, 1660.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49360538E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 62.0, "minX": 15729.0, "maxY": 10010.0, "series": [{"data": [[41220.0, 62.0], [45079.0, 155.0], [25694.0, 146.0], [52278.0, 132.0], [15729.0, 135.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[41220.0, 10010.0], [45079.0, 10010.0], [25694.0, 10010.0], [52278.0, 10010.0], [15729.0, 10010.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 52278.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 15729.0, "maxY": 155.0, "series": [{"data": [[41220.0, 62.0], [45079.0, 155.0], [25694.0, 146.0], [52278.0, 132.0], [15729.0, 135.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[41220.0, 0.0], [45079.0, 0.0], [25694.0, 0.0], [52278.0, 0.0], [15729.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 52278.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 682.85, "minX": 1.49360514E12, "maxY": 1428.2, "series": [{"data": [[1.4936052E12, 1262.15], [1.49360538E12, 682.85], [1.49360526E12, 1428.2], [1.49360514E12, 756.3166666666667], [1.49360532E12, 870.4833333333333]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49360538E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.18333333333333332, "minX": 1.49360514E12, "maxY": 1420.6, "series": [{"data": [[1.4936052E12, 1254.9], [1.49360538E12, 684.8833333333333], [1.49360526E12, 1420.6], [1.49360514E12, 751.1333333333333], [1.49360532E12, 865.15]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.4936052E12, 7.25], [1.49360538E12, 2.1166666666666667], [1.49360526E12, 7.633333333333334], [1.49360514E12, 0.18333333333333332], [1.49360532E12, 6.15]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketTimeoutException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49360538E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.18333333333333332, "minX": 1.49360514E12, "maxY": 1420.6, "series": [{"data": [[1.4936052E12, 7.25], [1.49360538E12, 2.1166666666666667], [1.49360526E12, 7.633333333333334], [1.49360514E12, 0.18333333333333332], [1.49360532E12, 6.15]], "isOverall": false, "label": "HTTP请求-failure", "isController": false}, {"data": [[1.4936052E12, 1254.9], [1.49360538E12, 684.8833333333333], [1.49360526E12, 1420.6], [1.49360514E12, 751.1333333333333], [1.49360532E12, 865.15]], "isOverall": false, "label": "HTTP请求-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49360538E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
