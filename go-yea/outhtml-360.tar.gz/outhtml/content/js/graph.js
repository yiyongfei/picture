/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 0 : 0;
        var yOffset = options.yaxis.mode === "time" ? 0 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 28.0, "minX": 0.0, "maxY": 702.0, "series": [{"data": [[0.0, 28.0], [0.1, 51.0], [0.2, 51.0], [0.3, 51.0], [0.4, 52.0], [0.5, 52.0], [0.6, 52.0], [0.7, 52.0], [0.8, 52.0], [0.9, 53.0], [1.0, 53.0], [1.1, 53.0], [1.2, 54.0], [1.3, 54.0], [1.4, 55.0], [1.5, 55.0], [1.6, 56.0], [1.7, 56.0], [1.8, 57.0], [1.9, 58.0], [2.0, 59.0], [2.1, 60.0], [2.2, 61.0], [2.3, 62.0], [2.4, 63.0], [2.5, 64.0], [2.6, 65.0], [2.7, 66.0], [2.8, 67.0], [2.9, 68.0], [3.0, 69.0], [3.1, 70.0], [3.2, 71.0], [3.3, 73.0], [3.4, 74.0], [3.5, 75.0], [3.6, 76.0], [3.7, 77.0], [3.8, 77.0], [3.9, 78.0], [4.0, 79.0], [4.1, 79.0], [4.2, 80.0], [4.3, 81.0], [4.4, 82.0], [4.5, 82.0], [4.6, 83.0], [4.7, 84.0], [4.8, 84.0], [4.9, 85.0], [5.0, 86.0], [5.1, 86.0], [5.2, 87.0], [5.3, 88.0], [5.4, 89.0], [5.5, 89.0], [5.6, 90.0], [5.7, 91.0], [5.8, 91.0], [5.9, 92.0], [6.0, 93.0], [6.1, 94.0], [6.2, 94.0], [6.3, 95.0], [6.4, 96.0], [6.5, 97.0], [6.6, 97.0], [6.7, 98.0], [6.8, 99.0], [6.9, 100.0], [7.0, 100.0], [7.1, 101.0], [7.2, 102.0], [7.3, 102.0], [7.4, 103.0], [7.5, 104.0], [7.6, 104.0], [7.7, 105.0], [7.8, 105.0], [7.9, 106.0], [8.0, 107.0], [8.1, 107.0], [8.2, 108.0], [8.3, 108.0], [8.4, 109.0], [8.5, 109.0], [8.6, 110.0], [8.7, 111.0], [8.8, 111.0], [8.9, 112.0], [9.0, 112.0], [9.1, 113.0], [9.2, 113.0], [9.3, 114.0], [9.4, 114.0], [9.5, 115.0], [9.6, 115.0], [9.7, 116.0], [9.8, 116.0], [9.9, 117.0], [10.0, 117.0], [10.1, 118.0], [10.2, 118.0], [10.3, 119.0], [10.4, 119.0], [10.5, 120.0], [10.6, 120.0], [10.7, 121.0], [10.8, 121.0], [10.9, 122.0], [11.0, 122.0], [11.1, 123.0], [11.2, 123.0], [11.3, 124.0], [11.4, 124.0], [11.5, 125.0], [11.6, 125.0], [11.7, 126.0], [11.8, 126.0], [11.9, 127.0], [12.0, 127.0], [12.1, 128.0], [12.2, 128.0], [12.3, 128.0], [12.4, 129.0], [12.5, 129.0], [12.6, 130.0], [12.7, 130.0], [12.8, 131.0], [12.9, 131.0], [13.0, 131.0], [13.1, 132.0], [13.2, 132.0], [13.3, 133.0], [13.4, 133.0], [13.5, 133.0], [13.6, 134.0], [13.7, 134.0], [13.8, 134.0], [13.9, 135.0], [14.0, 135.0], [14.1, 136.0], [14.2, 136.0], [14.3, 136.0], [14.4, 137.0], [14.5, 137.0], [14.6, 137.0], [14.7, 138.0], [14.8, 138.0], [14.9, 138.0], [15.0, 139.0], [15.1, 139.0], [15.2, 139.0], [15.3, 140.0], [15.4, 140.0], [15.5, 140.0], [15.6, 141.0], [15.7, 141.0], [15.8, 141.0], [15.9, 142.0], [16.0, 142.0], [16.1, 142.0], [16.2, 143.0], [16.3, 143.0], [16.4, 143.0], [16.5, 144.0], [16.6, 144.0], [16.7, 144.0], [16.8, 145.0], [16.9, 145.0], [17.0, 145.0], [17.1, 146.0], [17.2, 146.0], [17.3, 146.0], [17.4, 147.0], [17.5, 147.0], [17.6, 147.0], [17.7, 148.0], [17.8, 148.0], [17.9, 148.0], [18.0, 149.0], [18.1, 149.0], [18.2, 149.0], [18.3, 149.0], [18.4, 150.0], [18.5, 150.0], [18.6, 150.0], [18.7, 151.0], [18.8, 151.0], [18.9, 151.0], [19.0, 152.0], [19.1, 152.0], [19.2, 152.0], [19.3, 153.0], [19.4, 153.0], [19.5, 153.0], [19.6, 153.0], [19.7, 154.0], [19.8, 154.0], [19.9, 154.0], [20.0, 155.0], [20.1, 155.0], [20.2, 155.0], [20.3, 155.0], [20.4, 156.0], [20.5, 156.0], [20.6, 156.0], [20.7, 157.0], [20.8, 157.0], [20.9, 157.0], [21.0, 157.0], [21.1, 158.0], [21.2, 158.0], [21.3, 158.0], [21.4, 159.0], [21.5, 159.0], [21.6, 159.0], [21.7, 159.0], [21.8, 160.0], [21.9, 160.0], [22.0, 160.0], [22.1, 161.0], [22.2, 161.0], [22.3, 161.0], [22.4, 161.0], [22.5, 162.0], [22.6, 162.0], [22.7, 162.0], [22.8, 162.0], [22.9, 163.0], [23.0, 163.0], [23.1, 163.0], [23.2, 163.0], [23.3, 164.0], [23.4, 164.0], [23.5, 164.0], [23.6, 164.0], [23.7, 165.0], [23.8, 165.0], [23.9, 165.0], [24.0, 165.0], [24.1, 166.0], [24.2, 166.0], [24.3, 166.0], [24.4, 166.0], [24.5, 167.0], [24.6, 167.0], [24.7, 167.0], [24.8, 167.0], [24.9, 168.0], [25.0, 168.0], [25.1, 168.0], [25.2, 168.0], [25.3, 169.0], [25.4, 169.0], [25.5, 169.0], [25.6, 169.0], [25.7, 170.0], [25.8, 170.0], [25.9, 170.0], [26.0, 170.0], [26.1, 171.0], [26.2, 171.0], [26.3, 171.0], [26.4, 171.0], [26.5, 172.0], [26.6, 172.0], [26.7, 172.0], [26.8, 172.0], [26.9, 173.0], [27.0, 173.0], [27.1, 173.0], [27.2, 173.0], [27.3, 173.0], [27.4, 174.0], [27.5, 174.0], [27.6, 174.0], [27.7, 174.0], [27.8, 175.0], [27.9, 175.0], [28.0, 175.0], [28.1, 175.0], [28.2, 176.0], [28.3, 176.0], [28.4, 176.0], [28.5, 176.0], [28.6, 177.0], [28.7, 177.0], [28.8, 177.0], [28.9, 177.0], [29.0, 178.0], [29.1, 178.0], [29.2, 178.0], [29.3, 178.0], [29.4, 178.0], [29.5, 179.0], [29.6, 179.0], [29.7, 179.0], [29.8, 179.0], [29.9, 180.0], [30.0, 180.0], [30.1, 180.0], [30.2, 180.0], [30.3, 180.0], [30.4, 181.0], [30.5, 181.0], [30.6, 181.0], [30.7, 181.0], [30.8, 182.0], [30.9, 182.0], [31.0, 182.0], [31.1, 182.0], [31.2, 182.0], [31.3, 183.0], [31.4, 183.0], [31.5, 183.0], [31.6, 183.0], [31.7, 184.0], [31.8, 184.0], [31.9, 184.0], [32.0, 184.0], [32.1, 184.0], [32.2, 185.0], [32.3, 185.0], [32.4, 185.0], [32.5, 185.0], [32.6, 185.0], [32.7, 186.0], [32.8, 186.0], [32.9, 186.0], [33.0, 186.0], [33.1, 187.0], [33.2, 187.0], [33.3, 187.0], [33.4, 187.0], [33.5, 187.0], [33.6, 188.0], [33.7, 188.0], [33.8, 188.0], [33.9, 188.0], [34.0, 188.0], [34.1, 189.0], [34.2, 189.0], [34.3, 189.0], [34.4, 189.0], [34.5, 189.0], [34.6, 190.0], [34.7, 190.0], [34.8, 190.0], [34.9, 190.0], [35.0, 191.0], [35.1, 191.0], [35.2, 191.0], [35.3, 191.0], [35.4, 191.0], [35.5, 192.0], [35.6, 192.0], [35.7, 192.0], [35.8, 192.0], [35.9, 192.0], [36.0, 193.0], [36.1, 193.0], [36.2, 193.0], [36.3, 193.0], [36.4, 193.0], [36.5, 194.0], [36.6, 194.0], [36.7, 194.0], [36.8, 194.0], [36.9, 194.0], [37.0, 195.0], [37.1, 195.0], [37.2, 195.0], [37.3, 195.0], [37.4, 195.0], [37.5, 196.0], [37.6, 196.0], [37.7, 196.0], [37.8, 196.0], [37.9, 196.0], [38.0, 197.0], [38.1, 197.0], [38.2, 197.0], [38.3, 197.0], [38.4, 197.0], [38.5, 198.0], [38.6, 198.0], [38.7, 198.0], [38.8, 198.0], [38.9, 198.0], [39.0, 199.0], [39.1, 199.0], [39.2, 199.0], [39.3, 199.0], [39.4, 199.0], [39.5, 200.0], [39.6, 200.0], [39.7, 200.0], [39.8, 200.0], [39.9, 200.0], [40.0, 201.0], [40.1, 201.0], [40.2, 201.0], [40.3, 201.0], [40.4, 201.0], [40.5, 202.0], [40.6, 202.0], [40.7, 202.0], [40.8, 202.0], [40.9, 202.0], [41.0, 203.0], [41.1, 203.0], [41.2, 203.0], [41.3, 203.0], [41.4, 204.0], [41.5, 204.0], [41.6, 204.0], [41.7, 204.0], [41.8, 204.0], [41.9, 204.0], [42.0, 205.0], [42.1, 205.0], [42.2, 205.0], [42.3, 205.0], [42.4, 205.0], [42.5, 206.0], [42.6, 206.0], [42.7, 206.0], [42.8, 206.0], [42.9, 206.0], [43.0, 207.0], [43.1, 207.0], [43.2, 207.0], [43.3, 207.0], [43.4, 207.0], [43.5, 208.0], [43.6, 208.0], [43.7, 208.0], [43.8, 208.0], [43.9, 208.0], [44.0, 209.0], [44.1, 209.0], [44.2, 209.0], [44.3, 209.0], [44.4, 209.0], [44.5, 210.0], [44.6, 210.0], [44.7, 210.0], [44.8, 210.0], [44.9, 210.0], [45.0, 211.0], [45.1, 211.0], [45.2, 211.0], [45.3, 211.0], [45.4, 211.0], [45.5, 211.0], [45.6, 212.0], [45.7, 212.0], [45.8, 212.0], [45.9, 212.0], [46.0, 212.0], [46.1, 213.0], [46.2, 213.0], [46.3, 213.0], [46.4, 213.0], [46.5, 213.0], [46.6, 214.0], [46.7, 214.0], [46.8, 214.0], [46.9, 214.0], [47.0, 214.0], [47.1, 215.0], [47.2, 215.0], [47.3, 215.0], [47.4, 215.0], [47.5, 215.0], [47.6, 216.0], [47.7, 216.0], [47.8, 216.0], [47.9, 216.0], [48.0, 216.0], [48.1, 217.0], [48.2, 217.0], [48.3, 217.0], [48.4, 217.0], [48.5, 217.0], [48.6, 218.0], [48.7, 218.0], [48.8, 218.0], [48.9, 218.0], [49.0, 218.0], [49.1, 219.0], [49.2, 219.0], [49.3, 219.0], [49.4, 219.0], [49.5, 219.0], [49.6, 220.0], [49.7, 220.0], [49.8, 220.0], [49.9, 220.0], [50.0, 220.0], [50.1, 221.0], [50.2, 221.0], [50.3, 221.0], [50.4, 221.0], [50.5, 221.0], [50.6, 222.0], [50.7, 222.0], [50.8, 222.0], [50.9, 222.0], [51.0, 222.0], [51.1, 223.0], [51.2, 223.0], [51.3, 223.0], [51.4, 223.0], [51.5, 223.0], [51.6, 224.0], [51.7, 224.0], [51.8, 224.0], [51.9, 224.0], [52.0, 224.0], [52.1, 225.0], [52.2, 225.0], [52.3, 225.0], [52.4, 225.0], [52.5, 225.0], [52.6, 226.0], [52.7, 226.0], [52.8, 226.0], [52.9, 226.0], [53.0, 226.0], [53.1, 227.0], [53.2, 227.0], [53.3, 227.0], [53.4, 227.0], [53.5, 227.0], [53.6, 228.0], [53.7, 228.0], [53.8, 228.0], [53.9, 228.0], [54.0, 228.0], [54.1, 229.0], [54.2, 229.0], [54.3, 229.0], [54.4, 229.0], [54.5, 229.0], [54.6, 230.0], [54.7, 230.0], [54.8, 230.0], [54.9, 230.0], [55.0, 230.0], [55.1, 231.0], [55.2, 231.0], [55.3, 231.0], [55.4, 231.0], [55.5, 231.0], [55.6, 232.0], [55.7, 232.0], [55.8, 232.0], [55.9, 232.0], [56.0, 232.0], [56.1, 233.0], [56.2, 233.0], [56.3, 233.0], [56.4, 233.0], [56.5, 233.0], [56.6, 234.0], [56.7, 234.0], [56.8, 234.0], [56.9, 234.0], [57.0, 234.0], [57.1, 235.0], [57.2, 235.0], [57.3, 235.0], [57.4, 235.0], [57.5, 235.0], [57.6, 236.0], [57.7, 236.0], [57.8, 236.0], [57.9, 236.0], [58.0, 237.0], [58.1, 237.0], [58.2, 237.0], [58.3, 237.0], [58.4, 237.0], [58.5, 238.0], [58.6, 238.0], [58.7, 238.0], [58.8, 238.0], [58.9, 238.0], [59.0, 239.0], [59.1, 239.0], [59.2, 239.0], [59.3, 239.0], [59.4, 240.0], [59.5, 240.0], [59.6, 240.0], [59.7, 240.0], [59.8, 240.0], [59.9, 241.0], [60.0, 241.0], [60.1, 241.0], [60.2, 241.0], [60.3, 241.0], [60.4, 242.0], [60.5, 242.0], [60.6, 242.0], [60.7, 242.0], [60.8, 242.0], [60.9, 243.0], [61.0, 243.0], [61.1, 243.0], [61.2, 243.0], [61.3, 244.0], [61.4, 244.0], [61.5, 244.0], [61.6, 244.0], [61.7, 244.0], [61.8, 245.0], [61.9, 245.0], [62.0, 245.0], [62.1, 245.0], [62.2, 245.0], [62.3, 246.0], [62.4, 246.0], [62.5, 246.0], [62.6, 246.0], [62.7, 247.0], [62.8, 247.0], [62.9, 247.0], [63.0, 247.0], [63.1, 247.0], [63.2, 248.0], [63.3, 248.0], [63.4, 248.0], [63.5, 248.0], [63.6, 248.0], [63.7, 249.0], [63.8, 249.0], [63.9, 249.0], [64.0, 249.0], [64.1, 249.0], [64.2, 250.0], [64.3, 250.0], [64.4, 250.0], [64.5, 250.0], [64.6, 251.0], [64.7, 251.0], [64.8, 251.0], [64.9, 251.0], [65.0, 251.0], [65.1, 252.0], [65.2, 252.0], [65.3, 252.0], [65.4, 252.0], [65.5, 253.0], [65.6, 253.0], [65.7, 253.0], [65.8, 253.0], [65.9, 253.0], [66.0, 254.0], [66.1, 254.0], [66.2, 254.0], [66.3, 254.0], [66.4, 255.0], [66.5, 255.0], [66.6, 255.0], [66.7, 255.0], [66.8, 255.0], [66.9, 256.0], [67.0, 256.0], [67.1, 256.0], [67.2, 256.0], [67.3, 257.0], [67.4, 257.0], [67.5, 257.0], [67.6, 257.0], [67.7, 258.0], [67.8, 258.0], [67.9, 258.0], [68.0, 258.0], [68.1, 258.0], [68.2, 259.0], [68.3, 259.0], [68.4, 259.0], [68.5, 259.0], [68.6, 260.0], [68.7, 260.0], [68.8, 260.0], [68.9, 260.0], [69.0, 261.0], [69.1, 261.0], [69.2, 261.0], [69.3, 261.0], [69.4, 261.0], [69.5, 262.0], [69.6, 262.0], [69.7, 262.0], [69.8, 262.0], [69.9, 263.0], [70.0, 263.0], [70.1, 263.0], [70.2, 263.0], [70.3, 264.0], [70.4, 264.0], [70.5, 264.0], [70.6, 264.0], [70.7, 265.0], [70.8, 265.0], [70.9, 265.0], [71.0, 265.0], [71.1, 265.0], [71.2, 266.0], [71.3, 266.0], [71.4, 266.0], [71.5, 266.0], [71.6, 267.0], [71.7, 267.0], [71.8, 267.0], [71.9, 267.0], [72.0, 268.0], [72.1, 268.0], [72.2, 268.0], [72.3, 268.0], [72.4, 269.0], [72.5, 269.0], [72.6, 269.0], [72.7, 269.0], [72.8, 270.0], [72.9, 270.0], [73.0, 270.0], [73.1, 270.0], [73.2, 271.0], [73.3, 271.0], [73.4, 271.0], [73.5, 271.0], [73.6, 272.0], [73.7, 272.0], [73.8, 272.0], [73.9, 272.0], [74.0, 273.0], [74.1, 273.0], [74.2, 273.0], [74.3, 273.0], [74.4, 274.0], [74.5, 274.0], [74.6, 274.0], [74.7, 274.0], [74.8, 275.0], [74.9, 275.0], [75.0, 275.0], [75.1, 275.0], [75.2, 276.0], [75.3, 276.0], [75.4, 276.0], [75.5, 276.0], [75.6, 277.0], [75.7, 277.0], [75.8, 277.0], [75.9, 278.0], [76.0, 278.0], [76.1, 278.0], [76.2, 278.0], [76.3, 279.0], [76.4, 279.0], [76.5, 279.0], [76.6, 279.0], [76.7, 280.0], [76.8, 280.0], [76.9, 280.0], [77.0, 281.0], [77.1, 281.0], [77.2, 281.0], [77.3, 281.0], [77.4, 282.0], [77.5, 282.0], [77.6, 282.0], [77.7, 282.0], [77.8, 283.0], [77.9, 283.0], [78.0, 283.0], [78.1, 284.0], [78.2, 284.0], [78.3, 284.0], [78.4, 284.0], [78.5, 285.0], [78.6, 285.0], [78.7, 285.0], [78.8, 286.0], [78.9, 286.0], [79.0, 286.0], [79.1, 287.0], [79.2, 287.0], [79.3, 287.0], [79.4, 287.0], [79.5, 288.0], [79.6, 288.0], [79.7, 288.0], [79.8, 289.0], [79.9, 289.0], [80.0, 289.0], [80.1, 290.0], [80.2, 290.0], [80.3, 290.0], [80.4, 290.0], [80.5, 291.0], [80.6, 291.0], [80.7, 291.0], [80.8, 292.0], [80.9, 292.0], [81.0, 292.0], [81.1, 293.0], [81.2, 293.0], [81.3, 293.0], [81.4, 294.0], [81.5, 294.0], [81.6, 294.0], [81.7, 295.0], [81.8, 295.0], [81.9, 295.0], [82.0, 296.0], [82.1, 296.0], [82.2, 296.0], [82.3, 297.0], [82.4, 297.0], [82.5, 297.0], [82.6, 298.0], [82.7, 298.0], [82.8, 298.0], [82.9, 299.0], [83.0, 299.0], [83.1, 299.0], [83.2, 300.0], [83.3, 300.0], [83.4, 300.0], [83.5, 301.0], [83.6, 301.0], [83.7, 301.0], [83.8, 302.0], [83.9, 302.0], [84.0, 303.0], [84.1, 303.0], [84.2, 303.0], [84.3, 304.0], [84.4, 304.0], [84.5, 304.0], [84.6, 305.0], [84.7, 305.0], [84.8, 305.0], [84.9, 306.0], [85.0, 306.0], [85.1, 307.0], [85.2, 307.0], [85.3, 307.0], [85.4, 308.0], [85.5, 308.0], [85.6, 309.0], [85.7, 309.0], [85.8, 309.0], [85.9, 310.0], [86.0, 310.0], [86.1, 310.0], [86.2, 311.0], [86.3, 311.0], [86.4, 312.0], [86.5, 312.0], [86.6, 312.0], [86.7, 313.0], [86.8, 313.0], [86.9, 314.0], [87.0, 314.0], [87.1, 314.0], [87.2, 315.0], [87.3, 315.0], [87.4, 316.0], [87.5, 316.0], [87.6, 317.0], [87.7, 317.0], [87.8, 317.0], [87.9, 318.0], [88.0, 318.0], [88.1, 319.0], [88.2, 319.0], [88.3, 320.0], [88.4, 320.0], [88.5, 321.0], [88.6, 321.0], [88.7, 321.0], [88.8, 322.0], [88.9, 322.0], [89.0, 323.0], [89.1, 323.0], [89.2, 324.0], [89.3, 324.0], [89.4, 325.0], [89.5, 325.0], [89.6, 326.0], [89.7, 326.0], [89.8, 327.0], [89.9, 327.0], [90.0, 328.0], [90.1, 328.0], [90.2, 329.0], [90.3, 329.0], [90.4, 330.0], [90.5, 330.0], [90.6, 331.0], [90.7, 331.0], [90.8, 332.0], [90.9, 333.0], [91.0, 333.0], [91.1, 334.0], [91.2, 334.0], [91.3, 335.0], [91.4, 335.0], [91.5, 336.0], [91.6, 337.0], [91.7, 337.0], [91.8, 338.0], [91.9, 338.0], [92.0, 339.0], [92.1, 340.0], [92.2, 340.0], [92.3, 341.0], [92.4, 342.0], [92.5, 342.0], [92.6, 343.0], [92.7, 344.0], [92.8, 344.0], [92.9, 345.0], [93.0, 346.0], [93.1, 346.0], [93.2, 347.0], [93.3, 348.0], [93.4, 349.0], [93.5, 349.0], [93.6, 350.0], [93.7, 351.0], [93.8, 352.0], [93.9, 352.0], [94.0, 353.0], [94.1, 354.0], [94.2, 355.0], [94.3, 356.0], [94.4, 356.0], [94.5, 357.0], [94.6, 358.0], [94.7, 359.0], [94.8, 360.0], [94.9, 361.0], [95.0, 361.0], [95.1, 362.0], [95.2, 363.0], [95.3, 364.0], [95.4, 365.0], [95.5, 366.0], [95.6, 367.0], [95.7, 368.0], [95.8, 369.0], [95.9, 370.0], [96.0, 371.0], [96.1, 372.0], [96.2, 373.0], [96.3, 375.0], [96.4, 376.0], [96.5, 377.0], [96.6, 378.0], [96.7, 379.0], [96.8, 381.0], [96.9, 382.0], [97.0, 383.0], [97.1, 385.0], [97.2, 386.0], [97.3, 387.0], [97.4, 389.0], [97.5, 390.0], [97.6, 392.0], [97.7, 394.0], [97.8, 396.0], [97.9, 398.0], [98.0, 400.0], [98.1, 402.0], [98.2, 404.0], [98.3, 406.0], [98.4, 409.0], [98.5, 412.0], [98.6, 414.0], [98.7, 417.0], [98.8, 420.0], [98.9, 424.0], [99.0, 427.0], [99.1, 431.0], [99.2, 435.0], [99.3, 440.0], [99.4, 446.0], [99.5, 453.0], [99.6, 462.0], [99.7, 473.0], [99.8, 487.0], [99.9, 510.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1026.0, "minX": 0.0, "maxY": 718974.0, "series": [{"data": [[0.0, 718974.0], [500.0, 1026.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 500, "maxX": 500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 990.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 719010.0, "series": [{"data": [[1.0, 990.0]], "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[0.0, 719010.0]], "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 174.59091803601177, "minX": 1.49576646E12, "maxY": 360.0, "series": [{"data": [[1.4957667E12, 360.0], [1.49576652E12, 356.2725641625692], [1.49576682E12, 358.9634839058738], [1.49576664E12, 360.0], [1.49576646E12, 174.84686089332445], [1.49576694E12, 174.59091803601177], [1.49576676E12, 360.0], [1.49576658E12, 360.0], [1.49576688E12, 301.01187603554223]], "isOverall": false, "label": "性能测试", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49576694E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 51.770833333333314, "minX": 1.0, "maxY": 271.63358778625974, "series": [{"data": [[2.0, 53.0], [3.0, 76.1875], [4.0, 52.55555555555556], [5.0, 52.57142857142858], [6.0, 52.9], [7.0, 58.25], [8.0, 52.37500000000001], [9.0, 51.770833333333314], [10.0, 52.53448275862069], [11.0, 52.44444444444444], [12.0, 52.25581395348838], [13.0, 52.080000000000005], [14.0, 52.5090909090909], [15.0, 52.34545454545456], [16.0, 52.68], [17.0, 52.67692307692306], [18.0, 52.42105263157895], [19.0, 52.609375], [20.0, 52.18987341772153], [21.0, 52.06060606060608], [22.0, 52.41758241758242], [23.0, 52.2621359223301], [24.0, 52.27272727272727], [25.0, 58.40740740740741], [26.0, 52.78212290502793], [27.0, 53.04819277108433], [28.0, 52.82978723404255], [29.0, 52.47999999999999], [30.0, 54.02419354838709], [31.0, 52.79797979797981], [32.0, 53.01428571428571], [33.0, 52.08411214953273], [34.0, 52.788135593220346], [35.0, 58.801652892562025], [36.0, 54.83225806451615], [37.0, 53.92682926829269], [38.0, 54.54973821989529], [39.0, 52.20491803278688], [40.0, 53.22602739726028], [41.0, 55.0246913580247], [42.0, 56.662162162162154], [43.0, 59.74301675977654], [44.0, 54.74814814814815], [45.0, 56.161764705882376], [46.0, 54.72619047619049], [47.0, 56.09137055837564], [48.0, 56.61146496815286], [49.0, 62.30666666666667], [50.0, 58.74404761904763], [51.0, 63.43424317617862], [52.0, 53.41142857142857], [53.0, 55.160194174757294], [54.0, 61.1795665634675], [55.0, 62.999999999999986], [56.0, 53.88397790055249], [57.0, 57.54585152838428], [58.0, 54.13888888888887], [59.0, 54.86403508771929], [60.0, 60.363207547169836], [61.0, 58.06787330316743], [62.0, 59.882075471698116], [63.0, 56.786516853932575], [64.0, 58.90168539325839], [65.0, 72.10743801652893], [66.0, 63.36684782608696], [67.0, 62.466237942122156], [68.0, 56.03448275862069], [69.0, 55.705645161290334], [70.0, 67.37128712871291], [71.0, 65.87619047619046], [72.0, 59.773076923076935], [73.0, 59.32642487046635], [74.0, 58.55681818181818], [75.0, 67.28723404255322], [76.0, 57.6825396825397], [77.0, 62.076246334310824], [78.0, 67.49650349650351], [79.0, 73.82608695652176], [80.0, 65.87087087087086], [81.0, 67.03580562659852], [82.0, 61.20121951219511], [83.0, 72.1408450704225], [84.0, 62.08709677419358], [85.0, 59.343065693430646], [86.0, 69.96394230769226], [87.0, 74.66996699669966], [88.0, 70.54697986577179], [89.0, 71.45214521452138], [90.0, 72.65405405405401], [91.0, 76.05726872246692], [92.0, 73.10264900662249], [93.0, 72.29729729729732], [94.0, 68.61992619926203], [95.0, 68.80597014925372], [96.0, 71.30000000000003], [97.0, 61.141868512110705], [98.0, 70.09235668789812], [99.0, 75.19946091644206], [100.0, 73.63461538461534], [101.0, 74.34117647058824], [102.0, 72.1301115241635], [103.0, 85.3008130081301], [104.0, 78.91639871382631], [105.0, 81.41379310344838], [106.0, 75.04615384615389], [107.0, 77.33647058823519], [108.0, 74.09113924050635], [109.0, 77.59405940594064], [110.0, 79.43478260869556], [111.0, 89.30837789661318], [112.0, 71.86545454545453], [113.0, 71.30812324929975], [114.0, 77.73866666666662], [115.0, 90.73708920187798], [116.0, 71.13213213213209], [117.0, 78.92156862745105], [118.0, 94.6271186440678], [119.0, 82.55112651646444], [120.0, 73.42048517520215], [121.0, 77.49353448275865], [122.0, 84.03906249999997], [123.0, 85.81006864988555], [124.0, 74.05474452554746], [125.0, 85.50793650793653], [126.0, 87.48205128205133], [127.0, 84.81681034482753], [128.0, 89.88014981273429], [129.0, 108.78518518518521], [130.0, 84.58974358974359], [131.0, 86.64117647058828], [132.0, 83.49999999999997], [133.0, 98.30746268656722], [134.0, 90.00291545189502], [135.0, 87.27761194029858], [136.0, 91.56869565217386], [137.0, 102.45244215938303], [138.0, 87.57676348547727], [139.0, 83.67889908256876], [140.0, 98.21812080536913], [141.0, 96.97416020671828], [142.0, 89.76449275362314], [143.0, 107.95538057742792], [144.0, 104.8670694864048], [145.0, 97.63833992094864], [146.0, 90.97619047619051], [147.0, 106.28782287822875], [148.0, 102.62230215827333], [149.0, 84.50453172205438], [150.0, 102.82083333333337], [151.0, 117.17454545454535], [152.0, 111.46483704974266], [153.0, 107.86407766990285], [154.0, 105.66396761133606], [155.0, 119.65840220385678], [156.0, 114.09135802469135], [157.0, 104.79508196721316], [158.0, 116.53008595988541], [159.0, 105.68345323741008], [160.0, 113.9300411522633], [161.0, 91.34999999999997], [162.0, 118.73514851485146], [163.0, 106.44557823129252], [164.0, 97.14062500000003], [165.0, 114.35426008968614], [166.0, 130.31679389312978], [167.0, 109.19533527696791], [168.0, 101.33766233766225], [169.0, 121.17979002624679], [170.0, 102.12951807228914], [171.0, 104.75700934579437], [172.0, 123.0344827586207], [173.0, 116.61147902869757], [174.0, 103.65207373271885], [175.0, 111.82296650717697], [176.0, 125.72261484098942], [177.0, 111.68705547652917], [178.0, 105.9847494553376], [179.0, 114.08583690987123], [180.0, 140.39341917024302], [181.0, 112.44479495268142], [182.0, 109.12993421052623], [183.0, 147.85100286532938], [184.0, 108.65683646112598], [185.0, 107.10632911392409], [186.0, 122.05263157894736], [187.0, 125.97777777777803], [188.0, 111.36133333333326], [189.0, 120.4154460719042], [190.0, 134.71234939759037], [191.0, 121.37547169811316], [192.0, 111.86698337292167], [193.0, 141.780185758514], [194.0, 130.4160583941606], [195.0, 121.97547974413662], [196.0, 128.12306289881496], [197.0, 139.84946236559128], [198.0, 129.65819861431885], [199.0, 128.78539823008848], [200.0, 135.7524115755627], [201.0, 149.9542682926829], [202.0, 122.06696832579182], [203.0, 132.8152424942264], [204.0, 167.5746753246754], [205.0, 122.47590361445779], [206.0, 151.9623015873016], [207.0, 146.5309523809522], [208.0, 141.71188475390173], [209.0, 151.30386740331465], [210.0, 127.60537190082644], [211.0, 128.70338983050848], [212.0, 141.85163204747778], [213.0, 125.88666666666668], [214.0, 137.32336448598136], [215.0, 148.20306513409963], [216.0, 141.34451019066378], [217.0, 139.3106382978725], [218.0, 126.65811965811965], [219.0, 167.0900000000001], [220.0, 156.86111111111123], [221.0, 128.39746835443043], [222.0, 152.28139534883712], [223.0, 147.91908975979754], [224.0, 139.99298245614034], [225.0, 133.27551020408174], [226.0, 148.56385542168695], [227.0, 160.7792915531334], [228.0, 148.94414607948448], [229.0, 149.1455479452054], [230.0, 145.8717201166181], [231.0, 162.9389978213507], [232.0, 172.59223300970862], [233.0, 158.49548872180495], [234.0, 161.03435804701616], [235.0, 203.61561264822117], [236.0, 166.0369127516778], [237.0, 152.59711075441402], [238.0, 149.62948960302458], [239.0, 170.44989339019202], [240.0, 151.55078124999997], [241.0, 170.03958333333327], [242.0, 166.62703962703932], [243.0, 154.4738955823291], [244.0, 161.2351421188633], [245.0, 187.78181818181815], [246.0, 163.0222672064778], [247.0, 163.97444633730834], [248.0, 168.0527272727272], [249.0, 163.41931684334511], [250.0, 166.9845360824743], [251.0, 156.0342555994732], [252.0, 172.9433233147274], [253.0, 168.65994962216618], [254.0, 168.99272930648812], [255.0, 189.63476562499994], [257.0, 174.02510460251042], [256.0, 188.82163742690045], [258.0, 147.89416846652279], [259.0, 172.47069597069594], [260.0, 170.60486322188447], [261.0, 192.11700468018722], [262.0, 158.9558303886926], [263.0, 170.29689521345372], [264.0, 205.53432835820894], [270.0, 180.34390415785782], [271.0, 178.5142857142857], [268.0, 188.42097701149424], [269.0, 174.40454914703471], [265.0, 175.15415821501006], [266.0, 160.59368836291918], [267.0, 174.80240320427228], [273.0, 159.95372750642665], [272.0, 185.11355311355305], [274.0, 189.3497803311932], [275.0, 181.10149942329886], [276.0, 176.29596412556046], [277.0, 191.31422390481362], [278.0, 204.53679245283027], [279.0, 176.79690949227393], [280.0, 202.5733333333334], [286.0, 190.12301587301582], [287.0, 171.78705035971234], [284.0, 184.03374777975137], [285.0, 198.59844271412695], [281.0, 194.11374407582937], [282.0, 180.2421052631579], [283.0, 201.5816733067728], [289.0, 191.89276681841142], [288.0, 187.49266144814086], [290.0, 184.71264367816102], [291.0, 183.05669199298652], [292.0, 215.83870967741944], [293.0, 185.3544999999999], [294.0, 169.4657039711192], [295.0, 183.46482122260656], [296.0, 206.89285714285705], [302.0, 201.40738668158917], [303.0, 215.0459770114942], [300.0, 197.3364520958085], [301.0, 187.08328675237541], [297.0, 194.9413202933985], [298.0, 187.6412961567447], [299.0, 206.54330708661425], [305.0, 169.12432432432422], [304.0, 211.67423789599482], [306.0, 212.182444061962], [307.0, 219.82981090100114], [308.0, 221.6253869969041], [309.0, 198.23514211886322], [310.0, 211.8929765886289], [311.0, 189.53410740203174], [312.0, 191.32527105921577], [318.0, 188.75757575757595], [319.0, 199.04938271604908], [316.0, 194.00311526479757], [317.0, 206.07439310884885], [313.0, 198.98781838316702], [314.0, 203.2531328320803], [315.0, 203.35013908205792], [321.0, 249.77283950617303], [320.0, 201.43109275253448], [322.0, 214.57310924369756], [323.0, 213.00450315220652], [324.0, 217.2007528230866], [325.0, 231.75037593984973], [326.0, 189.56962025316452], [327.0, 213.05462653288728], [328.0, 230.02112676056342], [334.0, 227.1065420560748], [335.0, 244.95417348608828], [332.0, 233.07560756075605], [333.0, 236.35928489042644], [329.0, 227.44521912350598], [330.0, 209.53313840155948], [331.0, 220.6598860862484], [337.0, 238.66554621848732], [336.0, 229.5596330275233], [338.0, 245.85990961910946], [339.0, 238.44121071012788], [340.0, 245.81308411214928], [341.0, 237.05116959064378], [342.0, 236.2884353741496], [343.0, 226.449037551278], [344.0, 271.63358778625974], [350.0, 240.23908413205538], [351.0, 245.52152765267527], [348.0, 234.10132158590295], [349.0, 247.53532608695645], [345.0, 255.69367088607595], [346.0, 241.9703703703706], [347.0, 236.27025089605735], [353.0, 223.7194244604317], [352.0, 231.1677215189875], [354.0, 231.58936484490434], [355.0, 234.95601851851833], [356.0, 229.41493383742886], [357.0, 237.83877159309026], [358.0, 222.29197761194047], [359.0, 238.1450617283952], [360.0, 248.33204391912582], [1.0, 51.8]], "isOverall": false, "label": "HTTP请求", "isController": false}, {"data": [[324.2589569444479, 222.7462916666701]], "isOverall": false, "label": "HTTP请求-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 360.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 151767.46666666667, "minX": 1.49576646E12, "maxY": 984722.55, "series": [{"data": [[1.4957667E12, 940101.3], [1.49576652E12, 982576.35], [1.49576682E12, 931089.45], [1.49576664E12, 939477.15], [1.49576646E12, 737416.8], [1.49576694E12, 445139.4], [1.49576676E12, 940046.55], [1.49576658E12, 983430.45], [1.49576688E12, 984722.55]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.4957667E12, 320521.6], [1.49576652E12, 335003.2], [1.49576682E12, 317449.06666666665], [1.49576664E12, 320308.8], [1.49576646E12, 251417.6], [1.49576694E12, 151767.46666666667], [1.49576676E12, 320502.93333333335], [1.49576658E12, 335294.4], [1.49576688E12, 335734.93333333335]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49576694E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 117.84576205749585, "minX": 1.49576646E12, "maxY": 253.4329127024263, "series": [{"data": [[1.4957667E12, 251.65416870501184], [1.49576652E12, 238.04442067021094], [1.49576682E12, 253.4329127024263], [1.49576664E12, 251.58450761681638], [1.49576646E12, 117.84576205749585], [1.49576694E12, 124.86497589294429], [1.49576676E12, 251.3877738820494], [1.49576658E12, 240.45569028292925], [1.49576688E12, 201.12924640549926]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49576694E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 117.84224281302053, "minX": 1.49576646E12, "maxY": 253.43081934823607, "series": [{"data": [[1.4957667E12, 251.651943997948], [1.49576652E12, 238.04223641246764], [1.49576682E12, 253.43081934823607], [1.49576664E12, 251.58225812091595], [1.49576646E12, 117.84224281302053], [1.49576694E12, 124.8621470038363], [1.49576676E12, 251.3857237708066], [1.49576658E12, 240.45307367694423], [1.49576688E12, 201.12702242880465]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49576694E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.03795438346400539, "minX": 1.49576646E12, "maxY": 0.07186876622870127, "series": [{"data": [[1.4957667E12, 0.06273440957905282], [1.49576652E12, 0.07186876622870127], [1.49576682E12, 0.054486010984229706], [1.49576664E12, 0.06601629427602375], [1.49576646E12, 0.03795438346400539], [1.49576694E12, 0.041449375184492626], [1.49576676E12, 0.06411256974455189], [1.49576658E12, 0.0659830087628469], [1.49576688E12, 0.061125999399526794]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49576694E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 28.0, "minX": 1.49576646E12, "maxY": 702.0, "series": [{"data": [[1.4957667E12, 702.0], [1.49576652E12, 661.0], [1.49576682E12, 645.0], [1.49576664E12, 629.0], [1.49576646E12, 530.0], [1.49576694E12, 442.0], [1.49576676E12, 589.0], [1.49576658E12, 689.0], [1.49576688E12, 573.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.4957667E12, 51.0], [1.49576652E12, 52.0], [1.49576682E12, 56.0], [1.49576664E12, 51.0], [1.49576646E12, 28.0], [1.49576694E12, 50.0], [1.49576676E12, 51.0], [1.49576658E12, 52.0], [1.49576688E12, 51.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.4957667E12, 335.0], [1.49576652E12, 320.0], [1.49576682E12, 341.0], [1.49576664E12, 364.0], [1.49576646E12, 253.0], [1.49576694E12, 150.0], [1.49576676E12, 351.0], [1.49576658E12, 321.0], [1.49576688E12, 237.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.4957667E12, 421.0], [1.49576652E12, 391.0], [1.49576682E12, 418.0], [1.49576664E12, 454.0], [1.49576646E12, 360.0], [1.49576694E12, 199.0], [1.49576676E12, 467.0], [1.49576658E12, 394.0], [1.49576688E12, 308.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.4957667E12, 364.0], [1.49576652E12, 347.0], [1.49576682E12, 371.0], [1.49576664E12, 397.0], [1.49576646E12, 279.9500000000007], [1.49576694E12, 167.0], [1.49576676E12, 388.0], [1.49576658E12, 348.0], [1.49576688E12, 260.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49576694E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 94.0, "minX": 7344.0, "maxY": 262.0, "series": [{"data": [[40652.0, 94.0], [25031.0, 241.0], [25797.0, 262.0], [25854.0, 252.0], [25849.0, 242.0], [7344.0, 172.0], [29733.0, 226.0], [29811.0, 230.0], [29929.0, 166.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 40652.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 94.0, "minX": 7344.0, "maxY": 262.0, "series": [{"data": [[40652.0, 94.0], [25031.0, 241.0], [25797.0, 262.0], [25854.0, 252.0], [25849.0, 242.0], [7344.0, 172.0], [29733.0, 226.0], [29811.0, 230.0], [29929.0, 166.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 40652.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 673.5, "minX": 1.49576646E12, "maxY": 1497.05, "series": [{"data": [[1.4957667E12, 1430.9333333333334], [1.49576652E12, 1496.4166666666667], [1.49576682E12, 1416.9833333333333], [1.49576664E12, 1429.9166666666667], [1.49576646E12, 1127.5333333333333], [1.49576694E12, 673.5], [1.49576676E12, 1430.8166666666666], [1.49576658E12, 1496.85], [1.49576688E12, 1497.05]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49576694E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 677.5333333333333, "minX": 1.49576646E12, "maxY": 1498.8166666666666, "series": [{"data": [[1.4957667E12, 1430.9], [1.49576652E12, 1495.55], [1.49576682E12, 1417.1833333333334], [1.49576664E12, 1429.95], [1.49576646E12, 1122.4], [1.49576694E12, 677.5333333333333], [1.49576676E12, 1430.8166666666666], [1.49576658E12, 1496.85], [1.49576688E12, 1498.8166666666666]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49576694E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 677.5333333333333, "minX": 1.49576646E12, "maxY": 1498.8166666666666, "series": [{"data": [[1.4957667E12, 1430.9], [1.49576652E12, 1495.55], [1.49576682E12, 1417.1833333333334], [1.49576664E12, 1429.95], [1.49576646E12, 1122.4], [1.49576694E12, 677.5333333333333], [1.49576676E12, 1430.8166666666666], [1.49576658E12, 1496.85], [1.49576688E12, 1498.8166666666666]], "isOverall": false, "label": "HTTP请求-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49576694E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
