/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 0 : 0;
        var yOffset = options.yaxis.mode === "time" ? 0 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 12.0, "minX": 0.0, "maxY": 10524.0, "series": [{"data": [[0.0, 12.0], [0.1, 30.0], [0.2, 34.0], [0.3, 39.0], [0.4, 44.0], [0.5, 49.0], [0.6, 51.0], [0.7, 52.0], [0.8, 52.0], [0.9, 52.0], [1.0, 52.0], [1.1, 53.0], [1.2, 53.0], [1.3, 53.0], [1.4, 53.0], [1.5, 53.0], [1.6, 53.0], [1.7, 54.0], [1.8, 54.0], [1.9, 54.0], [2.0, 54.0], [2.1, 54.0], [2.2, 55.0], [2.3, 55.0], [2.4, 55.0], [2.5, 56.0], [2.6, 56.0], [2.7, 56.0], [2.8, 56.0], [2.9, 57.0], [3.0, 57.0], [3.1, 57.0], [3.2, 58.0], [3.3, 58.0], [3.4, 58.0], [3.5, 59.0], [3.6, 59.0], [3.7, 59.0], [3.8, 60.0], [3.9, 60.0], [4.0, 60.0], [4.1, 61.0], [4.2, 61.0], [4.3, 62.0], [4.4, 62.0], [4.5, 62.0], [4.6, 63.0], [4.7, 63.0], [4.8, 63.0], [4.9, 64.0], [5.0, 64.0], [5.1, 64.0], [5.2, 65.0], [5.3, 65.0], [5.4, 66.0], [5.5, 66.0], [5.6, 66.0], [5.7, 67.0], [5.8, 67.0], [5.9, 67.0], [6.0, 68.0], [6.1, 68.0], [6.2, 69.0], [6.3, 69.0], [6.4, 69.0], [6.5, 70.0], [6.6, 70.0], [6.7, 71.0], [6.8, 71.0], [6.9, 71.0], [7.0, 72.0], [7.1, 72.0], [7.2, 73.0], [7.3, 73.0], [7.4, 73.0], [7.5, 74.0], [7.6, 74.0], [7.7, 75.0], [7.8, 75.0], [7.9, 75.0], [8.0, 76.0], [8.1, 76.0], [8.2, 77.0], [8.3, 77.0], [8.4, 77.0], [8.5, 78.0], [8.6, 78.0], [8.7, 78.0], [8.8, 79.0], [8.9, 79.0], [9.0, 79.0], [9.1, 80.0], [9.2, 80.0], [9.3, 80.0], [9.4, 80.0], [9.5, 81.0], [9.6, 81.0], [9.7, 81.0], [9.8, 82.0], [9.9, 82.0], [10.0, 82.0], [10.1, 83.0], [10.2, 83.0], [10.3, 83.0], [10.4, 84.0], [10.5, 84.0], [10.6, 84.0], [10.7, 84.0], [10.8, 85.0], [10.9, 85.0], [11.0, 85.0], [11.1, 86.0], [11.2, 86.0], [11.3, 86.0], [11.4, 87.0], [11.5, 87.0], [11.6, 87.0], [11.7, 88.0], [11.8, 88.0], [11.9, 88.0], [12.0, 88.0], [12.1, 89.0], [12.2, 89.0], [12.3, 89.0], [12.4, 90.0], [12.5, 90.0], [12.6, 90.0], [12.7, 91.0], [12.8, 91.0], [12.9, 91.0], [13.0, 92.0], [13.1, 92.0], [13.2, 92.0], [13.3, 93.0], [13.4, 93.0], [13.5, 93.0], [13.6, 93.0], [13.7, 94.0], [13.8, 94.0], [13.9, 94.0], [14.0, 95.0], [14.1, 95.0], [14.2, 95.0], [14.3, 96.0], [14.4, 96.0], [14.5, 96.0], [14.6, 97.0], [14.7, 97.0], [14.8, 97.0], [14.9, 98.0], [15.0, 98.0], [15.1, 98.0], [15.2, 98.0], [15.3, 99.0], [15.4, 99.0], [15.5, 99.0], [15.6, 100.0], [15.7, 100.0], [15.8, 100.0], [15.9, 101.0], [16.0, 101.0], [16.1, 101.0], [16.2, 102.0], [16.3, 102.0], [16.4, 102.0], [16.5, 103.0], [16.6, 103.0], [16.7, 103.0], [16.8, 103.0], [16.9, 104.0], [17.0, 104.0], [17.1, 104.0], [17.2, 104.0], [17.3, 105.0], [17.4, 105.0], [17.5, 105.0], [17.6, 106.0], [17.7, 106.0], [17.8, 106.0], [17.9, 106.0], [18.0, 107.0], [18.1, 107.0], [18.2, 107.0], [18.3, 107.0], [18.4, 108.0], [18.5, 108.0], [18.6, 108.0], [18.7, 108.0], [18.8, 109.0], [18.9, 109.0], [19.0, 109.0], [19.1, 110.0], [19.2, 110.0], [19.3, 110.0], [19.4, 110.0], [19.5, 111.0], [19.6, 111.0], [19.7, 111.0], [19.8, 111.0], [19.9, 112.0], [20.0, 112.0], [20.1, 112.0], [20.2, 112.0], [20.3, 113.0], [20.4, 113.0], [20.5, 113.0], [20.6, 113.0], [20.7, 114.0], [20.8, 114.0], [20.9, 114.0], [21.0, 114.0], [21.1, 115.0], [21.2, 115.0], [21.3, 115.0], [21.4, 115.0], [21.5, 116.0], [21.6, 116.0], [21.7, 116.0], [21.8, 117.0], [21.9, 117.0], [22.0, 117.0], [22.1, 117.0], [22.2, 118.0], [22.3, 118.0], [22.4, 118.0], [22.5, 118.0], [22.6, 119.0], [22.7, 119.0], [22.8, 119.0], [22.9, 119.0], [23.0, 120.0], [23.1, 120.0], [23.2, 120.0], [23.3, 120.0], [23.4, 121.0], [23.5, 121.0], [23.6, 121.0], [23.7, 121.0], [23.8, 122.0], [23.9, 122.0], [24.0, 122.0], [24.1, 123.0], [24.2, 123.0], [24.3, 123.0], [24.4, 123.0], [24.5, 124.0], [24.6, 124.0], [24.7, 124.0], [24.8, 124.0], [24.9, 125.0], [25.0, 125.0], [25.1, 125.0], [25.2, 126.0], [25.3, 126.0], [25.4, 126.0], [25.5, 126.0], [25.6, 127.0], [25.7, 127.0], [25.8, 127.0], [25.9, 127.0], [26.0, 128.0], [26.1, 128.0], [26.2, 128.0], [26.3, 129.0], [26.4, 129.0], [26.5, 129.0], [26.6, 129.0], [26.7, 130.0], [26.8, 130.0], [26.9, 130.0], [27.0, 130.0], [27.1, 131.0], [27.2, 131.0], [27.3, 131.0], [27.4, 131.0], [27.5, 132.0], [27.6, 132.0], [27.7, 132.0], [27.8, 132.0], [27.9, 133.0], [28.0, 133.0], [28.1, 133.0], [28.2, 133.0], [28.3, 134.0], [28.4, 134.0], [28.5, 134.0], [28.6, 134.0], [28.7, 135.0], [28.8, 135.0], [28.9, 135.0], [29.0, 135.0], [29.1, 136.0], [29.2, 136.0], [29.3, 136.0], [29.4, 136.0], [29.5, 137.0], [29.6, 137.0], [29.7, 137.0], [29.8, 137.0], [29.9, 138.0], [30.0, 138.0], [30.1, 138.0], [30.2, 138.0], [30.3, 139.0], [30.4, 139.0], [30.5, 139.0], [30.6, 139.0], [30.7, 140.0], [30.8, 140.0], [30.9, 140.0], [31.0, 140.0], [31.1, 141.0], [31.2, 141.0], [31.3, 141.0], [31.4, 141.0], [31.5, 142.0], [31.6, 142.0], [31.7, 142.0], [31.8, 142.0], [31.9, 143.0], [32.0, 143.0], [32.1, 143.0], [32.2, 143.0], [32.3, 144.0], [32.4, 144.0], [32.5, 144.0], [32.6, 144.0], [32.7, 145.0], [32.8, 145.0], [32.9, 145.0], [33.0, 145.0], [33.1, 146.0], [33.2, 146.0], [33.3, 146.0], [33.4, 146.0], [33.5, 147.0], [33.6, 147.0], [33.7, 147.0], [33.8, 147.0], [33.9, 148.0], [34.0, 148.0], [34.1, 148.0], [34.2, 148.0], [34.3, 149.0], [34.4, 149.0], [34.5, 149.0], [34.6, 150.0], [34.7, 150.0], [34.8, 150.0], [34.9, 150.0], [35.0, 151.0], [35.1, 151.0], [35.2, 151.0], [35.3, 151.0], [35.4, 152.0], [35.5, 152.0], [35.6, 152.0], [35.7, 152.0], [35.8, 153.0], [35.9, 153.0], [36.0, 153.0], [36.1, 153.0], [36.2, 154.0], [36.3, 154.0], [36.4, 154.0], [36.5, 154.0], [36.6, 155.0], [36.7, 155.0], [36.8, 155.0], [36.9, 155.0], [37.0, 156.0], [37.1, 156.0], [37.2, 156.0], [37.3, 157.0], [37.4, 157.0], [37.5, 157.0], [37.6, 157.0], [37.7, 158.0], [37.8, 158.0], [37.9, 158.0], [38.0, 158.0], [38.1, 159.0], [38.2, 159.0], [38.3, 159.0], [38.4, 159.0], [38.5, 160.0], [38.6, 160.0], [38.7, 160.0], [38.8, 160.0], [38.9, 161.0], [39.0, 161.0], [39.1, 161.0], [39.2, 161.0], [39.3, 162.0], [39.4, 162.0], [39.5, 162.0], [39.6, 162.0], [39.7, 163.0], [39.8, 163.0], [39.9, 163.0], [40.0, 164.0], [40.1, 164.0], [40.2, 164.0], [40.3, 164.0], [40.4, 165.0], [40.5, 165.0], [40.6, 165.0], [40.7, 165.0], [40.8, 166.0], [40.9, 166.0], [41.0, 166.0], [41.1, 166.0], [41.2, 167.0], [41.3, 167.0], [41.4, 167.0], [41.5, 167.0], [41.6, 168.0], [41.7, 168.0], [41.8, 168.0], [41.9, 169.0], [42.0, 169.0], [42.1, 169.0], [42.2, 169.0], [42.3, 170.0], [42.4, 170.0], [42.5, 170.0], [42.6, 170.0], [42.7, 171.0], [42.8, 171.0], [42.9, 171.0], [43.0, 171.0], [43.1, 172.0], [43.2, 172.0], [43.3, 172.0], [43.4, 172.0], [43.5, 173.0], [43.6, 173.0], [43.7, 173.0], [43.8, 174.0], [43.9, 174.0], [44.0, 174.0], [44.1, 174.0], [44.2, 175.0], [44.3, 175.0], [44.4, 175.0], [44.5, 175.0], [44.6, 176.0], [44.7, 176.0], [44.8, 176.0], [44.9, 176.0], [45.0, 177.0], [45.1, 177.0], [45.2, 177.0], [45.3, 178.0], [45.4, 178.0], [45.5, 178.0], [45.6, 178.0], [45.7, 179.0], [45.8, 179.0], [45.9, 179.0], [46.0, 179.0], [46.1, 180.0], [46.2, 180.0], [46.3, 180.0], [46.4, 180.0], [46.5, 181.0], [46.6, 181.0], [46.7, 181.0], [46.8, 182.0], [46.9, 182.0], [47.0, 182.0], [47.1, 182.0], [47.2, 183.0], [47.3, 183.0], [47.4, 183.0], [47.5, 183.0], [47.6, 184.0], [47.7, 184.0], [47.8, 184.0], [47.9, 185.0], [48.0, 185.0], [48.1, 185.0], [48.2, 185.0], [48.3, 186.0], [48.4, 186.0], [48.5, 186.0], [48.6, 187.0], [48.7, 187.0], [48.8, 187.0], [48.9, 187.0], [49.0, 188.0], [49.1, 188.0], [49.2, 188.0], [49.3, 188.0], [49.4, 189.0], [49.5, 189.0], [49.6, 189.0], [49.7, 190.0], [49.8, 190.0], [49.9, 190.0], [50.0, 190.0], [50.1, 191.0], [50.2, 191.0], [50.3, 191.0], [50.4, 192.0], [50.5, 192.0], [50.6, 192.0], [50.7, 192.0], [50.8, 193.0], [50.9, 193.0], [51.0, 193.0], [51.1, 194.0], [51.2, 194.0], [51.3, 194.0], [51.4, 194.0], [51.5, 195.0], [51.6, 195.0], [51.7, 195.0], [51.8, 196.0], [51.9, 196.0], [52.0, 196.0], [52.1, 196.0], [52.2, 197.0], [52.3, 197.0], [52.4, 197.0], [52.5, 198.0], [52.6, 198.0], [52.7, 198.0], [52.8, 198.0], [52.9, 199.0], [53.0, 199.0], [53.1, 199.0], [53.2, 200.0], [53.3, 200.0], [53.4, 200.0], [53.5, 200.0], [53.6, 201.0], [53.7, 201.0], [53.8, 201.0], [53.9, 202.0], [54.0, 202.0], [54.1, 202.0], [54.2, 203.0], [54.3, 203.0], [54.4, 203.0], [54.5, 203.0], [54.6, 204.0], [54.7, 204.0], [54.8, 204.0], [54.9, 205.0], [55.0, 205.0], [55.1, 205.0], [55.2, 206.0], [55.3, 206.0], [55.4, 206.0], [55.5, 206.0], [55.6, 207.0], [55.7, 207.0], [55.8, 207.0], [55.9, 208.0], [56.0, 208.0], [56.1, 208.0], [56.2, 209.0], [56.3, 209.0], [56.4, 209.0], [56.5, 209.0], [56.6, 210.0], [56.7, 210.0], [56.8, 210.0], [56.9, 211.0], [57.0, 211.0], [57.1, 211.0], [57.2, 212.0], [57.3, 212.0], [57.4, 212.0], [57.5, 212.0], [57.6, 213.0], [57.7, 213.0], [57.8, 213.0], [57.9, 214.0], [58.0, 214.0], [58.1, 214.0], [58.2, 215.0], [58.3, 215.0], [58.4, 215.0], [58.5, 215.0], [58.6, 216.0], [58.7, 216.0], [58.8, 216.0], [58.9, 217.0], [59.0, 217.0], [59.1, 217.0], [59.2, 218.0], [59.3, 218.0], [59.4, 218.0], [59.5, 219.0], [59.6, 219.0], [59.7, 219.0], [59.8, 219.0], [59.9, 220.0], [60.0, 220.0], [60.1, 220.0], [60.2, 221.0], [60.3, 221.0], [60.4, 221.0], [60.5, 222.0], [60.6, 222.0], [60.7, 222.0], [60.8, 223.0], [60.9, 223.0], [61.0, 223.0], [61.1, 224.0], [61.2, 224.0], [61.3, 224.0], [61.4, 225.0], [61.5, 225.0], [61.6, 225.0], [61.7, 226.0], [61.8, 226.0], [61.9, 226.0], [62.0, 227.0], [62.1, 227.0], [62.2, 227.0], [62.3, 228.0], [62.4, 228.0], [62.5, 228.0], [62.6, 229.0], [62.7, 229.0], [62.8, 229.0], [62.9, 230.0], [63.0, 230.0], [63.1, 230.0], [63.2, 231.0], [63.3, 231.0], [63.4, 231.0], [63.5, 232.0], [63.6, 232.0], [63.7, 232.0], [63.8, 233.0], [63.9, 233.0], [64.0, 233.0], [64.1, 234.0], [64.2, 234.0], [64.3, 234.0], [64.4, 235.0], [64.5, 235.0], [64.6, 235.0], [64.7, 236.0], [64.8, 236.0], [64.9, 236.0], [65.0, 237.0], [65.1, 237.0], [65.2, 237.0], [65.3, 238.0], [65.4, 238.0], [65.5, 239.0], [65.6, 239.0], [65.7, 239.0], [65.8, 240.0], [65.9, 240.0], [66.0, 240.0], [66.1, 241.0], [66.2, 241.0], [66.3, 241.0], [66.4, 242.0], [66.5, 242.0], [66.6, 242.0], [66.7, 243.0], [66.8, 243.0], [66.9, 243.0], [67.0, 244.0], [67.1, 244.0], [67.2, 245.0], [67.3, 245.0], [67.4, 245.0], [67.5, 246.0], [67.6, 246.0], [67.7, 246.0], [67.8, 247.0], [67.9, 247.0], [68.0, 247.0], [68.1, 248.0], [68.2, 248.0], [68.3, 249.0], [68.4, 249.0], [68.5, 249.0], [68.6, 250.0], [68.7, 250.0], [68.8, 250.0], [68.9, 251.0], [69.0, 251.0], [69.1, 252.0], [69.2, 252.0], [69.3, 252.0], [69.4, 253.0], [69.5, 253.0], [69.6, 253.0], [69.7, 254.0], [69.8, 254.0], [69.9, 255.0], [70.0, 255.0], [70.1, 255.0], [70.2, 256.0], [70.3, 256.0], [70.4, 257.0], [70.5, 257.0], [70.6, 257.0], [70.7, 258.0], [70.8, 258.0], [70.9, 259.0], [71.0, 259.0], [71.1, 259.0], [71.2, 260.0], [71.3, 260.0], [71.4, 261.0], [71.5, 261.0], [71.6, 261.0], [71.7, 262.0], [71.8, 262.0], [71.9, 262.0], [72.0, 263.0], [72.1, 263.0], [72.2, 264.0], [72.3, 264.0], [72.4, 265.0], [72.5, 265.0], [72.6, 265.0], [72.7, 266.0], [72.8, 266.0], [72.9, 267.0], [73.0, 267.0], [73.1, 267.0], [73.2, 268.0], [73.3, 268.0], [73.4, 269.0], [73.5, 269.0], [73.6, 270.0], [73.7, 270.0], [73.8, 270.0], [73.9, 271.0], [74.0, 271.0], [74.1, 272.0], [74.2, 272.0], [74.3, 273.0], [74.4, 273.0], [74.5, 274.0], [74.6, 274.0], [74.7, 274.0], [74.8, 275.0], [74.9, 275.0], [75.0, 276.0], [75.1, 276.0], [75.2, 277.0], [75.3, 277.0], [75.4, 278.0], [75.5, 278.0], [75.6, 279.0], [75.7, 279.0], [75.8, 280.0], [75.9, 280.0], [76.0, 280.0], [76.1, 281.0], [76.2, 281.0], [76.3, 282.0], [76.4, 282.0], [76.5, 283.0], [76.6, 283.0], [76.7, 284.0], [76.8, 284.0], [76.9, 285.0], [77.0, 285.0], [77.1, 286.0], [77.2, 286.0], [77.3, 287.0], [77.4, 287.0], [77.5, 288.0], [77.6, 288.0], [77.7, 289.0], [77.8, 289.0], [77.9, 290.0], [78.0, 290.0], [78.1, 290.0], [78.2, 291.0], [78.3, 291.0], [78.4, 292.0], [78.5, 292.0], [78.6, 293.0], [78.7, 293.0], [78.8, 294.0], [78.9, 295.0], [79.0, 295.0], [79.1, 296.0], [79.2, 296.0], [79.3, 297.0], [79.4, 297.0], [79.5, 298.0], [79.6, 298.0], [79.7, 299.0], [79.8, 299.0], [79.9, 300.0], [80.0, 300.0], [80.1, 301.0], [80.2, 301.0], [80.3, 302.0], [80.4, 302.0], [80.5, 303.0], [80.6, 303.0], [80.7, 304.0], [80.8, 304.0], [80.9, 305.0], [81.0, 306.0], [81.1, 306.0], [81.2, 307.0], [81.3, 307.0], [81.4, 308.0], [81.5, 308.0], [81.6, 309.0], [81.7, 309.0], [81.8, 310.0], [81.9, 311.0], [82.0, 311.0], [82.1, 312.0], [82.2, 312.0], [82.3, 313.0], [82.4, 313.0], [82.5, 314.0], [82.6, 315.0], [82.7, 315.0], [82.8, 316.0], [82.9, 316.0], [83.0, 317.0], [83.1, 318.0], [83.2, 318.0], [83.3, 319.0], [83.4, 319.0], [83.5, 320.0], [83.6, 321.0], [83.7, 321.0], [83.8, 322.0], [83.9, 322.0], [84.0, 323.0], [84.1, 324.0], [84.2, 324.0], [84.3, 325.0], [84.4, 326.0], [84.5, 326.0], [84.6, 327.0], [84.7, 327.0], [84.8, 328.0], [84.9, 329.0], [85.0, 329.0], [85.1, 330.0], [85.2, 331.0], [85.3, 331.0], [85.4, 332.0], [85.5, 333.0], [85.6, 333.0], [85.7, 334.0], [85.8, 335.0], [85.9, 335.0], [86.0, 336.0], [86.1, 337.0], [86.2, 337.0], [86.3, 338.0], [86.4, 339.0], [86.5, 339.0], [86.6, 340.0], [86.7, 341.0], [86.8, 342.0], [86.9, 342.0], [87.0, 343.0], [87.1, 344.0], [87.2, 344.0], [87.3, 345.0], [87.4, 346.0], [87.5, 347.0], [87.6, 347.0], [87.7, 348.0], [87.8, 349.0], [87.9, 350.0], [88.0, 350.0], [88.1, 351.0], [88.2, 352.0], [88.3, 353.0], [88.4, 354.0], [88.5, 354.0], [88.6, 355.0], [88.7, 356.0], [88.8, 357.0], [88.9, 358.0], [89.0, 359.0], [89.1, 359.0], [89.2, 360.0], [89.3, 361.0], [89.4, 362.0], [89.5, 363.0], [89.6, 364.0], [89.7, 365.0], [89.8, 366.0], [89.9, 366.0], [90.0, 367.0], [90.1, 368.0], [90.2, 369.0], [90.3, 370.0], [90.4, 371.0], [90.5, 372.0], [90.6, 373.0], [90.7, 374.0], [90.8, 375.0], [90.9, 376.0], [91.0, 377.0], [91.1, 378.0], [91.2, 379.0], [91.3, 380.0], [91.4, 381.0], [91.5, 382.0], [91.6, 383.0], [91.7, 384.0], [91.8, 385.0], [91.9, 386.0], [92.0, 387.0], [92.1, 389.0], [92.2, 390.0], [92.3, 391.0], [92.4, 392.0], [92.5, 393.0], [92.6, 394.0], [92.7, 396.0], [92.8, 397.0], [92.9, 398.0], [93.0, 399.0], [93.1, 400.0], [93.2, 402.0], [93.3, 403.0], [93.4, 404.0], [93.5, 406.0], [93.6, 407.0], [93.7, 409.0], [93.8, 410.0], [93.9, 411.0], [94.0, 413.0], [94.1, 414.0], [94.2, 416.0], [94.3, 417.0], [94.4, 419.0], [94.5, 420.0], [94.6, 422.0], [94.7, 424.0], [94.8, 425.0], [94.9, 427.0], [95.0, 428.0], [95.1, 430.0], [95.2, 432.0], [95.3, 434.0], [95.4, 436.0], [95.5, 438.0], [95.6, 440.0], [95.7, 442.0], [95.8, 444.0], [95.9, 446.0], [96.0, 448.0], [96.1, 450.0], [96.2, 452.0], [96.3, 454.0], [96.4, 457.0], [96.5, 459.0], [96.6, 462.0], [96.7, 464.0], [96.8, 467.0], [96.9, 469.0], [97.0, 472.0], [97.1, 475.0], [97.2, 478.0], [97.3, 481.0], [97.4, 484.0], [97.5, 487.0], [97.6, 491.0], [97.7, 494.0], [97.8, 498.0], [97.9, 502.0], [98.0, 506.0], [98.1, 510.0], [98.2, 515.0], [98.3, 520.0], [98.4, 525.0], [98.5, 530.0], [98.6, 535.0], [98.7, 542.0], [98.8, 548.0], [98.9, 555.0], [99.0, 563.0], [99.1, 572.0], [99.2, 582.0], [99.3, 595.0], [99.4, 608.0], [99.5, 623.0], [99.6, 644.0], [99.7, 667.0], [99.8, 700.0], [99.9, 764.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 4.0, "minX": 0.0, "maxY": 880528.0, "series": [{"data": [[0.0, 880528.0], [10000.0, 10.0], [10500.0, 4.0], [500.0, 19360.0], [1000.0, 98.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 500, "maxX": 10500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 4.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 880746.0, "series": [{"data": [[1.0, 19240.0]], "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[3.0, 4.0]], "isOverall": false, "label": "Requests in error", "isController": false}, {"data": [[0.0, 880746.0]], "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[2.0, 10.0]], "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 194.06929347826093, "minX": 1.49380548E12, "maxY": 600.0, "series": [{"data": [[1.49380584E12, 332.7054279026312], [1.49380554E12, 534.2863320942572], [1.49380572E12, 600.0], [1.4938056E12, 600.0], [1.49380548E12, 194.06929347826093], [1.49380578E12, 540.6693472661843], [1.49380566E12, 600.0]], "isOverall": false, "label": "性能测试", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380584E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 42.55555555555556, "minX": 1.0, "maxY": 325.0582278481013, "series": [{"data": [[2.0, 53.75], [3.0, 50.75675675675675], [4.0, 52.666666666666664], [5.0, 42.55555555555556], [6.0, 52.0], [7.0, 53.25], [8.0, 114.75], [9.0, 52.709677419354826], [10.0, 61.68181818181817], [11.0, 51.83333333333333], [12.0, 51.1111111111111], [13.0, 54.51612903225807], [14.0, 52.11320754716982], [15.0, 51.71428571428571], [16.0, 52.63333333333333], [17.0, 51.92307692307692], [18.0, 52.553571428571416], [19.0, 53.477611940298495], [20.0, 53.229166666666664], [21.0, 52.520547945205486], [22.0, 55.47435897435897], [23.0, 53.673913043478265], [24.0, 52.72857142857143], [25.0, 55.510204081632644], [26.0, 52.23655913978495], [27.0, 54.21153846153847], [28.0, 50.23255813953488], [29.0, 51.18309859154929], [30.0, 52.21126760563379], [31.0, 51.74626865671641], [32.0, 52.43478260869567], [33.0, 51.68999999999997], [34.0, 51.668639053254445], [35.0, 51.6090909090909], [36.0, 52.50666666666668], [37.0, 53.38888888888889], [38.0, 51.81481481481482], [39.0, 49.970873786407765], [40.0, 52.87037037037037], [41.0, 50.10169491525422], [42.0, 56.061224489795904], [43.0, 51.85567010309279], [44.0, 52.09734513274336], [45.0, 52.104166666666686], [46.0, 52.48484848484848], [47.0, 52.5287356321839], [48.0, 52.70967741935484], [49.0, 133.25641025641028], [50.0, 96.52631578947368], [51.0, 54.72340425531915], [52.0, 52.44444444444445], [53.0, 54.28235294117647], [54.0, 52.157024793388445], [55.0, 58.2016806722689], [56.0, 52.97087378640778], [57.0, 50.643274853801174], [58.0, 51.77391304347827], [59.0, 54.740458015267194], [60.0, 55.25], [61.0, 51.68444444444443], [62.0, 52.25547445255474], [63.0, 50.06572769953053], [64.0, 50.94972067039107], [65.0, 59.05594405594407], [66.0, 57.02890173410405], [67.0, 53.30666666666666], [68.0, 50.10526315789472], [69.0, 51.93827160493828], [70.0, 51.574193548387115], [71.0, 50.101265822784825], [72.0, 50.76027397260273], [73.0, 52.428571428571395], [74.0, 53.83030303030305], [75.0, 53.56647398843933], [76.0, 54.85786802030458], [77.0, 57.24814814814815], [78.0, 69.2058823529412], [79.0, 55.52150537634411], [80.0, 55.840659340659336], [81.0, 56.72602739726027], [82.0, 54.834532374100746], [83.0, 57.3427561837456], [84.0, 52.830917874396135], [85.0, 52.04060913705585], [86.0, 50.37563451776652], [87.0, 80.06521739130436], [88.0, 67.37885462555069], [89.0, 52.101190476190496], [90.0, 54.29896907216494], [91.0, 56.1212121212121], [92.0, 56.13596491228073], [93.0, 58.86245353159852], [94.0, 55.452173913043495], [95.0, 57.687179487179506], [96.0, 64.45771144278608], [97.0, 57.79126213592233], [98.0, 56.48821548821551], [99.0, 56.98437499999999], [100.0, 57.52895752895751], [101.0, 53.769911504424776], [102.0, 55.23706896551721], [103.0, 53.490654205607484], [104.0, 65.74100719424463], [105.0, 69.45283018867924], [106.0, 62.392452830188645], [107.0, 61.02941176470587], [108.0, 65.61578947368425], [109.0, 58.38073394495414], [110.0, 65.1404255319149], [111.0, 57.5811688311688], [112.0, 70.59523809523812], [113.0, 65.4549356223176], [114.0, 67.6793103448276], [115.0, 114.15887850467294], [116.0, 65.48], [117.0, 56.01639344262296], [118.0, 63.26404494382021], [119.0, 63.185654008438775], [120.0, 54.33333333333335], [121.0, 58.86320754716983], [122.0, 69.45041322314054], [123.0, 63.144859813084125], [124.0, 62.88429752066116], [125.0, 61.74909090909091], [126.0, 67.91052631578953], [127.0, 69.23886639676115], [128.0, 61.141818181818216], [129.0, 53.632124352331566], [130.0, 74.72203389830509], [131.0, 61.970464135021075], [132.0, 76.62886597938142], [133.0, 63.08974358974353], [134.0, 57.77821011673153], [135.0, 62.63470319634705], [136.0, 69.3008849557522], [137.0, 61.57718120805366], [138.0, 64.57416267942581], [139.0, 97.90090090090092], [140.0, 64.77454545454546], [141.0, 80.30413625304142], [142.0, 69.93103448275856], [143.0, 63.48688046647229], [144.0, 65.54499999999997], [145.0, 81.52059925093639], [146.0, 76.08540925266904], [147.0, 67.93867924528307], [148.0, 63.54222222222225], [149.0, 59.68401486988846], [150.0, 63.27758007117438], [151.0, 75.35598705501623], [152.0, 65.05204460966543], [153.0, 71.2402234636871], [154.0, 83.45412844036697], [155.0, 75.26476578411408], [156.0, 59.70234113712374], [157.0, 80.87687687687692], [158.0, 64.47037037037038], [159.0, 100.02863436123347], [160.0, 97.64206642066428], [161.0, 102.42608695652177], [162.0, 80.23383084577108], [163.0, 68.9591078066915], [164.0, 79.10480349344982], [165.0, 83.44179894179888], [166.0, 73.61313868613139], [167.0, 75.73684210526316], [168.0, 81.63207547169809], [169.0, 78.60753880266077], [170.0, 81.24137931034477], [171.0, 71.0751173708921], [172.0, 90.02555910543133], [173.0, 83.99288256227759], [174.0, 69.74253731343289], [175.0, 68.32752613240419], [176.0, 68.02346041055718], [177.0, 74.64999999999999], [178.0, 68.9273182957394], [179.0, 73.9541666666667], [180.0, 85.87686567164178], [181.0, 88.15774647887325], [182.0, 113.26382978723404], [183.0, 89.26148409894002], [184.0, 82.99635036496348], [185.0, 93.70645161290321], [186.0, 86.61237785016284], [187.0, 68.81841432225063], [188.0, 82.28712871287121], [189.0, 78.30386740331495], [190.0, 79.76880222841218], [191.0, 77.41017964071852], [192.0, 78.8605388272584], [193.0, 113.8847305389222], [194.0, 86.84722222222229], [195.0, 115.19767441860463], [196.0, 106.13372093023258], [197.0, 111.89895470383273], [198.0, 101.57352941176468], [199.0, 111.25901639344255], [200.0, 88.2088452088452], [201.0, 90.88750000000002], [202.0, 87.67407407407404], [203.0, 92.05890227576984], [204.0, 115.29946524064171], [205.0, 127.47999999999995], [206.0, 133.31428571428577], [207.0, 113.63913043478266], [208.0, 144.65037593984968], [209.0, 98.14583333333336], [210.0, 96.41448692152922], [211.0, 91.93513513513507], [212.0, 96.23809523809521], [213.0, 79.53984575835483], [214.0, 86.8053691275168], [215.0, 100.3278008298755], [216.0, 99.15763546798033], [217.0, 102.96902654867262], [218.0, 107.28749999999998], [219.0, 100.47341337907385], [220.0, 89.14754098360653], [221.0, 98.09333333333339], [222.0, 102.32894736842107], [223.0, 93.94306049822062], [224.0, 75.80130293159617], [225.0, 126.62171052631578], [226.0, 96.30623818525524], [227.0, 88.0759075907591], [228.0, 143.43859649122808], [229.0, 96.95860284605426], [230.0, 110.92733017377559], [231.0, 98.28571428571426], [232.0, 107.06529209621986], [233.0, 102.14444444444445], [234.0, 85.48543689320398], [235.0, 76.46813186813185], [236.0, 104.24369747899155], [237.0, 109.27112676056332], [238.0, 94.26048565121405], [239.0, 92.18143459915612], [240.0, 79.41805225653209], [241.0, 86.59523809523807], [242.0, 107.77936962750722], [243.0, 89.26007326007328], [244.0, 106.07571801566576], [245.0, 126.56034482758625], [246.0, 130.3216783216783], [247.0, 106.80456852791878], [248.0, 123.43103448275869], [249.0, 104.84171597633141], [250.0, 73.49999999999999], [251.0, 103.8115942028986], [252.0, 108.35795454545453], [253.0, 117.45992366412219], [254.0, 117.80174291938995], [255.0, 90.81868131868136], [257.0, 129.95275590551165], [256.0, 117.07037037037043], [258.0, 134.96238244514112], [259.0, 119.00948766603415], [260.0, 110.44717444717452], [261.0, 108.04672897196261], [262.0, 132.50851063829793], [263.0, 114.05913978494627], [264.0, 111.76285240464347], [270.0, 130.38139534883726], [271.0, 160.08494208494216], [268.0, 154.27731092436971], [269.0, 145.3322147651007], [265.0, 100.18181818181817], [266.0, 94.05431309904156], [267.0, 111.1686460807601], [273.0, 93.20451693851943], [272.0, 121.24528301886794], [274.0, 82.69981916817348], [275.0, 88.68181818181816], [276.0, 89.62190812720853], [277.0, 96.11821974965235], [278.0, 98.71243523316062], [279.0, 131.4465617232808], [280.0, 131.23393316195373], [286.0, 127.2385892116183], [287.0, 122.59459459459455], [284.0, 149.67236467236458], [285.0, 131.70332480818425], [281.0, 126.20088626292458], [282.0, 103.32374100719429], [283.0, 118.65151515151518], [289.0, 108.44082840236688], [288.0, 142.50694444444443], [290.0, 117.79435483870964], [291.0, 116.1533477321814], [292.0, 113.45762711864408], [293.0, 111.98347107438008], [294.0, 121.73076923076917], [295.0, 108.94510739856801], [296.0, 101.8664047151277], [302.0, 134.16260162601614], [303.0, 126.72504708097927], [300.0, 109.71120689655173], [301.0, 102.04322200392922], [297.0, 108.82531645569614], [298.0, 107.63888888888887], [299.0, 114.06487341772159], [305.0, 160.407867494824], [304.0, 145.9779735682819], [306.0, 121.18018018018016], [307.0, 115.00884955752205], [308.0, 127.52396804261018], [309.0, 128.94633642930833], [310.0, 112.35573122529644], [311.0, 114.65359477124188], [312.0, 136.14662756598233], [318.0, 108.93979057591626], [319.0, 102.78754578754575], [316.0, 113.83755760368666], [317.0, 125.67643923240955], [313.0, 125.36820925553322], [314.0, 120.89198606271773], [315.0, 111.27151051625236], [321.0, 121.68957871396888], [320.0, 134.73813708260118], [322.0, 108.23809523809523], [323.0, 127.21249999999995], [324.0, 122.64019851116636], [325.0, 127.38764044943821], [326.0, 135.62400000000014], [327.0, 159.51315789473676], [328.0, 116.02735562310032], [334.0, 140.14941022280468], [335.0, 160.87086092715242], [332.0, 130.54318181818184], [333.0, 122.87052341597793], [329.0, 133.42351453855886], [330.0, 107.57990867579909], [331.0, 132.137837837838], [337.0, 151.3452631578947], [336.0, 148.03225806451607], [338.0, 137.42675159235674], [339.0, 113.06477732793523], [340.0, 126.86692015209121], [341.0, 131.20604914933838], [342.0, 123.9659685863875], [343.0, 144.638629283489], [344.0, 158.40932642487047], [350.0, 126.5700197238658], [351.0, 114.07384615384618], [348.0, 140.19230769230765], [349.0, 129.63219895287938], [345.0, 149.26690391459084], [346.0, 174.25595238095232], [347.0, 167.0726872246698], [353.0, 124.38515901060076], [352.0, 138.2567353407289], [354.0, 123.86183074265982], [355.0, 131.94339622641513], [356.0, 122.56281407035176], [357.0, 144.2352941176469], [358.0, 116.7240000000001], [359.0, 94.66834170854266], [360.0, 132.37455830388694], [366.0, 98.99268292682926], [367.0, 136.65415549597864], [364.0, 177.40549828178706], [365.0, 140.50410958904106], [361.0, 139.3224181360201], [362.0, 129.39194915254234], [363.0, 136.7739726027396], [369.0, 133.06525573192246], [368.0, 148.00740740740744], [370.0, 135.94699646643113], [371.0, 117.88038277511964], [372.0, 152.82489577129274], [373.0, 131.67125984251965], [374.0, 160.33899999999997], [375.0, 102.57652173913046], [376.0, 114.05350553505538], [382.0, 131.06853146853132], [383.0, 113.61044176706827], [380.0, 123.95277207392196], [381.0, 135.9021352313168], [377.0, 163.42282958199357], [378.0, 168.03043478260867], [379.0, 172.33177570093454], [385.0, 168.59382422802847], [384.0, 135.88571428571444], [386.0, 159.49752475247507], [387.0, 127.41244573082471], [388.0, 153.6710816777041], [389.0, 156.13600000000002], [390.0, 146.181216931217], [391.0, 140.11018711018707], [392.0, 142.41732283464574], [398.0, 153.8505747126437], [399.0, 174.2129870129871], [396.0, 183.43647540983628], [397.0, 179.0515151515151], [393.0, 141.74383301707772], [394.0, 168.46046511627898], [395.0, 187.61516853932574], [401.0, 144.1355140186915], [400.0, 136.32421875], [402.0, 188.70942408376965], [403.0, 158.24320827943086], [404.0, 149.67773851590098], [405.0, 188.18009478672977], [406.0, 176.26114649681537], [407.0, 160.12727272727267], [408.0, 135.24219910846944], [414.0, 158.02510460251037], [415.0, 171.1141818181814], [412.0, 140.7483443708609], [413.0, 185.50290135396514], [409.0, 140.31598513011156], [410.0, 155.46415094339616], [411.0, 138.38273921200758], [417.0, 158.33285233285292], [416.0, 148.05060240963817], [418.0, 152.86807817589573], [419.0, 189.64113785557987], [420.0, 194.25264550264538], [421.0, 195.1921110299488], [422.0, 196.24255319148935], [423.0, 163.72911227154063], [424.0, 148.93060498220655], [430.0, 168.96808510638303], [431.0, 228.31250000000014], [428.0, 172.13570487483548], [429.0, 121.26114649681526], [425.0, 148.27777777777774], [426.0, 161.5253863134658], [427.0, 163.79381443298968], [433.0, 177.85464098073513], [432.0, 251.92608695652177], [434.0, 141.1388550548111], [435.0, 155.92807424593954], [436.0, 164.36235708003525], [437.0, 144.43582089552257], [438.0, 152.21294117647062], [439.0, 190.43431635388748], [440.0, 171.10946196660493], [446.0, 157.30595813204505], [447.0, 189.42038834951455], [444.0, 162.33004926108353], [445.0, 149.05250596658723], [441.0, 170.7449814126395], [442.0, 126.91230068337129], [443.0, 143.5029535864977], [449.0, 205.55238095238082], [448.0, 185.58706467661702], [450.0, 189.27134146341447], [451.0, 160.88020086083213], [452.0, 281.0062047569809], [453.0, 185.69277108433735], [454.0, 209.28445229681984], [455.0, 162.05982905982896], [456.0, 151.08666666666664], [462.0, 207.3341404358353], [463.0, 189.2236976506639], [460.0, 167.59722222222226], [461.0, 204.4474393530997], [457.0, 172.06891891891885], [458.0, 123.20879120879123], [459.0, 151.56266666666667], [465.0, 324.09433962264154], [464.0, 187.01104972375697], [466.0, 271.3118022328548], [467.0, 193.34199837530448], [468.0, 175.63852242744062], [469.0, 150.75813953488364], [470.0, 172.3237639553432], [471.0, 228.96666666666675], [472.0, 210.34688090737257], [478.0, 191.57057949479966], [479.0, 181.98742138364793], [476.0, 191.9758534554538], [477.0, 165.12900763358775], [473.0, 211.12043795620446], [474.0, 196.3025316455696], [475.0, 218.07290233837682], [481.0, 174.26327599102476], [480.0, 230.23042505592835], [482.0, 206.26851851851848], [483.0, 160.92958423455917], [484.0, 225.80267558528433], [485.0, 205.73831775700933], [486.0, 257.66789667896654], [487.0, 217.56016597510373], [488.0, 172.32184950135968], [494.0, 234.70496083550884], [495.0, 183.10998552822], [492.0, 180.73821339950362], [493.0, 176.99242424242425], [489.0, 169.75837742504393], [490.0, 171.42627345844494], [491.0, 191.11176818450625], [497.0, 183.6764705882355], [496.0, 167.67445482866026], [498.0, 155.57902973395932], [499.0, 203.17076167076166], [500.0, 158.12022900763367], [501.0, 235.14865606143724], [502.0, 219.56100855470513], [503.0, 252.19029850746264], [504.0, 219.48119034250416], [510.0, 169.6939252336448], [511.0, 204.82058337919614], [508.0, 192.91713961407478], [509.0, 229.28137931034465], [505.0, 132.6396396396396], [506.0, 210.39413680781757], [507.0, 209.76843057440067], [515.0, 245.71826923076904], [512.0, 186.64565043894595], [526.0, 229.9198312236287], [527.0, 199.88065099457484], [524.0, 241.3571157495259], [525.0, 205.56744186046492], [522.0, 188.55033557046983], [523.0, 222.4804312163113], [513.0, 198.81268011527365], [514.0, 201.5223457082055], [516.0, 234.70440251572344], [517.0, 209.92387256930112], [518.0, 211.90254237288133], [519.0, 212.87110789283136], [528.0, 213.69662921348308], [542.0, 194.47089397089394], [543.0, 201.98971722365047], [540.0, 186.35600578871203], [541.0, 210.730880929332], [538.0, 261.3621169916431], [539.0, 169.90502793296088], [536.0, 180.38522012578613], [537.0, 231.94267515923545], [529.0, 174.07552083333312], [530.0, 196.63298969072167], [531.0, 233.1281618887015], [532.0, 162.30207064555438], [533.0, 220.35402985074617], [534.0, 164.05901287553615], [535.0, 155.53864734299523], [520.0, 244.8163265306124], [521.0, 193.60493827160502], [547.0, 210.93973063973053], [544.0, 191.279207920792], [558.0, 200.77100271002712], [559.0, 226.9387351778655], [556.0, 273.0523809523808], [557.0, 208.29722589167784], [554.0, 219.5905707196031], [555.0, 233.59657387580287], [545.0, 277.7679999999999], [546.0, 263.56968876860606], [548.0, 181.14514514514516], [549.0, 201.15351812366742], [550.0, 215.2750582750588], [551.0, 181.28437792329262], [560.0, 229.75691699604744], [574.0, 229.50905218317374], [575.0, 194.61224489795913], [572.0, 325.0582278481013], [573.0, 245.63335415365412], [570.0, 219.31704808434057], [571.0, 208.8133623819899], [568.0, 209.13567615658317], [569.0, 193.65661641541047], [561.0, 298.2326698695947], [562.0, 224.07924528301874], [563.0, 211.9187327823694], [564.0, 215.22048690859012], [565.0, 195.723076923077], [566.0, 189.93218806509944], [567.0, 210.74323062558358], [552.0, 223.52947154471534], [553.0, 221.78252427184452], [579.0, 213.13551401869154], [576.0, 220.36701337295705], [590.0, 226.65439093484412], [591.0, 217.20616883116878], [588.0, 235.77272727272717], [589.0, 253.68361086766006], [586.0, 290.93362193362196], [587.0, 218.66750313676275], [577.0, 172.07640449438185], [578.0, 196.68539325842687], [580.0, 234.29337539432163], [581.0, 258.6847172081828], [582.0, 248.59271523178822], [583.0, 194.4318283415285], [592.0, 244.44705603038994], [600.0, 242.22800660153945], [593.0, 288.54408060453386], [594.0, 317.64017094017015], [595.0, 298.0082592121983], [596.0, 261.6028037383178], [597.0, 214.37586685159516], [598.0, 216.6144000000002], [599.0, 241.41225259189443], [584.0, 244.86987522281643], [585.0, 222.41861861861847], [1.0, 48.4]], "isOverall": false, "label": "HTTP请求", "isController": false}, {"data": [[524.2618777777626, 211.91302666667133]], "isOverall": false, "label": "HTTP请求-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 600.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 218837.33333333334, "minX": 1.49380548E12, "maxY": 1675678.5, "series": [{"data": [[1.49380584E12, 1043173.65], [1.49380554E12, 1658454.15], [1.49380572E12, 1614661.7], [1.4938056E12, 1675678.5], [1.49380548E12, 644736.0], [1.49380578E12, 1632693.9833333334], [1.49380566E12, 1586030.85]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.49380584E12, 354075.68333333335], [1.49380554E12, 562915.1833333333], [1.49380572E12, 547925.8666666667], [1.4938056E12, 568761.5], [1.49380548E12, 218837.33333333334], [1.49380578E12, 554136.4166666666], [1.49380566E12, 538333.15]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380584E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 89.71948029891306, "minX": 1.49380548E12, "maxY": 248.2153089897333, "series": [{"data": [[1.49380584E12, 136.02826792068475], [1.49380554E12, 211.76761721149077], [1.49380572E12, 244.23064296228], [1.4938056E12, 234.91476181140968], [1.49380548E12, 89.71948029891306], [1.49380578E12, 217.9729905564186], [1.49380566E12, 248.2153089897333]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380584E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 89.71345108695655, "minX": 1.49380548E12, "maxY": 248.21191220839108, "series": [{"data": [[1.49380584E12, 136.0234603797737], [1.49380554E12, 211.7641904963115], [1.49380572E12, 244.0094623101604], [1.4938056E12, 234.91110893288948], [1.49380548E12, 89.71345108695655], [1.49380578E12, 217.89865589955528], [1.49380566E12, 248.21191220839108]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380584E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.12145040760869542, "minX": 1.49380548E12, "maxY": 0.8588333574974267, "series": [{"data": [[1.49380584E12, 0.3422171370988936], [1.49380554E12, 0.502287778049216], [1.49380572E12, 0.6920102830553388], [1.4938056E12, 0.6924067176370605], [1.49380548E12, 0.12145040760869542], [1.49380578E12, 0.5579760691098379], [1.49380566E12, 0.8588333574974267]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380584E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 12.0, "minX": 1.49380548E12, "maxY": 10491.0, "series": [{"data": [[1.49380584E12, 849.0], [1.49380554E12, 905.0], [1.49380572E12, 10491.0], [1.4938056E12, 911.0], [1.49380548E12, 397.0], [1.49380578E12, 10229.0], [1.49380566E12, 1004.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.49380584E12, 26.0], [1.49380554E12, 26.0], [1.49380572E12, 27.0], [1.4938056E12, 26.0], [1.49380548E12, 12.0], [1.49380578E12, 26.0], [1.49380566E12, 30.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.49380584E12, 129.0], [1.49380554E12, 380.0], [1.49380572E12, 420.0], [1.4938056E12, 383.0], [1.49380548E12, 180.0], [1.49380578E12, 302.0], [1.49380566E12, 378.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.49380584E12, 192.0], [1.49380554E12, 608.9900000000016], [1.49380572E12, 651.0], [1.4938056E12, 485.9900000000016], [1.49380548E12, 277.0], [1.49380578E12, 424.0], [1.49380566E12, 601.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.49380584E12, 155.0], [1.49380554E12, 446.0], [1.49380572E12, 507.9500000000007], [1.4938056E12, 422.0], [1.49380548E12, 207.0], [1.49380578E12, 344.0], [1.49380566E12, 435.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380584E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 75.0, "minX": 24843.0, "maxY": 10511.0, "series": [{"data": [[33030.0, 226.0], [35267.0, 75.0], [24843.0, 214.0], [27427.0, 209.0], [58880.0, 110.0], [29096.0, 172.0], [31457.0, 208.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[27427.0, 10511.0], [29096.0, 10510.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 58880.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 24843.0, "maxY": 226.0, "series": [{"data": [[33030.0, 226.0], [35267.0, 75.0], [24843.0, 214.0], [27427.0, 209.0], [58880.0, 110.0], [29096.0, 172.0], [31457.0, 208.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[27427.0, 0.0], [29096.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 58880.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 986.7333333333333, "minX": 1.49380548E12, "maxY": 2550.516666666667, "series": [{"data": [[1.49380584E12, 1580.0166666666667], [1.49380554E12, 2528.866666666667], [1.49380572E12, 2457.133333333333], [1.4938056E12, 2550.516666666667], [1.49380548E12, 986.7333333333333], [1.49380578E12, 2482.7], [1.49380566E12, 2414.0333333333333]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380584E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.49380548E12, "maxY": 2550.5, "series": [{"data": [[1.49380584E12, 1587.7833333333333], [1.49380554E12, 2524.2833333333333], [1.49380572E12, 2457.0666666666666], [1.4938056E12, 2550.5], [1.49380548E12, 981.3333333333334], [1.49380578E12, 2484.9166666666665], [1.49380566E12, 2414.05]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.49380572E12, 0.05], [1.49380578E12, 0.016666666666666666]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketTimeoutException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380584E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.49380548E12, "maxY": 2550.5, "series": [{"data": [[1.49380572E12, 0.05], [1.49380578E12, 0.016666666666666666]], "isOverall": false, "label": "HTTP请求-failure", "isController": false}, {"data": [[1.49380584E12, 1587.7833333333333], [1.49380554E12, 2524.2833333333333], [1.49380572E12, 2457.0666666666666], [1.4938056E12, 2550.5], [1.49380548E12, 981.3333333333334], [1.49380578E12, 2484.9166666666665], [1.49380566E12, 2414.05]], "isOverall": false, "label": "HTTP请求-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380584E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
