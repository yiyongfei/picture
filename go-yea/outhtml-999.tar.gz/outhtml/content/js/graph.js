/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 0 : 0;
        var yOffset = options.yaxis.mode === "time" ? 0 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 43.0, "minX": 0.0, "maxY": 1794.0, "series": [{"data": [[0.0, 43.0], [0.1, 52.0], [0.2, 53.0], [0.3, 53.0], [0.4, 54.0], [0.5, 54.0], [0.6, 55.0], [0.7, 56.0], [0.8, 57.0], [0.9, 58.0], [1.0, 59.0], [1.1, 60.0], [1.2, 61.0], [1.3, 63.0], [1.4, 64.0], [1.5, 66.0], [1.6, 68.0], [1.7, 70.0], [1.8, 71.0], [1.9, 73.0], [2.0, 76.0], [2.1, 77.0], [2.2, 78.0], [2.3, 80.0], [2.4, 81.0], [2.5, 82.0], [2.6, 83.0], [2.7, 84.0], [2.8, 85.0], [2.9, 86.0], [3.0, 87.0], [3.1, 88.0], [3.2, 89.0], [3.3, 90.0], [3.4, 91.0], [3.5, 93.0], [3.6, 94.0], [3.7, 95.0], [3.8, 96.0], [3.9, 97.0], [4.0, 98.0], [4.1, 99.0], [4.2, 100.0], [4.3, 101.0], [4.4, 102.0], [4.5, 103.0], [4.6, 104.0], [4.7, 105.0], [4.8, 105.0], [4.9, 106.0], [5.0, 107.0], [5.1, 107.0], [5.2, 108.0], [5.3, 109.0], [5.4, 109.0], [5.5, 110.0], [5.6, 110.0], [5.7, 111.0], [5.8, 112.0], [5.9, 112.0], [6.0, 113.0], [6.1, 113.0], [6.2, 114.0], [6.3, 115.0], [6.4, 115.0], [6.5, 116.0], [6.6, 116.0], [6.7, 117.0], [6.8, 118.0], [6.9, 118.0], [7.0, 119.0], [7.1, 119.0], [7.2, 120.0], [7.3, 121.0], [7.4, 121.0], [7.5, 122.0], [7.6, 122.0], [7.7, 123.0], [7.8, 123.0], [7.9, 124.0], [8.0, 125.0], [8.1, 125.0], [8.2, 126.0], [8.3, 126.0], [8.4, 127.0], [8.5, 127.0], [8.6, 128.0], [8.7, 129.0], [8.8, 129.0], [8.9, 130.0], [9.0, 130.0], [9.1, 131.0], [9.2, 131.0], [9.3, 132.0], [9.4, 132.0], [9.5, 133.0], [9.6, 133.0], [9.7, 134.0], [9.8, 135.0], [9.9, 135.0], [10.0, 136.0], [10.1, 136.0], [10.2, 137.0], [10.3, 137.0], [10.4, 138.0], [10.5, 138.0], [10.6, 139.0], [10.7, 139.0], [10.8, 140.0], [10.9, 140.0], [11.0, 141.0], [11.1, 141.0], [11.2, 142.0], [11.3, 142.0], [11.4, 143.0], [11.5, 143.0], [11.6, 144.0], [11.7, 144.0], [11.8, 145.0], [11.9, 145.0], [12.0, 146.0], [12.1, 146.0], [12.2, 147.0], [12.3, 147.0], [12.4, 148.0], [12.5, 148.0], [12.6, 149.0], [12.7, 149.0], [12.8, 150.0], [12.9, 150.0], [13.0, 151.0], [13.1, 151.0], [13.2, 152.0], [13.3, 152.0], [13.4, 153.0], [13.5, 153.0], [13.6, 154.0], [13.7, 154.0], [13.8, 155.0], [13.9, 155.0], [14.0, 156.0], [14.1, 156.0], [14.2, 157.0], [14.3, 157.0], [14.4, 158.0], [14.5, 158.0], [14.6, 159.0], [14.7, 159.0], [14.8, 160.0], [14.9, 160.0], [15.0, 161.0], [15.1, 161.0], [15.2, 161.0], [15.3, 162.0], [15.4, 162.0], [15.5, 163.0], [15.6, 163.0], [15.7, 164.0], [15.8, 164.0], [15.9, 165.0], [16.0, 165.0], [16.1, 166.0], [16.2, 166.0], [16.3, 167.0], [16.4, 167.0], [16.5, 167.0], [16.6, 168.0], [16.7, 168.0], [16.8, 169.0], [16.9, 169.0], [17.0, 170.0], [17.1, 170.0], [17.2, 171.0], [17.3, 171.0], [17.4, 171.0], [17.5, 172.0], [17.6, 172.0], [17.7, 173.0], [17.8, 173.0], [17.9, 174.0], [18.0, 174.0], [18.1, 175.0], [18.2, 175.0], [18.3, 176.0], [18.4, 176.0], [18.5, 176.0], [18.6, 177.0], [18.7, 177.0], [18.8, 178.0], [18.9, 178.0], [19.0, 179.0], [19.1, 179.0], [19.2, 180.0], [19.3, 180.0], [19.4, 180.0], [19.5, 181.0], [19.6, 181.0], [19.7, 182.0], [19.8, 182.0], [19.9, 183.0], [20.0, 183.0], [20.1, 183.0], [20.2, 184.0], [20.3, 184.0], [20.4, 185.0], [20.5, 185.0], [20.6, 186.0], [20.7, 186.0], [20.8, 186.0], [20.9, 187.0], [21.0, 187.0], [21.1, 188.0], [21.2, 188.0], [21.3, 189.0], [21.4, 189.0], [21.5, 189.0], [21.6, 190.0], [21.7, 190.0], [21.8, 191.0], [21.9, 191.0], [22.0, 191.0], [22.1, 192.0], [22.2, 192.0], [22.3, 193.0], [22.4, 193.0], [22.5, 194.0], [22.6, 194.0], [22.7, 194.0], [22.8, 195.0], [22.9, 195.0], [23.0, 196.0], [23.1, 196.0], [23.2, 197.0], [23.3, 197.0], [23.4, 197.0], [23.5, 198.0], [23.6, 198.0], [23.7, 199.0], [23.8, 199.0], [23.9, 199.0], [24.0, 200.0], [24.1, 200.0], [24.2, 201.0], [24.3, 201.0], [24.4, 202.0], [24.5, 202.0], [24.6, 202.0], [24.7, 203.0], [24.8, 203.0], [24.9, 204.0], [25.0, 204.0], [25.1, 204.0], [25.2, 205.0], [25.3, 205.0], [25.4, 206.0], [25.5, 206.0], [25.6, 206.0], [25.7, 207.0], [25.8, 207.0], [25.9, 208.0], [26.0, 208.0], [26.1, 208.0], [26.2, 209.0], [26.3, 209.0], [26.4, 210.0], [26.5, 210.0], [26.6, 211.0], [26.7, 211.0], [26.8, 211.0], [26.9, 212.0], [27.0, 212.0], [27.1, 213.0], [27.2, 213.0], [27.3, 213.0], [27.4, 214.0], [27.5, 214.0], [27.6, 215.0], [27.7, 215.0], [27.8, 215.0], [27.9, 216.0], [28.0, 216.0], [28.1, 217.0], [28.2, 217.0], [28.3, 217.0], [28.4, 218.0], [28.5, 218.0], [28.6, 219.0], [28.7, 219.0], [28.8, 219.0], [28.9, 220.0], [29.0, 220.0], [29.1, 221.0], [29.2, 221.0], [29.3, 221.0], [29.4, 222.0], [29.5, 222.0], [29.6, 223.0], [29.7, 223.0], [29.8, 223.0], [29.9, 224.0], [30.0, 224.0], [30.1, 225.0], [30.2, 225.0], [30.3, 225.0], [30.4, 226.0], [30.5, 226.0], [30.6, 227.0], [30.7, 227.0], [30.8, 227.0], [30.9, 228.0], [31.0, 228.0], [31.1, 229.0], [31.2, 229.0], [31.3, 229.0], [31.4, 230.0], [31.5, 230.0], [31.6, 231.0], [31.7, 231.0], [31.8, 231.0], [31.9, 232.0], [32.0, 232.0], [32.1, 233.0], [32.2, 233.0], [32.3, 233.0], [32.4, 234.0], [32.5, 234.0], [32.6, 235.0], [32.7, 235.0], [32.8, 235.0], [32.9, 236.0], [33.0, 236.0], [33.1, 237.0], [33.2, 237.0], [33.3, 237.0], [33.4, 238.0], [33.5, 238.0], [33.6, 239.0], [33.7, 239.0], [33.8, 239.0], [33.9, 240.0], [34.0, 240.0], [34.1, 241.0], [34.2, 241.0], [34.3, 241.0], [34.4, 242.0], [34.5, 242.0], [34.6, 243.0], [34.7, 243.0], [34.8, 244.0], [34.9, 244.0], [35.0, 244.0], [35.1, 245.0], [35.2, 245.0], [35.3, 246.0], [35.4, 246.0], [35.5, 246.0], [35.6, 247.0], [35.7, 247.0], [35.8, 248.0], [35.9, 248.0], [36.0, 248.0], [36.1, 249.0], [36.2, 249.0], [36.3, 250.0], [36.4, 250.0], [36.5, 250.0], [36.6, 251.0], [36.7, 251.0], [36.8, 252.0], [36.9, 252.0], [37.0, 252.0], [37.1, 253.0], [37.2, 253.0], [37.3, 254.0], [37.4, 254.0], [37.5, 254.0], [37.6, 255.0], [37.7, 255.0], [37.8, 256.0], [37.9, 256.0], [38.0, 257.0], [38.1, 257.0], [38.2, 257.0], [38.3, 258.0], [38.4, 258.0], [38.5, 259.0], [38.6, 259.0], [38.7, 259.0], [38.8, 260.0], [38.9, 260.0], [39.0, 261.0], [39.1, 261.0], [39.2, 261.0], [39.3, 262.0], [39.4, 262.0], [39.5, 263.0], [39.6, 263.0], [39.7, 264.0], [39.8, 264.0], [39.9, 264.0], [40.0, 265.0], [40.1, 265.0], [40.2, 266.0], [40.3, 266.0], [40.4, 266.0], [40.5, 267.0], [40.6, 267.0], [40.7, 268.0], [40.8, 268.0], [40.9, 268.0], [41.0, 269.0], [41.1, 269.0], [41.2, 270.0], [41.3, 270.0], [41.4, 270.0], [41.5, 271.0], [41.6, 271.0], [41.7, 272.0], [41.8, 272.0], [41.9, 273.0], [42.0, 273.0], [42.1, 273.0], [42.2, 274.0], [42.3, 274.0], [42.4, 275.0], [42.5, 275.0], [42.6, 275.0], [42.7, 276.0], [42.8, 276.0], [42.9, 277.0], [43.0, 277.0], [43.1, 277.0], [43.2, 278.0], [43.3, 278.0], [43.4, 279.0], [43.5, 279.0], [43.6, 280.0], [43.7, 280.0], [43.8, 280.0], [43.9, 281.0], [44.0, 281.0], [44.1, 282.0], [44.2, 282.0], [44.3, 282.0], [44.4, 283.0], [44.5, 283.0], [44.6, 284.0], [44.7, 284.0], [44.8, 285.0], [44.9, 285.0], [45.0, 285.0], [45.1, 286.0], [45.2, 286.0], [45.3, 287.0], [45.4, 287.0], [45.5, 288.0], [45.6, 288.0], [45.7, 288.0], [45.8, 289.0], [45.9, 289.0], [46.0, 290.0], [46.1, 290.0], [46.2, 290.0], [46.3, 291.0], [46.4, 291.0], [46.5, 292.0], [46.6, 292.0], [46.7, 293.0], [46.8, 293.0], [46.9, 293.0], [47.0, 294.0], [47.1, 294.0], [47.2, 295.0], [47.3, 295.0], [47.4, 296.0], [47.5, 296.0], [47.6, 296.0], [47.7, 297.0], [47.8, 297.0], [47.9, 298.0], [48.0, 298.0], [48.1, 299.0], [48.2, 299.0], [48.3, 299.0], [48.4, 300.0], [48.5, 300.0], [48.6, 301.0], [48.7, 301.0], [48.8, 301.0], [48.9, 302.0], [49.0, 302.0], [49.1, 303.0], [49.2, 303.0], [49.3, 304.0], [49.4, 304.0], [49.5, 305.0], [49.6, 305.0], [49.7, 305.0], [49.8, 306.0], [49.9, 306.0], [50.0, 307.0], [50.1, 307.0], [50.2, 308.0], [50.3, 308.0], [50.4, 309.0], [50.5, 309.0], [50.6, 309.0], [50.7, 310.0], [50.8, 310.0], [50.9, 311.0], [51.0, 311.0], [51.1, 312.0], [51.2, 312.0], [51.3, 312.0], [51.4, 313.0], [51.5, 313.0], [51.6, 314.0], [51.7, 314.0], [51.8, 315.0], [51.9, 315.0], [52.0, 316.0], [52.1, 316.0], [52.2, 316.0], [52.3, 317.0], [52.4, 317.0], [52.5, 318.0], [52.6, 318.0], [52.7, 319.0], [52.8, 319.0], [52.9, 320.0], [53.0, 320.0], [53.1, 320.0], [53.2, 321.0], [53.3, 321.0], [53.4, 322.0], [53.5, 322.0], [53.6, 323.0], [53.7, 323.0], [53.8, 324.0], [53.9, 324.0], [54.0, 325.0], [54.1, 325.0], [54.2, 325.0], [54.3, 326.0], [54.4, 326.0], [54.5, 327.0], [54.6, 327.0], [54.7, 328.0], [54.8, 328.0], [54.9, 329.0], [55.0, 329.0], [55.1, 330.0], [55.2, 330.0], [55.3, 330.0], [55.4, 331.0], [55.5, 331.0], [55.6, 332.0], [55.7, 332.0], [55.8, 333.0], [55.9, 333.0], [56.0, 334.0], [56.1, 334.0], [56.2, 335.0], [56.3, 335.0], [56.4, 336.0], [56.5, 336.0], [56.6, 337.0], [56.7, 337.0], [56.8, 338.0], [56.9, 338.0], [57.0, 339.0], [57.1, 339.0], [57.2, 339.0], [57.3, 340.0], [57.4, 340.0], [57.5, 341.0], [57.6, 341.0], [57.7, 342.0], [57.8, 342.0], [57.9, 343.0], [58.0, 343.0], [58.1, 344.0], [58.2, 344.0], [58.3, 345.0], [58.4, 345.0], [58.5, 346.0], [58.6, 346.0], [58.7, 347.0], [58.8, 347.0], [58.9, 348.0], [59.0, 348.0], [59.1, 349.0], [59.2, 349.0], [59.3, 349.0], [59.4, 350.0], [59.5, 350.0], [59.6, 351.0], [59.7, 351.0], [59.8, 352.0], [59.9, 352.0], [60.0, 353.0], [60.1, 353.0], [60.2, 354.0], [60.3, 354.0], [60.4, 355.0], [60.5, 355.0], [60.6, 356.0], [60.7, 356.0], [60.8, 357.0], [60.9, 357.0], [61.0, 358.0], [61.1, 358.0], [61.2, 359.0], [61.3, 359.0], [61.4, 360.0], [61.5, 360.0], [61.6, 361.0], [61.7, 361.0], [61.8, 362.0], [61.9, 362.0], [62.0, 363.0], [62.1, 363.0], [62.2, 364.0], [62.3, 364.0], [62.4, 365.0], [62.5, 365.0], [62.6, 366.0], [62.7, 366.0], [62.8, 367.0], [62.9, 367.0], [63.0, 368.0], [63.1, 368.0], [63.2, 369.0], [63.3, 369.0], [63.4, 370.0], [63.5, 370.0], [63.6, 371.0], [63.7, 371.0], [63.8, 372.0], [63.9, 372.0], [64.0, 373.0], [64.1, 373.0], [64.2, 374.0], [64.3, 374.0], [64.4, 375.0], [64.5, 375.0], [64.6, 376.0], [64.7, 376.0], [64.8, 377.0], [64.9, 378.0], [65.0, 378.0], [65.1, 379.0], [65.2, 379.0], [65.3, 380.0], [65.4, 380.0], [65.5, 381.0], [65.6, 381.0], [65.7, 382.0], [65.8, 382.0], [65.9, 383.0], [66.0, 383.0], [66.1, 384.0], [66.2, 385.0], [66.3, 385.0], [66.4, 386.0], [66.5, 386.0], [66.6, 387.0], [66.7, 387.0], [66.8, 388.0], [66.9, 388.0], [67.0, 389.0], [67.1, 389.0], [67.2, 390.0], [67.3, 391.0], [67.4, 391.0], [67.5, 392.0], [67.6, 392.0], [67.7, 393.0], [67.8, 393.0], [67.9, 394.0], [68.0, 394.0], [68.1, 395.0], [68.2, 396.0], [68.3, 396.0], [68.4, 397.0], [68.5, 397.0], [68.6, 398.0], [68.7, 398.0], [68.8, 399.0], [68.9, 400.0], [69.0, 400.0], [69.1, 401.0], [69.2, 401.0], [69.3, 402.0], [69.4, 402.0], [69.5, 403.0], [69.6, 404.0], [69.7, 404.0], [69.8, 405.0], [69.9, 405.0], [70.0, 406.0], [70.1, 406.0], [70.2, 407.0], [70.3, 408.0], [70.4, 408.0], [70.5, 409.0], [70.6, 409.0], [70.7, 410.0], [70.8, 411.0], [70.9, 411.0], [71.0, 412.0], [71.1, 412.0], [71.2, 413.0], [71.3, 414.0], [71.4, 414.0], [71.5, 415.0], [71.6, 415.0], [71.7, 416.0], [71.8, 417.0], [71.9, 417.0], [72.0, 418.0], [72.1, 418.0], [72.2, 419.0], [72.3, 420.0], [72.4, 420.0], [72.5, 421.0], [72.6, 422.0], [72.7, 422.0], [72.8, 423.0], [72.9, 423.0], [73.0, 424.0], [73.1, 425.0], [73.2, 425.0], [73.3, 426.0], [73.4, 427.0], [73.5, 427.0], [73.6, 428.0], [73.7, 429.0], [73.8, 429.0], [73.9, 430.0], [74.0, 430.0], [74.1, 431.0], [74.2, 432.0], [74.3, 432.0], [74.4, 433.0], [74.5, 434.0], [74.6, 434.0], [74.7, 435.0], [74.8, 436.0], [74.9, 436.0], [75.0, 437.0], [75.1, 438.0], [75.2, 438.0], [75.3, 439.0], [75.4, 440.0], [75.5, 440.0], [75.6, 441.0], [75.7, 442.0], [75.8, 442.0], [75.9, 443.0], [76.0, 444.0], [76.1, 444.0], [76.2, 445.0], [76.3, 446.0], [76.4, 446.0], [76.5, 447.0], [76.6, 448.0], [76.7, 449.0], [76.8, 449.0], [76.9, 450.0], [77.0, 451.0], [77.1, 451.0], [77.2, 452.0], [77.3, 453.0], [77.4, 453.0], [77.5, 454.0], [77.6, 455.0], [77.7, 456.0], [77.8, 456.0], [77.9, 457.0], [78.0, 458.0], [78.1, 458.0], [78.2, 459.0], [78.3, 460.0], [78.4, 461.0], [78.5, 461.0], [78.6, 462.0], [78.7, 463.0], [78.8, 464.0], [78.9, 464.0], [79.0, 465.0], [79.1, 466.0], [79.2, 467.0], [79.3, 467.0], [79.4, 468.0], [79.5, 469.0], [79.6, 470.0], [79.7, 470.0], [79.8, 471.0], [79.9, 472.0], [80.0, 473.0], [80.1, 473.0], [80.2, 474.0], [80.3, 475.0], [80.4, 476.0], [80.5, 477.0], [80.6, 477.0], [80.7, 478.0], [80.8, 479.0], [80.9, 480.0], [81.0, 481.0], [81.1, 481.0], [81.2, 482.0], [81.3, 483.0], [81.4, 484.0], [81.5, 485.0], [81.6, 485.0], [81.7, 486.0], [81.8, 487.0], [81.9, 488.0], [82.0, 489.0], [82.1, 490.0], [82.2, 490.0], [82.3, 491.0], [82.4, 492.0], [82.5, 493.0], [82.6, 494.0], [82.7, 495.0], [82.8, 496.0], [82.9, 496.0], [83.0, 497.0], [83.1, 498.0], [83.2, 499.0], [83.3, 500.0], [83.4, 501.0], [83.5, 502.0], [83.6, 503.0], [83.7, 504.0], [83.8, 505.0], [83.9, 505.0], [84.0, 506.0], [84.1, 507.0], [84.2, 508.0], [84.3, 509.0], [84.4, 510.0], [84.5, 511.0], [84.6, 512.0], [84.7, 513.0], [84.8, 514.0], [84.9, 515.0], [85.0, 516.0], [85.1, 517.0], [85.2, 518.0], [85.3, 519.0], [85.4, 520.0], [85.5, 521.0], [85.6, 522.0], [85.7, 523.0], [85.8, 524.0], [85.9, 525.0], [86.0, 526.0], [86.1, 527.0], [86.2, 528.0], [86.3, 529.0], [86.4, 530.0], [86.5, 531.0], [86.6, 532.0], [86.7, 533.0], [86.8, 534.0], [86.9, 536.0], [87.0, 537.0], [87.1, 538.0], [87.2, 539.0], [87.3, 540.0], [87.4, 541.0], [87.5, 542.0], [87.6, 543.0], [87.7, 545.0], [87.8, 546.0], [87.9, 547.0], [88.0, 548.0], [88.1, 549.0], [88.2, 550.0], [88.3, 552.0], [88.4, 553.0], [88.5, 554.0], [88.6, 555.0], [88.7, 557.0], [88.8, 558.0], [88.9, 559.0], [89.0, 560.0], [89.1, 561.0], [89.2, 563.0], [89.3, 564.0], [89.4, 565.0], [89.5, 567.0], [89.6, 568.0], [89.7, 569.0], [89.8, 571.0], [89.9, 572.0], [90.0, 573.0], [90.1, 575.0], [90.2, 576.0], [90.3, 577.0], [90.4, 579.0], [90.5, 580.0], [90.6, 582.0], [90.7, 583.0], [90.8, 585.0], [90.9, 586.0], [91.0, 588.0], [91.1, 589.0], [91.2, 591.0], [91.3, 592.0], [91.4, 594.0], [91.5, 595.0], [91.6, 597.0], [91.7, 598.0], [91.8, 600.0], [91.9, 602.0], [92.0, 603.0], [92.1, 605.0], [92.2, 606.0], [92.3, 608.0], [92.4, 610.0], [92.5, 612.0], [92.6, 613.0], [92.7, 615.0], [92.8, 617.0], [92.9, 619.0], [93.0, 621.0], [93.1, 623.0], [93.2, 625.0], [93.3, 626.0], [93.4, 628.0], [93.5, 630.0], [93.6, 632.0], [93.7, 634.0], [93.8, 636.0], [93.9, 638.0], [94.0, 640.0], [94.1, 642.0], [94.2, 645.0], [94.3, 647.0], [94.4, 649.0], [94.5, 651.0], [94.6, 654.0], [94.7, 656.0], [94.8, 658.0], [94.9, 661.0], [95.0, 664.0], [95.1, 666.0], [95.2, 669.0], [95.3, 671.0], [95.4, 674.0], [95.5, 677.0], [95.6, 679.0], [95.7, 682.0], [95.8, 685.0], [95.9, 688.0], [96.0, 691.0], [96.1, 695.0], [96.2, 698.0], [96.3, 701.0], [96.4, 704.0], [96.5, 708.0], [96.6, 711.0], [96.7, 715.0], [96.8, 719.0], [96.9, 723.0], [97.0, 727.0], [97.1, 731.0], [97.2, 735.0], [97.3, 739.0], [97.4, 744.0], [97.5, 748.0], [97.6, 753.0], [97.7, 758.0], [97.8, 763.0], [97.9, 769.0], [98.0, 774.0], [98.1, 780.0], [98.2, 787.0], [98.3, 794.0], [98.4, 801.0], [98.5, 808.0], [98.6, 816.0], [98.7, 825.0], [98.8, 835.0], [98.9, 844.0], [99.0, 855.0], [99.1, 868.0], [99.2, 883.0], [99.3, 899.0], [99.4, 917.0], [99.5, 938.0], [99.6, 964.0], [99.7, 996.0], [99.8, 1036.0], [99.9, 1103.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 10.0, "minX": 0.0, "maxY": 1663107.0, "series": [{"data": [[0.0, 1663107.0], [1500.0, 10.0], [500.0, 329099.0], [1000.0, 5784.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 500, "maxX": 1500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 10.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1665425.0, "series": [{"data": [[1.0, 332565.0]], "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[0.0, 1665425.0]], "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[2.0, 10.0]], "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 444.70914164627584, "minX": 1.49458146E12, "maxY": 999.0, "series": [{"data": [[1.49458164E12, 999.0], [1.49458194E12, 999.0], [1.49458146E12, 461.48742900949094], [1.49458206E12, 982.3006069812207], [1.494582E12, 999.0], [1.4945817E12, 999.0], [1.49458212E12, 805.4507113166742], [1.49458182E12, 999.0], [1.49458176E12, 999.0], [1.49458188E12, 999.0], [1.49458158E12, 999.0], [1.49458152E12, 981.2121073148376], [1.49458218E12, 444.70914164627584]], "isOverall": false, "label": "性能测试", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49458218E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 52.166666666666664, "minX": 1.0, "maxY": 478.0024466969592, "series": [{"data": [[2.0, 52.5], [3.0, 52.625], [4.0, 52.166666666666664], [5.0, 52.55555555555556], [6.0, 53.0], [7.0, 53.1], [8.0, 92.82608695652173], [9.0, 55.63636363636363], [10.0, 55.19047619047619], [11.0, 58.08333333333333], [12.0, 56.10526315789473], [13.0, 53.666666666666664], [14.0, 57.75000000000001], [15.0, 53.73333333333333], [16.0, 62.19047619047618], [17.0, 53.42307692307692], [18.0, 57.00000000000001], [19.0, 55.08571428571429], [20.0, 71.71428571428572], [21.0, 54.37931034482759], [22.0, 55.735294117647065], [23.0, 57.61764705882354], [24.0, 53.633333333333326], [25.0, 55.52941176470588], [26.0, 53.94285714285715], [27.0, 53.107142857142854], [28.0, 54.59090909090909], [29.0, 54.88095238095237], [30.0, 56.19047619047619], [31.0, 55.98245614035088], [32.0, 53.81250000000001], [33.0, 57.521276595744695], [34.0, 55.530303030303024], [35.0, 52.97826086956521], [36.0, 53.43181818181817], [37.0, 56.300000000000004], [38.0, 55.01587301587303], [39.0, 55.796610169491515], [40.0, 54.44761904761903], [41.0, 57.44680851063828], [42.0, 56.86046511627907], [43.0, 53.23404255319149], [44.0, 54.48979591836735], [45.0, 56.785714285714285], [46.0, 54.33333333333332], [47.0, 54.357142857142854], [48.0, 55.227272727272734], [49.0, 54.509090909090915], [50.0, 57.30434782608697], [51.0, 69.6842105263158], [52.0, 57.51562500000001], [53.0, 60.52112676056338], [54.0, 57.807692307692314], [55.0, 60.666666666666664], [56.0, 53.92982456140351], [57.0, 55.861111111111114], [58.0, 116.64999999999999], [59.0, 107.83098591549297], [60.0, 62.47297297297298], [61.0, 58.987179487179496], [62.0, 57.21951219512194], [63.0, 55.446808510638306], [64.0, 54.77011494252873], [65.0, 59.47142857142857], [66.0, 56.793478260869556], [67.0, 56.11111111111111], [68.0, 57.72043010752688], [69.0, 55.85057471264367], [70.0, 54.158192090395495], [71.0, 60.109756097560975], [72.0, 64.63999999999999], [73.0, 57.77319587628867], [74.0, 57.54999999999999], [75.0, 69.1785714285714], [76.0, 56.34108527131781], [77.0, 55.02150537634408], [78.0, 53.888888888888886], [79.0, 58.207920792079186], [80.0, 64.97321428571426], [81.0, 61.037037037037045], [82.0, 58.224489795918394], [83.0, 68.24427480916032], [84.0, 72.51515151515153], [85.0, 75.83653846153848], [86.0, 73.94262295081974], [87.0, 66.87591240875912], [88.0, 73.0294117647059], [89.0, 63.798245614035096], [90.0, 61.92413793103446], [91.0, 105.5762711864407], [92.0, 66.55208333333331], [93.0, 60.34579439252336], [94.0, 61.876404494382], [95.0, 63.97345132743364], [96.0, 66.38613861386138], [97.0, 59.29729729729726], [98.0, 70.80291970802921], [99.0, 62.37988826815643], [100.0, 60.65811965811965], [101.0, 70.26666666666667], [102.0, 65.53623188405794], [103.0, 59.82467532467532], [104.0, 64.61151079136692], [105.0, 63.54285714285713], [106.0, 60.39622641509434], [107.0, 69.91249999999994], [108.0, 59.78881987577638], [109.0, 70.75609756097559], [110.0, 69.71590909090912], [111.0, 71.70192307692312], [112.0, 72.34090909090911], [113.0, 68.0588235294118], [114.0, 72.30597014925375], [115.0, 66.6744186046512], [116.0, 59.61764705882354], [117.0, 109.59574468085106], [118.0, 122.2348484848485], [119.0, 77.72058823529412], [120.0, 72.76999999999998], [121.0, 96.9020979020979], [122.0, 66.24528301886792], [123.0, 68.22962962962961], [124.0, 65.61240310077517], [125.0, 68.13333333333333], [126.0, 64.20129870129863], [127.0, 70.88421052631581], [128.0, 71.13333333333331], [129.0, 64.31677018633539], [130.0, 74.04255319148932], [131.0, 72.78735632183913], [132.0, 59.61006289308177], [133.0, 74.7083333333333], [134.0, 66.0441176470588], [135.0, 63.011111111111134], [136.0, 72.32539682539685], [137.0, 66.02884615384617], [138.0, 65.47656249999996], [139.0, 68.30059523809526], [140.0, 73.40909090909088], [141.0, 89.38461538461539], [142.0, 68.23456790123456], [143.0, 73.19028340080975], [144.0, 78.89444444444443], [145.0, 65.67052023121386], [146.0, 60.41269841269839], [147.0, 69.24832214765102], [148.0, 64.72413793103449], [149.0, 66.64666666666669], [150.0, 76.37714285714284], [151.0, 67.05555555555556], [152.0, 78.73127753303964], [153.0, 62.330935251798564], [154.0, 69.23529411764707], [155.0, 122.544], [156.0, 76.39393939393942], [157.0, 81.81818181818181], [158.0, 82.58988764044942], [159.0, 72.67676767676767], [160.0, 85.75520833333334], [161.0, 85.15384615384612], [162.0, 87.42857142857143], [163.0, 78.01401869158875], [164.0, 88.05555555555557], [165.0, 72.96913580246917], [166.0, 69.24561403508774], [167.0, 78.83333333333337], [168.0, 83.32624113475174], [169.0, 74.90062111801244], [170.0, 79.69117647058818], [171.0, 69.23417721518985], [172.0, 84.10674157303374], [173.0, 79.23312883435582], [174.0, 85.98564593301433], [175.0, 79.67588932806328], [176.0, 66.71349862258957], [177.0, 68.23857868020306], [178.0, 67.19463087248326], [179.0, 80.30232558139535], [180.0, 74.55666666666662], [181.0, 70.75428571428574], [182.0, 68.75735294117649], [183.0, 67.20710059171596], [184.0, 73.95491803278688], [185.0, 69.319587628866], [186.0, 91.73157894736839], [187.0, 91.10434782608694], [188.0, 74.23312883435584], [189.0, 72.17543859649126], [190.0, 89.45864661654133], [191.0, 113.59880239520953], [192.0, 85.98173515981732], [193.0, 63.85981308411219], [194.0, 70.03162055335967], [195.0, 73.46913580246915], [196.0, 77.17989417989412], [197.0, 77.02083333333334], [198.0, 73.50306748466258], [199.0, 76.28985507246375], [200.0, 86.21548821548814], [201.0, 81.87777777777782], [202.0, 77.23353293413176], [203.0, 77.12385321100918], [204.0, 82.75625], [205.0, 82.40613026819918], [206.0, 72.49681528662418], [207.0, 93.47231270358306], [208.0, 89.32579185520365], [209.0, 89.91828793774314], [210.0, 74.86486486486483], [211.0, 94.15425531914897], [212.0, 87.57727272727277], [213.0, 80.1024590163934], [214.0, 78.65201465201474], [215.0, 82.46153846153844], [216.0, 89.57961783439494], [217.0, 80.90211640211646], [218.0, 72.5288461538461], [219.0, 77.85915492957751], [220.0, 68.1521739130435], [221.0, 121.66666666666667], [222.0, 97.53886010362696], [223.0, 79.39130434782604], [224.0, 69.49999999999999], [225.0, 86.15503875968989], [226.0, 77.39555555555552], [227.0, 97.99206349206351], [228.0, 82.5584415584416], [229.0, 77.7963800904977], [230.0, 82.8279069767443], [231.0, 83.40000000000006], [232.0, 77.22767857142858], [233.0, 79.79611650485435], [234.0, 81.40975609756096], [235.0, 76.95945945945944], [236.0, 90.47395833333331], [237.0, 79.85964912280699], [238.0, 90.31155778894474], [239.0, 94.21897810218981], [240.0, 92.41197183098586], [241.0, 100.30232558139534], [242.0, 96.09714285714287], [243.0, 101.13584905660382], [244.0, 83.02429149797577], [245.0, 77.68750000000001], [246.0, 74.17191977077366], [247.0, 78.82296650717707], [248.0, 90.70355731225297], [249.0, 85.81012658227846], [250.0, 142.8349514563106], [251.0, 128.21641791044786], [252.0, 104.04968944099382], [253.0, 97.77435897435899], [254.0, 93.92270531400965], [255.0, 84.6484375], [257.0, 74.95217391304347], [256.0, 76.15178571428567], [258.0, 77.4734982332156], [259.0, 91.27807486631016], [260.0, 107.49999999999996], [261.0, 114.53231939163491], [262.0, 72.09407665505223], [263.0, 82.4291338582677], [264.0, 81.58454106280188], [270.0, 80.60393258426961], [271.0, 78.90697674418604], [268.0, 112.92391304347825], [269.0, 103.95145631067959], [265.0, 97.55172413793105], [266.0, 94.08127208480565], [267.0, 91.00330033003304], [273.0, 91.12903225806456], [272.0, 102.39361702127663], [274.0, 94.67424242424241], [275.0, 82.22941176470592], [276.0, 88.08333333333336], [277.0, 167.35576923076928], [278.0, 134.48363636363635], [279.0, 98.64948453608245], [280.0, 103.1262626262626], [286.0, 132.36956521739134], [287.0, 124.42081447963797], [284.0, 165.6666666666667], [285.0, 156.04322766570613], [281.0, 100.35999999999999], [282.0, 91.84615384615384], [283.0, 120.879781420765], [289.0, 98.42800000000001], [288.0, 122.11111111111116], [290.0, 113.10931174089067], [291.0, 108.67169811320751], [292.0, 99.58823529411762], [293.0, 92.80081300813009], [294.0, 93.67685589519644], [295.0, 92.22751322751324], [296.0, 100.00632911392402], [302.0, 113.03813559322033], [303.0, 114.02120141342758], [300.0, 114.7643678160919], [301.0, 102.33802816901408], [297.0, 106.16161616161614], [298.0, 99.78378378378385], [299.0, 105.75115207373273], [305.0, 131.2383177570093], [304.0, 106.95752895752898], [306.0, 123.76315789473685], [307.0, 123.1453287197232], [308.0, 168.01762114537422], [309.0, 150.20588235294122], [310.0, 123.27227722772284], [311.0, 111.54214123006828], [312.0, 95.43712574850301], [318.0, 120.7238095238095], [319.0, 91.9342465753424], [316.0, 109.94117647058825], [317.0, 96.25806451612904], [313.0, 106.42441860465117], [314.0, 110.97607655502394], [315.0, 106.23928571428577], [321.0, 99.6327433628319], [320.0, 90.6554621848739], [322.0, 102.50313152400825], [323.0, 110.31034482758618], [324.0, 116.3372093023256], [325.0, 134.64393939393938], [326.0, 115.19387755102046], [327.0, 124.5355932203389], [328.0, 127.90502793296089], [334.0, 107.03206997084554], [335.0, 115.95789473684214], [332.0, 107.80740740740744], [333.0, 108.49199999999996], [329.0, 111.90322580645163], [330.0, 119.39631336405529], [331.0, 105.85148514851485], [337.0, 170.85380116959075], [336.0, 102.3047619047619], [338.0, 207.57042253521124], [339.0, 154.15948275862064], [340.0, 116.2613240418119], [341.0, 106.86086956521737], [342.0, 122.29999999999993], [343.0, 137.37130801687763], [344.0, 122.52195121951216], [350.0, 119.2581967213115], [351.0, 134.25210084033606], [348.0, 100.30800000000002], [349.0, 104.92181069958843], [345.0, 118.2], [346.0, 102.6717791411042], [347.0, 106.86245353159849], [353.0, 138.20626151012897], [352.0, 135.5284280936455], [354.0, 127.70397111913353], [355.0, 96.82945736434107], [356.0, 114.3062015503876], [357.0, 102.70631970260227], [358.0, 101.68384879725095], [359.0, 103.10071942446041], [360.0, 108.08115183246076], [366.0, 132.1095238095237], [367.0, 126.03921568627442], [364.0, 198.0434782608697], [365.0, 167.69082125603867], [361.0, 97.45390070921985], [363.0, 124.80397727272724], [362.0, 117.26086956521739], [369.0, 111.41436464088403], [368.0, 125.15463917525787], [370.0, 129.30039525691703], [371.0, 132.42335766423346], [372.0, 128.4538152610442], [373.0, 99.72380952380946], [374.0, 100.23109243697476], [375.0, 107.77358490566039], [376.0, 114.98842592592592], [382.0, 121.57051282051285], [383.0, 110.75126903553296], [380.0, 107.20253164556974], [381.0, 131.85714285714292], [377.0, 117.55516014234875], [378.0, 116.30455635491607], [379.0, 104.78016085790887], [385.0, 111.69587628865976], [384.0, 113.52491694352153], [386.0, 123.79794520547945], [387.0, 126.90220048899752], [389.0, 167.15589353612165], [388.0, 116.56725146198833], [390.0, 132.98773006134965], [391.0, 207.23385300668153], [392.0, 166.79687500000003], [398.0, 112.87132352941181], [399.0, 154.49606299212596], [396.0, 118.73714285714281], [397.0, 142.0], [393.0, 154.0311111111111], [394.0, 169.88922155688624], [395.0, 119.20911528150135], [401.0, 113.00655021834054], [400.0, 122.67368421052632], [402.0, 117.18162839248436], [403.0, 115.08731241473387], [404.0, 108.3696682464455], [405.0, 117.79019607843131], [406.0, 99.23175965665239], [407.0, 115.9213483146067], [408.0, 108.25423728813557], [415.0, 229.41463414634148], [414.0, 199.75], [412.0, 161.58041958041963], [413.0, 172.3333333333334], [409.0, 135.88768115942023], [410.0, 131.72205438066462], [411.0, 132.48897058823553], [417.0, 176.14468085106387], [416.0, 196.6546391752576], [418.0, 138.0553633217993], [419.0, 152.9482758620689], [420.0, 157.28213166144198], [421.0, 145.34458672875425], [422.0, 209.14778325123154], [423.0, 201.2121212121211], [424.0, 128.15322580645167], [430.0, 120.27985739750443], [431.0, 131.10582010582007], [428.0, 132.3349056603773], [429.0, 127.68238213399492], [425.0, 118.74626865671638], [426.0, 116.58015267175576], [427.0, 121.5451713395639], [433.0, 98.38562091503266], [432.0, 126.16516516516523], [434.0, 133.50342465753423], [435.0, 133.68852459016398], [436.0, 143.46090534979422], [437.0, 146.96398891966763], [438.0, 148.22333333333333], [439.0, 134.55017301038075], [440.0, 121.79104477611938], [446.0, 118.82671480144401], [447.0, 150.41139240506337], [444.0, 204.95833333333343], [445.0, 150.52685421994875], [441.0, 163.96551724137927], [442.0, 184.0984251968503], [443.0, 207.76838235294102], [449.0, 171.6421319796953], [448.0, 146.78458498023704], [450.0, 169.97995991983964], [451.0, 137.50000000000003], [452.0, 131.18874172185434], [453.0, 151.0559210526319], [454.0, 154.61500000000004], [455.0, 176.5398457583547], [456.0, 207.611475409836], [462.0, 146.82532751091705], [463.0, 156.56055363321803], [460.0, 155.01791044776107], [461.0, 158.25], [457.0, 162.52552552552555], [458.0, 142.74074074074082], [459.0, 126.70558375634513], [465.0, 157.20370370370372], [464.0, 160.14361702127658], [466.0, 152.01410934744266], [467.0, 161.4357937310416], [468.0, 207.72571428571428], [469.0, 164.39869281045765], [470.0, 151.04913294797683], [471.0, 139.6529080675423], [472.0, 167.98240469208199], [478.0, 152.07593123209182], [479.0, 158.33757961783434], [476.0, 122.50591715976333], [477.0, 139.79670329670327], [473.0, 148.65827338129495], [474.0, 134.47766323024058], [475.0, 128.16908212560386], [481.0, 125.89756097560978], [480.0, 165.3095890410959], [482.0, 195.18318318318316], [483.0, 199.90712742980554], [484.0, 191.65250000000006], [485.0, 136.69009584664548], [486.0, 151.3466003316751], [487.0, 135.83185840707952], [488.0, 132.6009975062345], [494.0, 184.26495726495722], [495.0, 164.05617977528087], [492.0, 171.7578475336323], [493.0, 195.44583333333335], [489.0, 156.65306122448985], [490.0, 206.35593220338978], [491.0, 185.66139954853264], [497.0, 161.4453507340947], [496.0, 135.90476190476193], [498.0, 174.35195530726247], [499.0, 167.7465437788018], [500.0, 180.7738515901061], [501.0, 182.17061611374405], [502.0, 200.3591160220994], [503.0, 179.37542662116033], [504.0, 173.80718954248363], [510.0, 147.20873786407745], [511.0, 150.56401384083048], [508.0, 159.63701067615654], [509.0, 140.10399999999987], [505.0, 142.76207729468607], [506.0, 183.89913544668593], [507.0, 188.34883720930236], [515.0, 199.3829787234042], [512.0, 153.87292817679543], [526.0, 158.97900262467203], [527.0, 142.73958333333331], [524.0, 158.887573964497], [525.0, 156.98798798798816], [522.0, 167.54621848739498], [523.0, 155.05444126074497], [513.0, 145.56132075471706], [514.0, 214.57586206896542], [516.0, 195.52901785714292], [517.0, 193.60932944606412], [518.0, 190.99189189189204], [519.0, 155.37433862433858], [528.0, 135.8401639344262], [542.0, 267.33944954128435], [543.0, 201.39119804400983], [540.0, 206.9516728624536], [541.0, 215.93821510297477], [538.0, 193.0943396226416], [539.0, 158.0722433460076], [536.0, 157.29468599033825], [537.0, 152.10971223021593], [529.0, 171.75879396984928], [530.0, 164.72372372372382], [531.0, 176.0378457059679], [532.0, 166.98770491803282], [533.0, 211.48189415041767], [534.0, 188.079268292683], [535.0, 151.70920502092062], [520.0, 189.97124600638975], [521.0, 208.36507936507942], [547.0, 168.94531250000006], [544.0, 172.95341614906823], [558.0, 167.21372549019588], [559.0, 161.34104046242783], [556.0, 152.03579952267302], [557.0, 135.20058997050137], [554.0, 171.4066985645933], [555.0, 183.4026143790852], [545.0, 150.01183431952677], [546.0, 164.88638589618003], [548.0, 161.8063063063063], [549.0, 152.0566037735849], [550.0, 171.87709497206694], [551.0, 181.9504600141542], [560.0, 184.3899371069182], [574.0, 160.10399999999996], [575.0, 185.66942148760333], [572.0, 189.9999999999999], [573.0, 179.31397459165154], [570.0, 179.37124463519314], [571.0, 205.85567010309288], [568.0, 196.95833333333337], [569.0, 179.4291262135921], [561.0, 175.18758620689653], [562.0, 162.68900804289532], [563.0, 180.16666666666669], [564.0, 190.13306451612905], [565.0, 249.77744807121704], [566.0, 188.2285714285714], [567.0, 189.55035971223032], [552.0, 194.87330316742094], [553.0, 200.29398663697108], [579.0, 158.49127182044882], [576.0, 198.4372881355933], [590.0, 216.76261127596436], [591.0, 276.6517857142857], [588.0, 175.3115577889448], [589.0, 157.8488888888889], [586.0, 140.55835962145125], [587.0, 183.50583657587543], [577.0, 177.38647342995168], [578.0, 212.82932692307722], [580.0, 141.80952380952374], [581.0, 183.42821782178214], [582.0, 177.9055118110237], [583.0, 172.44296577946776], [592.0, 181.284705882353], [606.0, 184.21241830065367], [607.0, 244.75634127594148], [604.0, 183.93984962406037], [605.0, 191.39194915254225], [602.0, 193.0151515151515], [603.0, 176.60195227765718], [600.0, 194.4760705289673], [601.0, 180.44971098265913], [593.0, 218.23902439024397], [594.0, 214.60975609756096], [595.0, 195.54176334106737], [596.0, 227.90595611285275], [597.0, 192.93003618817835], [598.0, 178.78519855595684], [599.0, 184.23232323232324], [584.0, 169.2213247172859], [585.0, 162.5887096774193], [611.0, 156.51156812339337], [608.0, 177.81049250535335], [622.0, 294.7792207792206], [623.0, 190.11940298507463], [620.0, 270.59911894273165], [621.0, 195.26501766784452], [618.0, 269.63141025641005], [619.0, 366.1130952380952], [609.0, 181.53982300884948], [610.0, 173.33536121673018], [612.0, 175.5634517766496], [613.0, 193.84631578947352], [614.0, 255.17034700315455], [615.0, 222.35428571428565], [624.0, 174.76379310344848], [638.0, 209.3493975903612], [639.0, 261.8847402597403], [636.0, 241.58760107816713], [637.0, 232.0031055900621], [634.0, 203.86422976501296], [635.0, 208.45667447306803], [632.0, 166.6122448979592], [633.0, 202.95584415584415], [625.0, 170.82816229116938], [626.0, 186.564], [627.0, 188.50688705234145], [628.0, 187.14000000000001], [629.0, 192.2839756592292], [630.0, 172.13320463320468], [631.0, 198.66945606694554], [616.0, 191.82717678100252], [617.0, 231.45000000000005], [643.0, 238.24386252045826], [640.0, 295.9587628865977], [654.0, 216.6566757493189], [655.0, 227.6118047673102], [652.0, 190.14373088685008], [653.0, 196.55737704918027], [650.0, 299.61885790172636], [651.0, 242.07858243451463], [641.0, 271.6136363636362], [642.0, 202.20769230769235], [644.0, 202.62231462231472], [645.0, 203.58490566037747], [646.0, 212.26811594202906], [647.0, 203.68855316676374], [656.0, 245.6457960644008], [670.0, 222.67300380228139], [671.0, 221.91800000000018], [668.0, 274.587175792507], [669.0, 234.9834437086092], [666.0, 188.4087193460492], [667.0, 180.82142857142856], [664.0, 160.49136786188546], [665.0, 181.13056379821958], [657.0, 194.7398843930637], [658.0, 267.3285024154586], [659.0, 248.97202797202792], [660.0, 284.87700534759364], [661.0, 307.6358974358973], [662.0, 312.35023041474653], [663.0, 279.89645776566755], [648.0, 220.79999999999978], [649.0, 216.09045226130675], [675.0, 187.31698113207548], [672.0, 215.5704918032786], [687.0, 232.31445783132517], [685.0, 329.75793650793634], [686.0, 314.6335403726708], [682.0, 187.02325581395334], [683.0, 286.351851851852], [684.0, 221.90526315789478], [673.0, 231.79658792650923], [674.0, 166.51999999999998], [676.0, 264.1943005181349], [677.0, 232.21911421911392], [678.0, 204.2862903225806], [679.0, 232.7369369369371], [688.0, 339.20431328036375], [702.0, 217.66101694915253], [703.0, 195.8382352941177], [700.0, 229.18624641833824], [701.0, 266.6294117647059], [698.0, 225.23391812865478], [699.0, 233.65477439664195], [696.0, 240.49391304347836], [697.0, 221.67985611510792], [689.0, 268.5555555555558], [690.0, 223.87557603686648], [691.0, 195.56335616438366], [692.0, 191.90759493670896], [693.0, 161.23591549295782], [694.0, 218.83373983739835], [695.0, 182.9999999999999], [680.0, 231.9119170984455], [681.0, 224.67547169811323], [710.0, 268.4259259259259], [705.0, 176.25000000000003], [704.0, 254.65489849955873], [718.0, 277.816964285714], [719.0, 261.5459459459459], [716.0, 222.11170928667585], [717.0, 234.0867052023121], [714.0, 289.1434878587196], [715.0, 230.62649534780704], [706.0, 271.2846054333764], [707.0, 258.7096774193547], [709.0, 234.16774193548392], [708.0, 357.878947368421], [711.0, 209.72166666666675], [728.0, 213.76741130092006], [729.0, 172.64684014869883], [730.0, 232.10743801652887], [731.0, 272.05447470817126], [732.0, 292.04736842105257], [733.0, 343.29333333333324], [734.0, 283.1190900981272], [735.0, 228.83434343434337], [720.0, 213.08160442600285], [721.0, 222.43291473892907], [722.0, 248.82951653944025], [723.0, 232.93314231136608], [724.0, 208.3262411347518], [725.0, 284.47477360931475], [726.0, 289.64956011730214], [727.0, 218.23011536126302], [712.0, 233.26164383561633], [713.0, 261.7957559681697], [739.0, 225.3622291021673], [736.0, 243.58064516129033], [750.0, 246.85266457680225], [751.0, 271.8989547038327], [748.0, 218.26999999999995], [749.0, 211.7867647058823], [746.0, 282.364161849711], [747.0, 190.39537869062914], [737.0, 211.8640000000002], [738.0, 205.9589041095888], [740.0, 265.6364494806427], [741.0, 201.63293650793665], [742.0, 254.43612903225798], [743.0, 291.6744186046512], [752.0, 276.3468750000002], [766.0, 218.99999999999991], [767.0, 195.33142857142863], [764.0, 238.48160261651688], [765.0, 243.82269503546104], [762.0, 204.36744186046508], [763.0, 336.57917019474974], [760.0, 269.5319926873855], [761.0, 285.0371819960861], [753.0, 262.2793388429751], [754.0, 447.9060773480664], [755.0, 294.0], [756.0, 318.6911581569114], [757.0, 266.190909090909], [758.0, 266.35745296671456], [759.0, 233.5763440860214], [744.0, 299.5771971496437], [745.0, 350.635], [771.0, 230.42152466367713], [768.0, 245.59354838709666], [783.0, 251.21156773211558], [781.0, 309.88], [782.0, 304.48989898989885], [779.0, 297.26646706586837], [780.0, 336.3371298405465], [769.0, 196.88340807174896], [770.0, 256.6524953789277], [772.0, 257.7319422150884], [773.0, 307.69174757281564], [774.0, 240.07569721115544], [775.0, 306.93626513702964], [784.0, 317.01538461538456], [798.0, 235.77611940298513], [799.0, 226.50950570342218], [796.0, 264.3627608346713], [797.0, 238.96893667861406], [794.0, 245.45977011494253], [795.0, 241.25781250000014], [792.0, 335.6425755584759], [793.0, 334.95281933256643], [785.0, 313.93488372093015], [786.0, 254.44784580498862], [787.0, 263.44820441988924], [788.0, 298.36075949367086], [789.0, 281.2364217252395], [790.0, 269.8701298701301], [791.0, 218.06818181818198], [776.0, 262.658585858586], [777.0, 238.2021371326804], [778.0, 304.96183206106855], [803.0, 239.84931506849313], [800.0, 251.06991260923857], [814.0, 250.21686746987942], [815.0, 259.18000000000006], [812.0, 300.25716145833326], [813.0, 254.69451073985698], [810.0, 249.96053897978817], [811.0, 302.70527670527656], [801.0, 288.59606879606923], [802.0, 311.20661157024796], [804.0, 266.9067688378029], [805.0, 283.67460317460336], [806.0, 307.6520963425512], [807.0, 228.7694805194805], [816.0, 251.1805433829971], [830.0, 293.64805825242706], [831.0, 285.25652173913005], [828.0, 230.34511627906986], [829.0, 263.0495912806537], [826.0, 280.4274193548388], [827.0, 343.6454545454545], [824.0, 302.89019607843153], [825.0, 317.219492868463], [817.0, 258.85780885780866], [818.0, 239.9981549815499], [819.0, 333.99294710327433], [820.0, 279.5469208211138], [821.0, 211.40357852882687], [822.0, 266.77394305435797], [823.0, 279.7333333333334], [808.0, 276.48024316109434], [809.0, 274.3960396039601], [835.0, 211.4368932038835], [832.0, 249.98042704626343], [847.0, 303.98851590106005], [846.0, 235.59171597633147], [844.0, 309.0404984423686], [845.0, 220.91722972972977], [842.0, 250.96357615894036], [843.0, 264.92235801581575], [833.0, 326.4861538461536], [834.0, 282.68181818181813], [836.0, 261.92957746478874], [837.0, 275.76047904191614], [838.0, 231.49323786793946], [839.0, 216.67303102625314], [848.0, 358.04592314901606], [862.0, 373.0148731408571], [863.0, 342.7939262472882], [860.0, 279.70370370370364], [861.0, 275.06936416184976], [858.0, 265.0458452722067], [859.0, 230.2011494252874], [856.0, 244.8], [857.0, 236.18309859154928], [849.0, 427.51405622489943], [850.0, 254.96473906911143], [851.0, 316.6980769230771], [853.0, 316.21176470588244], [854.0, 315.86634349030527], [855.0, 232.2133333333332], [852.0, 326.8091796169137], [840.0, 293.6754201680675], [841.0, 348.7949871465293], [869.0, 285.04665409990525], [865.0, 283.0293685756235], [864.0, 276.1544050862856], [878.0, 316.36704730832025], [879.0, 314.5837104072398], [876.0, 278.41539528432764], [877.0, 413.18215158924215], [874.0, 401.88043478260875], [875.0, 274.95009596929], [866.0, 305.4304461942257], [867.0, 287.33630952380963], [868.0, 291.9569657184537], [871.0, 356.909090909091], [870.0, 282.41666666666663], [888.0, 283.30075625363577], [889.0, 384.24905183312313], [890.0, 299.9868995633187], [891.0, 354.44086021505353], [892.0, 273.1203319502075], [893.0, 339.67803030303037], [894.0, 293.16149068323], [895.0, 280.27389443651913], [880.0, 246.30751708428227], [881.0, 261.74558303886954], [882.0, 241.1339522546417], [883.0, 304.2189616252821], [884.0, 323.1874999999999], [885.0, 251.46280991735537], [886.0, 235.20813771517976], [887.0, 247.75000000000003], [872.0, 320.599020293911], [873.0, 346.18092105263145], [899.0, 349.0577249575552], [896.0, 322.7751820388349], [910.0, 363.69273743016737], [911.0, 337.13306451612914], [908.0, 328.30011074197085], [909.0, 373.99342105263156], [906.0, 326.59523809523813], [907.0, 266.199845081332], [897.0, 342.91498405951086], [898.0, 363.55335968379427], [900.0, 321.2778366914111], [901.0, 343.4420289855076], [902.0, 336.9314374756528], [903.0, 252.35649935649934], [912.0, 231.65567765567775], [926.0, 311.78849557522125], [927.0, 284.64705882352945], [924.0, 400.0068807339448], [925.0, 392.9378881987582], [922.0, 318.03080082135523], [923.0, 362.6130790190737], [920.0, 263.70560190703264], [921.0, 326.26885880077356], [913.0, 299.0075258701792], [914.0, 273.7292870905588], [915.0, 362.25779967159247], [916.0, 341.76518493383156], [917.0, 330.46466948876633], [918.0, 383.497064579256], [919.0, 383.5794392523363], [904.0, 323.00640614990317], [905.0, 362.9634387351781], [931.0, 272.6314102564102], [928.0, 276.13916500994054], [942.0, 290.6588983050849], [943.0, 344.1705882352938], [940.0, 262.8190789473683], [941.0, 291.56237218813897], [938.0, 272.9359296482416], [939.0, 235.21264367816096], [929.0, 260.5800865800865], [930.0, 202.62500000000017], [932.0, 332.26850094876704], [933.0, 402.5497287522609], [934.0, 328.84627575277375], [935.0, 305.3538461538459], [944.0, 319.10969793322806], [958.0, 286.36280056577147], [959.0, 293.3565989847719], [956.0, 331.5210792580103], [957.0, 325.5425051334697], [954.0, 315.3806451612909], [955.0, 335.29302325581375], [952.0, 423.32248219735567], [953.0, 328.38907849829366], [945.0, 340.10841654778875], [946.0, 353.73035714285777], [947.0, 391.1307692307689], [948.0, 342.0329809725158], [949.0, 342.017107942974], [950.0, 324.64160839160814], [951.0, 312.5902726602806], [936.0, 370.39095992544304], [937.0, 396.1777860603797], [963.0, 355.6570397111914], [960.0, 394.58641975308615], [975.0, 397.2669753086419], [973.0, 338.9802217560684], [974.0, 389.4031180400891], [971.0, 326.88313539192444], [970.0, 418.2782540919717], [972.0, 379.0561622464899], [961.0, 337.77220077220085], [962.0, 360.5554585152839], [964.0, 462.2397959183679], [965.0, 300.90041493775936], [966.0, 324.76998528690535], [967.0, 269.5192307692308], [976.0, 309.5764075067029], [990.0, 325.2245560848856], [991.0, 478.0024466969592], [988.0, 301.5229441163106], [989.0, 392.8960814028999], [986.0, 424.30895915678536], [987.0, 274.89075630252086], [984.0, 396.6416666666664], [985.0, 362.944099378882], [977.0, 344.8143851508115], [978.0, 452.99176728869395], [979.0, 430.0007137758738], [980.0, 352.18078175895755], [981.0, 255.06376360808704], [982.0, 377.8643486777671], [983.0, 325.29565217391405], [968.0, 362.08031088082913], [969.0, 392.1514622435616], [992.0, 319.41545524100985], [993.0, 353.56850140618604], [994.0, 275.51194029850706], [995.0, 300.3289473684208], [996.0, 359.592807424594], [997.0, 350.3969012837534], [998.0, 341.592655849701], [999.0, 364.3291128972556], [1.0, 53.0]], "isOverall": false, "label": "HTTP请求", "isController": false}, {"data": [[926.6431601602065, 335.63533233231743]], "isOverall": false, "label": "HTTP请求-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 999.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 250178.13333333333, "minX": 1.49458146E12, "maxY": 1870369.5, "series": [{"data": [[1.49458164E12, 1776232.35], [1.49458194E12, 1782046.8], [1.49458146E12, 1399782.3], [1.49458206E12, 1773341.55], [1.494582E12, 1785879.3], [1.4945817E12, 1779385.95], [1.49458212E12, 1870369.5], [1.49458182E12, 1788540.15], [1.49458176E12, 1800322.35], [1.49458188E12, 1772881.65], [1.49458158E12, 1800924.6], [1.49458152E12, 1814612.1], [1.49458218E12, 733781.4]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.49458164E12, 605595.2], [1.49458194E12, 607577.6], [1.49458146E12, 477246.93333333335], [1.49458206E12, 604609.6], [1.494582E12, 608884.2666666667], [1.4945817E12, 606670.4], [1.49458212E12, 637690.6666666666], [1.49458182E12, 609791.4666666667], [1.49458176E12, 613808.5333333333], [1.49458188E12, 604452.8], [1.49458158E12, 614013.8666666667], [1.49458152E12, 618680.5333333333], [1.49458218E12, 250178.13333333333]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49458218E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 147.91586581508116, "minX": 1.49458146E12, "maxY": 367.6463538680565, "series": [{"data": [[1.49458164E12, 367.6463538680565], [1.49458194E12, 365.3387467433507], [1.49458146E12, 160.04605973371557], [1.49458206E12, 361.3753897832074], [1.494582E12, 363.17247722171487], [1.4945817E12, 365.53618746961314], [1.49458212E12, 282.04885545342387], [1.49458182E12, 362.96474160784123], [1.49458176E12, 361.55188458334084], [1.49458188E12, 367.0383615285366], [1.49458158E12, 360.6367500060789], [1.49458152E12, 352.0024258076922], [1.49458218E12, 147.91586581508116]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49458218E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 147.90856861457684, "minX": 1.49458146E12, "maxY": 367.63634850474244, "series": [{"data": [[1.49458164E12, 367.63634850474244], [1.49458194E12, 365.3283807697925], [1.49458146E12, 160.03747046951386], [1.49458206E12, 361.3609778387021], [1.494582E12, 363.1613977215592], [1.4945817E12, 365.5255598427043], [1.49458212E12, 282.03833499209236], [1.49458182E12, 362.95579691068343], [1.49458176E12, 361.54017018118935], [1.49458188E12, 367.0271328602216], [1.49458158E12, 360.6232458593769], [1.49458152E12, 351.9917812186935], [1.49458218E12, 147.90856861457684]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49458218E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.4092998268966771, "minX": 1.49458146E12, "maxY": 2.098730452124435, "series": [{"data": [[1.49458164E12, 1.5762608422259796], [1.49458194E12, 1.8580961510101524], [1.49458146E12, 0.47454511319367554], [1.49458206E12, 2.0468295574532758], [1.494582E12, 1.8846370804566792], [1.4945817E12, 1.8247210786395343], [1.49458212E12, 1.07342661436683], [1.49458182E12, 1.8250120915652672], [1.49458176E12, 1.5492874651031485], [1.49458188E12, 1.694207168312667], [1.49458158E12, 2.098730452124435], [1.49458152E12, 1.60653640521848], [1.49458218E12, 0.4092998268966771]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49458218E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 43.0, "minX": 1.49458146E12, "maxY": 1794.0, "series": [{"data": [[1.49458164E12, 1384.0], [1.49458194E12, 1794.0], [1.49458146E12, 802.0], [1.49458206E12, 1491.0], [1.494582E12, 1328.0], [1.4945817E12, 1302.0], [1.49458212E12, 970.0], [1.49458182E12, 1305.0], [1.49458176E12, 1259.0], [1.49458188E12, 1378.0], [1.49458158E12, 1387.0], [1.49458152E12, 1365.0], [1.49458218E12, 524.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.49458164E12, 51.0], [1.49458194E12, 51.0], [1.49458146E12, 51.0], [1.49458206E12, 51.0], [1.494582E12, 52.0], [1.4945817E12, 52.0], [1.49458212E12, 51.0], [1.49458182E12, 52.0], [1.49458176E12, 51.0], [1.49458188E12, 52.0], [1.49458158E12, 52.0], [1.49458152E12, 51.0], [1.49458218E12, 43.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.49458164E12, 553.0], [1.49458194E12, 590.0], [1.49458146E12, 398.0], [1.49458206E12, 547.0], [1.494582E12, 563.0], [1.4945817E12, 591.0], [1.49458212E12, 372.0], [1.49458182E12, 619.0], [1.49458176E12, 608.0], [1.49458188E12, 592.0], [1.49458158E12, 568.0], [1.49458152E12, 566.0], [1.49458218E12, 140.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.49458164E12, 817.0], [1.49458194E12, 848.0], [1.49458146E12, 556.0], [1.49458206E12, 760.9900000000016], [1.494582E12, 806.0], [1.4945817E12, 775.0], [1.49458212E12, 486.0], [1.49458182E12, 939.0], [1.49458176E12, 813.0], [1.49458188E12, 793.0], [1.49458158E12, 758.0], [1.49458152E12, 763.0], [1.49458218E12, 232.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.49458164E12, 624.0], [1.49458194E12, 685.9500000000007], [1.49458146E12, 458.0], [1.49458206E12, 625.0], [1.494582E12, 636.0], [1.4945817E12, 659.9500000000007], [1.49458212E12, 414.0], [1.49458182E12, 690.0], [1.49458176E12, 699.9500000000007], [1.49458188E12, 660.0], [1.49458158E12, 627.0], [1.49458152E12, 634.0], [1.49458218E12, 165.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49458218E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 89.0, "minX": 7012.0, "maxY": 357.0, "series": [{"data": [[42213.0, 333.0], [42501.0, 334.0], [41907.0, 357.0], [42744.0, 323.0], [41949.0, 325.0], [44468.0, 337.0], [44413.0, 327.0], [43337.0, 334.0], [43094.0, 334.0], [45718.0, 343.0], [50810.0, 218.0], [7012.0, 89.0], [7834.0, 238.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 50810.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 89.0, "minX": 7012.0, "maxY": 357.0, "series": [{"data": [[42213.0, 333.0], [42501.0, 334.0], [41907.0, 357.0], [42744.0, 323.0], [41949.0, 325.0], [44468.0, 337.0], [44413.0, 327.0], [43337.0, 334.0], [43094.0, 334.0], [45718.0, 343.0], [50810.0, 218.0], [7012.0, 89.0], [7834.0, 238.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 50810.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1106.4833333333333, "minX": 1.49458146E12, "maxY": 2841.7, "series": [{"data": [[1.49458164E12, 2703.6], [1.49458194E12, 2712.633333333333], [1.49458146E12, 2144.133333333333], [1.49458206E12, 2697.9666666666667], [1.494582E12, 2718.25], [1.4945817E12, 2708.3333333333335], [1.49458212E12, 2841.7], [1.49458182E12, 2722.266666666667], [1.49458176E12, 2740.25], [1.49458188E12, 2698.266666666667], [1.49458158E12, 2741.0666666666666], [1.49458152E12, 2765.05], [1.49458218E12, 1106.4833333333333]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49458218E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1116.8666666666666, "minX": 1.49458146E12, "maxY": 2846.8333333333335, "series": [{"data": [[1.49458164E12, 2703.55], [1.49458194E12, 2712.4], [1.49458146E12, 2130.5666666666666], [1.49458206E12, 2699.15], [1.494582E12, 2718.233333333333], [1.4945817E12, 2708.35], [1.49458212E12, 2846.8333333333335], [1.49458182E12, 2722.2833333333333], [1.49458176E12, 2740.2166666666667], [1.49458188E12, 2698.45], [1.49458158E12, 2741.133333333333], [1.49458152E12, 2761.9666666666667], [1.49458218E12, 1116.8666666666666]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49458218E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1116.8666666666666, "minX": 1.49458146E12, "maxY": 2846.8333333333335, "series": [{"data": [[1.49458164E12, 2703.55], [1.49458194E12, 2712.4], [1.49458146E12, 2130.5666666666666], [1.49458206E12, 2699.15], [1.494582E12, 2718.233333333333], [1.4945817E12, 2708.35], [1.49458212E12, 2846.8333333333335], [1.49458182E12, 2722.2833333333333], [1.49458176E12, 2740.2166666666667], [1.49458188E12, 2698.45], [1.49458158E12, 2741.133333333333], [1.49458152E12, 2761.9666666666667], [1.49458218E12, 1116.8666666666666]], "isOverall": false, "label": "HTTP请求-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49458218E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
