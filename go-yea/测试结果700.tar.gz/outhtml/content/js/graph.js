/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 0 : 0;
        var yOffset = options.yaxis.mode === "time" ? 0 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 7.0, "minX": 0.0, "maxY": 10134.0, "series": [{"data": [[0.0, 7.0], [0.1, 32.0], [0.2, 38.0], [0.3, 44.0], [0.4, 51.0], [0.5, 52.0], [0.6, 52.0], [0.7, 52.0], [0.8, 53.0], [0.9, 53.0], [1.0, 53.0], [1.1, 53.0], [1.2, 53.0], [1.3, 54.0], [1.4, 54.0], [1.5, 54.0], [1.6, 55.0], [1.7, 55.0], [1.8, 55.0], [1.9, 56.0], [2.0, 56.0], [2.1, 56.0], [2.2, 57.0], [2.3, 57.0], [2.4, 58.0], [2.5, 58.0], [2.6, 58.0], [2.7, 59.0], [2.8, 59.0], [2.9, 60.0], [3.0, 60.0], [3.1, 61.0], [3.2, 61.0], [3.3, 62.0], [3.4, 62.0], [3.5, 63.0], [3.6, 63.0], [3.7, 64.0], [3.8, 64.0], [3.9, 65.0], [4.0, 65.0], [4.1, 66.0], [4.2, 66.0], [4.3, 67.0], [4.4, 68.0], [4.5, 68.0], [4.6, 69.0], [4.7, 69.0], [4.8, 70.0], [4.9, 70.0], [5.0, 71.0], [5.1, 71.0], [5.2, 72.0], [5.3, 72.0], [5.4, 73.0], [5.5, 74.0], [5.6, 74.0], [5.7, 75.0], [5.8, 75.0], [5.9, 76.0], [6.0, 76.0], [6.1, 77.0], [6.2, 77.0], [6.3, 78.0], [6.4, 78.0], [6.5, 79.0], [6.6, 79.0], [6.7, 79.0], [6.8, 80.0], [6.9, 80.0], [7.0, 81.0], [7.1, 81.0], [7.2, 82.0], [7.3, 82.0], [7.4, 82.0], [7.5, 83.0], [7.6, 83.0], [7.7, 84.0], [7.8, 84.0], [7.9, 85.0], [8.0, 85.0], [8.1, 85.0], [8.2, 86.0], [8.3, 86.0], [8.4, 87.0], [8.5, 87.0], [8.6, 87.0], [8.7, 88.0], [8.8, 88.0], [8.9, 89.0], [9.0, 89.0], [9.1, 89.0], [9.2, 90.0], [9.3, 90.0], [9.4, 91.0], [9.5, 91.0], [9.6, 92.0], [9.7, 92.0], [9.8, 92.0], [9.9, 93.0], [10.0, 93.0], [10.1, 94.0], [10.2, 94.0], [10.3, 95.0], [10.4, 95.0], [10.5, 95.0], [10.6, 96.0], [10.7, 96.0], [10.8, 97.0], [10.9, 97.0], [11.0, 97.0], [11.1, 98.0], [11.2, 98.0], [11.3, 99.0], [11.4, 99.0], [11.5, 100.0], [11.6, 100.0], [11.7, 100.0], [11.8, 101.0], [11.9, 101.0], [12.0, 102.0], [12.1, 102.0], [12.2, 102.0], [12.3, 103.0], [12.4, 103.0], [12.5, 103.0], [12.6, 104.0], [12.7, 104.0], [12.8, 105.0], [12.9, 105.0], [13.0, 105.0], [13.1, 106.0], [13.2, 106.0], [13.3, 106.0], [13.4, 107.0], [13.5, 107.0], [13.6, 107.0], [13.7, 108.0], [13.8, 108.0], [13.9, 108.0], [14.0, 109.0], [14.1, 109.0], [14.2, 109.0], [14.3, 110.0], [14.4, 110.0], [14.5, 110.0], [14.6, 111.0], [14.7, 111.0], [14.8, 111.0], [14.9, 112.0], [15.0, 112.0], [15.1, 112.0], [15.2, 113.0], [15.3, 113.0], [15.4, 113.0], [15.5, 114.0], [15.6, 114.0], [15.7, 114.0], [15.8, 115.0], [15.9, 115.0], [16.0, 115.0], [16.1, 116.0], [16.2, 116.0], [16.3, 116.0], [16.4, 117.0], [16.5, 117.0], [16.6, 117.0], [16.7, 118.0], [16.8, 118.0], [16.9, 118.0], [17.0, 119.0], [17.1, 119.0], [17.2, 119.0], [17.3, 120.0], [17.4, 120.0], [17.5, 120.0], [17.6, 121.0], [17.7, 121.0], [17.8, 121.0], [17.9, 122.0], [18.0, 122.0], [18.1, 122.0], [18.2, 123.0], [18.3, 123.0], [18.4, 123.0], [18.5, 124.0], [18.6, 124.0], [18.7, 124.0], [18.8, 125.0], [18.9, 125.0], [19.0, 125.0], [19.1, 126.0], [19.2, 126.0], [19.3, 126.0], [19.4, 127.0], [19.5, 127.0], [19.6, 127.0], [19.7, 127.0], [19.8, 128.0], [19.9, 128.0], [20.0, 128.0], [20.1, 129.0], [20.2, 129.0], [20.3, 129.0], [20.4, 130.0], [20.5, 130.0], [20.6, 130.0], [20.7, 131.0], [20.8, 131.0], [20.9, 131.0], [21.0, 131.0], [21.1, 132.0], [21.2, 132.0], [21.3, 132.0], [21.4, 133.0], [21.5, 133.0], [21.6, 133.0], [21.7, 134.0], [21.8, 134.0], [21.9, 134.0], [22.0, 134.0], [22.1, 135.0], [22.2, 135.0], [22.3, 135.0], [22.4, 136.0], [22.5, 136.0], [22.6, 136.0], [22.7, 137.0], [22.8, 137.0], [22.9, 137.0], [23.0, 137.0], [23.1, 138.0], [23.2, 138.0], [23.3, 138.0], [23.4, 139.0], [23.5, 139.0], [23.6, 139.0], [23.7, 140.0], [23.8, 140.0], [23.9, 140.0], [24.0, 140.0], [24.1, 141.0], [24.2, 141.0], [24.3, 141.0], [24.4, 142.0], [24.5, 142.0], [24.6, 142.0], [24.7, 143.0], [24.8, 143.0], [24.9, 143.0], [25.0, 143.0], [25.1, 144.0], [25.2, 144.0], [25.3, 144.0], [25.4, 145.0], [25.5, 145.0], [25.6, 145.0], [25.7, 146.0], [25.8, 146.0], [25.9, 146.0], [26.0, 146.0], [26.1, 147.0], [26.2, 147.0], [26.3, 147.0], [26.4, 148.0], [26.5, 148.0], [26.6, 148.0], [26.7, 149.0], [26.8, 149.0], [26.9, 149.0], [27.0, 150.0], [27.1, 150.0], [27.2, 150.0], [27.3, 150.0], [27.4, 151.0], [27.5, 151.0], [27.6, 151.0], [27.7, 152.0], [27.8, 152.0], [27.9, 152.0], [28.0, 153.0], [28.1, 153.0], [28.2, 153.0], [28.3, 153.0], [28.4, 154.0], [28.5, 154.0], [28.6, 154.0], [28.7, 155.0], [28.8, 155.0], [28.9, 155.0], [29.0, 156.0], [29.1, 156.0], [29.2, 156.0], [29.3, 156.0], [29.4, 157.0], [29.5, 157.0], [29.6, 157.0], [29.7, 158.0], [29.8, 158.0], [29.9, 158.0], [30.0, 159.0], [30.1, 159.0], [30.2, 159.0], [30.3, 159.0], [30.4, 160.0], [30.5, 160.0], [30.6, 160.0], [30.7, 161.0], [30.8, 161.0], [30.9, 161.0], [31.0, 161.0], [31.1, 162.0], [31.2, 162.0], [31.3, 162.0], [31.4, 163.0], [31.5, 163.0], [31.6, 163.0], [31.7, 163.0], [31.8, 164.0], [31.9, 164.0], [32.0, 164.0], [32.1, 165.0], [32.2, 165.0], [32.3, 165.0], [32.4, 165.0], [32.5, 166.0], [32.6, 166.0], [32.7, 166.0], [32.8, 167.0], [32.9, 167.0], [33.0, 167.0], [33.1, 167.0], [33.2, 168.0], [33.3, 168.0], [33.4, 168.0], [33.5, 169.0], [33.6, 169.0], [33.7, 169.0], [33.8, 169.0], [33.9, 170.0], [34.0, 170.0], [34.1, 170.0], [34.2, 171.0], [34.3, 171.0], [34.4, 171.0], [34.5, 172.0], [34.6, 172.0], [34.7, 172.0], [34.8, 172.0], [34.9, 173.0], [35.0, 173.0], [35.1, 173.0], [35.2, 174.0], [35.3, 174.0], [35.4, 174.0], [35.5, 174.0], [35.6, 175.0], [35.7, 175.0], [35.8, 175.0], [35.9, 176.0], [36.0, 176.0], [36.1, 176.0], [36.2, 177.0], [36.3, 177.0], [36.4, 177.0], [36.5, 177.0], [36.6, 178.0], [36.7, 178.0], [36.8, 178.0], [36.9, 179.0], [37.0, 179.0], [37.1, 179.0], [37.2, 180.0], [37.3, 180.0], [37.4, 180.0], [37.5, 180.0], [37.6, 181.0], [37.7, 181.0], [37.8, 181.0], [37.9, 182.0], [38.0, 182.0], [38.1, 182.0], [38.2, 183.0], [38.3, 183.0], [38.4, 183.0], [38.5, 184.0], [38.6, 184.0], [38.7, 184.0], [38.8, 184.0], [38.9, 185.0], [39.0, 185.0], [39.1, 185.0], [39.2, 186.0], [39.3, 186.0], [39.4, 186.0], [39.5, 187.0], [39.6, 187.0], [39.7, 187.0], [39.8, 187.0], [39.9, 188.0], [40.0, 188.0], [40.1, 188.0], [40.2, 189.0], [40.3, 189.0], [40.4, 189.0], [40.5, 190.0], [40.6, 190.0], [40.7, 190.0], [40.8, 190.0], [40.9, 191.0], [41.0, 191.0], [41.1, 191.0], [41.2, 192.0], [41.3, 192.0], [41.4, 192.0], [41.5, 193.0], [41.6, 193.0], [41.7, 193.0], [41.8, 193.0], [41.9, 194.0], [42.0, 194.0], [42.1, 194.0], [42.2, 195.0], [42.3, 195.0], [42.4, 195.0], [42.5, 196.0], [42.6, 196.0], [42.7, 196.0], [42.8, 197.0], [42.9, 197.0], [43.0, 197.0], [43.1, 197.0], [43.2, 198.0], [43.3, 198.0], [43.4, 198.0], [43.5, 199.0], [43.6, 199.0], [43.7, 199.0], [43.8, 200.0], [43.9, 200.0], [44.0, 200.0], [44.1, 201.0], [44.2, 201.0], [44.3, 201.0], [44.4, 202.0], [44.5, 202.0], [44.6, 202.0], [44.7, 202.0], [44.8, 203.0], [44.9, 203.0], [45.0, 203.0], [45.1, 204.0], [45.2, 204.0], [45.3, 204.0], [45.4, 205.0], [45.5, 205.0], [45.6, 205.0], [45.7, 206.0], [45.8, 206.0], [45.9, 206.0], [46.0, 207.0], [46.1, 207.0], [46.2, 207.0], [46.3, 208.0], [46.4, 208.0], [46.5, 208.0], [46.6, 208.0], [46.7, 209.0], [46.8, 209.0], [46.9, 209.0], [47.0, 210.0], [47.1, 210.0], [47.2, 210.0], [47.3, 211.0], [47.4, 211.0], [47.5, 211.0], [47.6, 212.0], [47.7, 212.0], [47.8, 212.0], [47.9, 213.0], [48.0, 213.0], [48.1, 213.0], [48.2, 214.0], [48.3, 214.0], [48.4, 214.0], [48.5, 215.0], [48.6, 215.0], [48.7, 215.0], [48.8, 215.0], [48.9, 216.0], [49.0, 216.0], [49.1, 216.0], [49.2, 217.0], [49.3, 217.0], [49.4, 217.0], [49.5, 218.0], [49.6, 218.0], [49.7, 218.0], [49.8, 219.0], [49.9, 219.0], [50.0, 219.0], [50.1, 220.0], [50.2, 220.0], [50.3, 220.0], [50.4, 221.0], [50.5, 221.0], [50.6, 221.0], [50.7, 222.0], [50.8, 222.0], [50.9, 222.0], [51.0, 223.0], [51.1, 223.0], [51.2, 223.0], [51.3, 224.0], [51.4, 224.0], [51.5, 224.0], [51.6, 225.0], [51.7, 225.0], [51.8, 225.0], [51.9, 226.0], [52.0, 226.0], [52.1, 226.0], [52.2, 227.0], [52.3, 227.0], [52.4, 227.0], [52.5, 228.0], [52.6, 228.0], [52.7, 228.0], [52.8, 229.0], [52.9, 229.0], [53.0, 229.0], [53.1, 230.0], [53.2, 230.0], [53.3, 230.0], [53.4, 231.0], [53.5, 231.0], [53.6, 231.0], [53.7, 232.0], [53.8, 232.0], [53.9, 232.0], [54.0, 233.0], [54.1, 233.0], [54.2, 233.0], [54.3, 234.0], [54.4, 234.0], [54.5, 235.0], [54.6, 235.0], [54.7, 235.0], [54.8, 236.0], [54.9, 236.0], [55.0, 236.0], [55.1, 237.0], [55.2, 237.0], [55.3, 237.0], [55.4, 238.0], [55.5, 238.0], [55.6, 238.0], [55.7, 239.0], [55.8, 239.0], [55.9, 239.0], [56.0, 240.0], [56.1, 240.0], [56.2, 240.0], [56.3, 241.0], [56.4, 241.0], [56.5, 241.0], [56.6, 242.0], [56.7, 242.0], [56.8, 243.0], [56.9, 243.0], [57.0, 243.0], [57.1, 244.0], [57.2, 244.0], [57.3, 244.0], [57.4, 245.0], [57.5, 245.0], [57.6, 245.0], [57.7, 246.0], [57.8, 246.0], [57.9, 247.0], [58.0, 247.0], [58.1, 247.0], [58.2, 248.0], [58.3, 248.0], [58.4, 248.0], [58.5, 249.0], [58.6, 249.0], [58.7, 250.0], [58.8, 250.0], [58.9, 250.0], [59.0, 251.0], [59.1, 251.0], [59.2, 251.0], [59.3, 252.0], [59.4, 252.0], [59.5, 253.0], [59.6, 253.0], [59.7, 253.0], [59.8, 254.0], [59.9, 254.0], [60.0, 254.0], [60.1, 255.0], [60.2, 255.0], [60.3, 256.0], [60.4, 256.0], [60.5, 256.0], [60.6, 257.0], [60.7, 257.0], [60.8, 257.0], [60.9, 258.0], [61.0, 258.0], [61.1, 259.0], [61.2, 259.0], [61.3, 259.0], [61.4, 260.0], [61.5, 260.0], [61.6, 261.0], [61.7, 261.0], [61.8, 261.0], [61.9, 262.0], [62.0, 262.0], [62.1, 263.0], [62.2, 263.0], [62.3, 263.0], [62.4, 264.0], [62.5, 264.0], [62.6, 265.0], [62.7, 265.0], [62.8, 265.0], [62.9, 266.0], [63.0, 266.0], [63.1, 267.0], [63.2, 267.0], [63.3, 267.0], [63.4, 268.0], [63.5, 268.0], [63.6, 268.0], [63.7, 269.0], [63.8, 269.0], [63.9, 270.0], [64.0, 270.0], [64.1, 270.0], [64.2, 271.0], [64.3, 271.0], [64.4, 272.0], [64.5, 272.0], [64.6, 272.0], [64.7, 273.0], [64.8, 273.0], [64.9, 274.0], [65.0, 274.0], [65.1, 275.0], [65.2, 275.0], [65.3, 275.0], [65.4, 276.0], [65.5, 276.0], [65.6, 277.0], [65.7, 277.0], [65.8, 277.0], [65.9, 278.0], [66.0, 278.0], [66.1, 279.0], [66.2, 279.0], [66.3, 280.0], [66.4, 280.0], [66.5, 280.0], [66.6, 281.0], [66.7, 281.0], [66.8, 282.0], [66.9, 282.0], [67.0, 282.0], [67.1, 283.0], [67.2, 283.0], [67.3, 284.0], [67.4, 284.0], [67.5, 285.0], [67.6, 285.0], [67.7, 286.0], [67.8, 286.0], [67.9, 286.0], [68.0, 287.0], [68.1, 287.0], [68.2, 288.0], [68.3, 288.0], [68.4, 289.0], [68.5, 289.0], [68.6, 290.0], [68.7, 290.0], [68.8, 290.0], [68.9, 291.0], [69.0, 291.0], [69.1, 292.0], [69.2, 292.0], [69.3, 293.0], [69.4, 293.0], [69.5, 294.0], [69.6, 294.0], [69.7, 295.0], [69.8, 295.0], [69.9, 295.0], [70.0, 296.0], [70.1, 296.0], [70.2, 297.0], [70.3, 297.0], [70.4, 298.0], [70.5, 298.0], [70.6, 299.0], [70.7, 299.0], [70.8, 300.0], [70.9, 300.0], [71.0, 300.0], [71.1, 301.0], [71.2, 301.0], [71.3, 302.0], [71.4, 302.0], [71.5, 303.0], [71.6, 303.0], [71.7, 304.0], [71.8, 304.0], [71.9, 305.0], [72.0, 305.0], [72.1, 305.0], [72.2, 306.0], [72.3, 306.0], [72.4, 307.0], [72.5, 307.0], [72.6, 308.0], [72.7, 308.0], [72.8, 309.0], [72.9, 309.0], [73.0, 310.0], [73.1, 310.0], [73.2, 311.0], [73.3, 311.0], [73.4, 312.0], [73.5, 312.0], [73.6, 313.0], [73.7, 313.0], [73.8, 314.0], [73.9, 314.0], [74.0, 315.0], [74.1, 315.0], [74.2, 316.0], [74.3, 316.0], [74.4, 317.0], [74.5, 317.0], [74.6, 317.0], [74.7, 318.0], [74.8, 318.0], [74.9, 319.0], [75.0, 319.0], [75.1, 320.0], [75.2, 320.0], [75.3, 321.0], [75.4, 321.0], [75.5, 322.0], [75.6, 322.0], [75.7, 323.0], [75.8, 323.0], [75.9, 324.0], [76.0, 324.0], [76.1, 325.0], [76.2, 325.0], [76.3, 326.0], [76.4, 327.0], [76.5, 327.0], [76.6, 328.0], [76.7, 328.0], [76.8, 329.0], [76.9, 329.0], [77.0, 330.0], [77.1, 330.0], [77.2, 331.0], [77.3, 331.0], [77.4, 332.0], [77.5, 332.0], [77.6, 333.0], [77.7, 334.0], [77.8, 334.0], [77.9, 335.0], [78.0, 335.0], [78.1, 336.0], [78.2, 336.0], [78.3, 337.0], [78.4, 337.0], [78.5, 338.0], [78.6, 339.0], [78.7, 339.0], [78.8, 340.0], [78.9, 340.0], [79.0, 341.0], [79.1, 341.0], [79.2, 342.0], [79.3, 343.0], [79.4, 343.0], [79.5, 344.0], [79.6, 344.0], [79.7, 345.0], [79.8, 346.0], [79.9, 346.0], [80.0, 347.0], [80.1, 348.0], [80.2, 348.0], [80.3, 349.0], [80.4, 349.0], [80.5, 350.0], [80.6, 351.0], [80.7, 351.0], [80.8, 352.0], [80.9, 353.0], [81.0, 353.0], [81.1, 354.0], [81.2, 354.0], [81.3, 355.0], [81.4, 356.0], [81.5, 356.0], [81.6, 357.0], [81.7, 358.0], [81.8, 358.0], [81.9, 359.0], [82.0, 360.0], [82.1, 360.0], [82.2, 361.0], [82.3, 362.0], [82.4, 362.0], [82.5, 363.0], [82.6, 364.0], [82.7, 364.0], [82.8, 365.0], [82.9, 366.0], [83.0, 366.0], [83.1, 367.0], [83.2, 368.0], [83.3, 369.0], [83.4, 369.0], [83.5, 370.0], [83.6, 371.0], [83.7, 371.0], [83.8, 372.0], [83.9, 373.0], [84.0, 374.0], [84.1, 374.0], [84.2, 375.0], [84.3, 376.0], [84.4, 377.0], [84.5, 377.0], [84.6, 378.0], [84.7, 379.0], [84.8, 380.0], [84.9, 380.0], [85.0, 381.0], [85.1, 382.0], [85.2, 383.0], [85.3, 384.0], [85.4, 384.0], [85.5, 385.0], [85.6, 386.0], [85.7, 387.0], [85.8, 388.0], [85.9, 388.0], [86.0, 389.0], [86.1, 390.0], [86.2, 391.0], [86.3, 392.0], [86.4, 393.0], [86.5, 394.0], [86.6, 394.0], [86.7, 395.0], [86.8, 396.0], [86.9, 397.0], [87.0, 398.0], [87.1, 399.0], [87.2, 400.0], [87.3, 400.0], [87.4, 401.0], [87.5, 402.0], [87.6, 403.0], [87.7, 404.0], [87.8, 405.0], [87.9, 406.0], [88.0, 407.0], [88.1, 408.0], [88.2, 409.0], [88.3, 410.0], [88.4, 411.0], [88.5, 412.0], [88.6, 413.0], [88.7, 414.0], [88.8, 415.0], [88.9, 416.0], [89.0, 417.0], [89.1, 418.0], [89.2, 419.0], [89.3, 420.0], [89.4, 421.0], [89.5, 422.0], [89.6, 423.0], [89.7, 424.0], [89.8, 425.0], [89.9, 426.0], [90.0, 427.0], [90.1, 428.0], [90.2, 429.0], [90.3, 430.0], [90.4, 431.0], [90.5, 433.0], [90.6, 434.0], [90.7, 435.0], [90.8, 436.0], [90.9, 437.0], [91.0, 439.0], [91.1, 440.0], [91.2, 441.0], [91.3, 442.0], [91.4, 443.0], [91.5, 445.0], [91.6, 446.0], [91.7, 447.0], [91.8, 448.0], [91.9, 450.0], [92.0, 451.0], [92.1, 452.0], [92.2, 454.0], [92.3, 455.0], [92.4, 456.0], [92.5, 458.0], [92.6, 459.0], [92.7, 461.0], [92.8, 462.0], [92.9, 464.0], [93.0, 465.0], [93.1, 467.0], [93.2, 468.0], [93.3, 470.0], [93.4, 471.0], [93.5, 473.0], [93.6, 475.0], [93.7, 477.0], [93.8, 478.0], [93.9, 480.0], [94.0, 482.0], [94.1, 484.0], [94.2, 485.0], [94.3, 487.0], [94.4, 489.0], [94.5, 491.0], [94.6, 493.0], [94.7, 495.0], [94.8, 497.0], [94.9, 499.0], [95.0, 502.0], [95.1, 504.0], [95.2, 506.0], [95.3, 508.0], [95.4, 511.0], [95.5, 513.0], [95.6, 516.0], [95.7, 518.0], [95.8, 521.0], [95.9, 524.0], [96.0, 526.0], [96.1, 529.0], [96.2, 532.0], [96.3, 535.0], [96.4, 538.0], [96.5, 541.0], [96.6, 544.0], [96.7, 548.0], [96.8, 551.0], [96.9, 555.0], [97.0, 558.0], [97.1, 562.0], [97.2, 566.0], [97.3, 570.0], [97.4, 574.0], [97.5, 578.0], [97.6, 582.0], [97.7, 587.0], [97.8, 591.0], [97.9, 596.0], [98.0, 601.0], [98.1, 606.0], [98.2, 612.0], [98.3, 618.0], [98.4, 624.0], [98.5, 631.0], [98.6, 637.0], [98.7, 644.0], [98.8, 652.0], [98.9, 660.0], [99.0, 670.0], [99.1, 680.0], [99.2, 692.0], [99.3, 705.0], [99.4, 718.0], [99.5, 734.0], [99.6, 756.0], [99.7, 784.0], [99.8, 832.0], [99.9, 927.0], [100.0, 10134.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 258.0, "minX": 0.0, "maxY": 996455.0, "series": [{"data": [[0.0, 996455.0], [10000.0, 415.0], [500.0, 52872.0], [1000.0, 258.0]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 500, "maxX": 10000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 415.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 996963.0, "series": [{"data": [[1.0, 52622.0]], "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[3.0, 415.0]], "isOverall": false, "label": "Requests in error", "isController": false}, {"data": [[0.0, 996963.0]], "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 110.92076530612269, "minX": 1.4938065E12, "maxY": 700.0, "series": [{"data": [[1.4938068E12, 700.0], [1.4938065E12, 110.92076530612269], [1.49380668E12, 700.0], [1.49380686E12, 658.0020538243567], [1.49380656E12, 509.26893306127954], [1.49380674E12, 700.0], [1.49380692E12, 428.03425720448894], [1.49380662E12, 700.0]], "isOverall": false, "label": "性能测试", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380692E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 48.897058823529434, "minX": 1.0, "maxY": 451.3836431226762, "series": [{"data": [[2.0, 54.416666666666664], [3.0, 55.0], [4.0, 53.125], [5.0, 53.0], [6.0, 53.0], [7.0, 51.69230769230769], [8.0, 50.4], [9.0, 52.0], [10.0, 52.625], [11.0, 150.24999999999997], [12.0, 53.42857142857143], [13.0, 54.11111111111113], [14.0, 54.91428571428571], [15.0, 52.218181818181826], [16.0, 54.666666666666664], [17.0, 53.166666666666664], [18.0, 52.02222222222221], [19.0, 52.70588235294117], [20.0, 53.19642857142857], [21.0, 52.35897435897436], [22.0, 51.59210526315788], [23.0, 51.16666666666667], [24.0, 51.844444444444456], [25.0, 52.021276595744695], [26.0, 50.63999999999999], [27.0, 51.303571428571445], [28.0, 51.04999999999999], [29.0, 51.85714285714287], [30.0, 51.47826086956521], [31.0, 50.67164179104478], [32.0, 51.65346534653465], [33.0, 51.81250000000002], [34.0, 49.876404494382015], [35.0, 52.379310344827594], [36.0, 52.522727272727266], [37.0, 51.067164179104495], [38.0, 52.00892857142858], [39.0, 50.39705882352941], [40.0, 51.38202247191012], [41.0, 52.831325301204814], [42.0, 49.21256038647345], [43.0, 51.81318681318682], [44.0, 51.61077844311378], [45.0, 54.013698630137], [46.0, 51.90131578947368], [47.0, 51.17880794701987], [48.0, 51.69072164948452], [49.0, 49.50961538461538], [50.0, 50.896551724137915], [51.0, 51.166666666666664], [52.0, 51.50617283950616], [53.0, 48.897058823529434], [54.0, 52.15384615384616], [55.0, 51.52941176470589], [56.0, 51.382978723404264], [57.0, 53.62371134020618], [58.0, 52.008547008547005], [59.0, 51.318385650224215], [60.0, 115.48214285714286], [61.0, 82.71199999999996], [62.0, 55.81739130434782], [63.0, 54.8148148148148], [64.0, 52.492647058823536], [65.0, 50.535031847133766], [66.0, 54.73684210526315], [67.0, 65.21649484536084], [68.0, 55.02673796791444], [69.0, 53.14615384615386], [70.0, 50.20472440944882], [71.0, 55.403100775193785], [72.0, 53.35344827586205], [73.0, 55.31034482758622], [74.0, 53.147208121827425], [75.0, 54.651898734177216], [76.0, 57.6923076923077], [77.0, 53.13380281690141], [78.0, 63.11926605504584], [79.0, 55.52755905511811], [80.0, 54.96610169491526], [81.0, 61.289940828402365], [82.0, 52.72], [83.0, 59.59541984732824], [84.0, 67.39285714285712], [85.0, 62.38764044943823], [86.0, 61.60176991150444], [87.0, 58.00865800865799], [88.0, 53.253807106599005], [89.0, 55.36111111111108], [90.0, 51.559210526315766], [91.0, 54.426035502958584], [92.0, 53.16556291390727], [93.0, 52.049450549450555], [94.0, 55.864], [95.0, 58.95294117647057], [96.0, 60.57718120805368], [97.0, 67.575], [98.0, 56.2769953051643], [99.0, 54.993630573248396], [100.0, 58.37500000000001], [101.0, 90.37820512820512], [102.0, 59.158075601374556], [103.0, 51.94308943089433], [104.0, 57.074829931972786], [105.0, 63.25000000000002], [106.0, 64.5839416058394], [107.0, 57.943005181347125], [108.0, 55.53142857142856], [109.0, 63.741935483871], [110.0, 56.89690721649484], [111.0, 65.78518518518514], [112.0, 70.29268292682929], [113.0, 56.59999999999998], [114.0, 58.53731343283582], [115.0, 58.03333333333331], [116.0, 54.47783251231526], [117.0, 53.304182509505715], [118.0, 58.81262327416171], [119.0, 62.99999999999997], [120.0, 61.24712643678161], [121.0, 60.193548387096776], [122.0, 61.53242320819116], [123.0, 53.4285714285714], [124.0, 55.65536723163843], [125.0, 66.27380952380952], [126.0, 66.74458874458871], [127.0, 64.25000000000001], [128.0, 56.98832684824902], [129.0, 74.3392857142857], [130.0, 100.67867036011084], [135.0, 58.390243902439], [134.0, 60.72], [133.0, 60.53846153846153], [132.0, 56.28571428571428], [131.0, 54.35798816568049], [136.0, 362.1612903225807], [137.0, 248.6808510638299], [138.0, 71.63235294117645], [139.0, 62.25], [140.0, 81.68235294117646], [141.0, 79.20198675496692], [142.0, 72.96456692913384], [143.0, 61.003861003861026], [144.0, 64.14977973568283], [145.0, 70.08906882591093], [146.0, 63.987603305785164], [147.0, 62.62931034482757], [148.0, 67.79670329670333], [149.0, 68.5185185185185], [150.0, 60.39459459459457], [151.0, 68.27311827956991], [152.0, 82.34782608695657], [153.0, 93.75555555555555], [154.0, 94.36111111111109], [155.0, 88.74311926605499], [156.0, 77.64672364672367], [157.0, 90.0776699029126], [158.0, 87.15139442231077], [159.0, 87.99004975124375], [160.0, 73.75555555555555], [161.0, 74.7797833935018], [162.0, 84.22631578947369], [163.0, 103.91406249999999], [164.0, 133.20833333333334], [165.0, 80.42599277978341], [166.0, 78.01843317972352], [167.0, 82.35057471264369], [168.0, 91.3954545454546], [169.0, 74.4744744744745], [170.0, 66.469696969697], [171.0, 79.31658291457288], [172.0, 70.87853107344631], [173.0, 76.95061728395062], [174.0, 84.20833333333336], [175.0, 96.54644808743174], [176.0, 86.91037735849054], [177.0, 93.63243243243242], [178.0, 93.54189944134079], [179.0, 90.42483660130715], [180.0, 91.71491228070177], [181.0, 65.96761133603242], [182.0, 68.25816993464049], [183.0, 67.8716577540107], [184.0, 63.98083067092652], [185.0, 74.74489795918376], [186.0, 80.69599999999998], [187.0, 74.52892561983474], [188.0, 74.22832369942195], [189.0, 66.1382113821138], [190.0, 121.40552995391707], [191.0, 83.41702127659575], [192.0, 77.84210526315785], [193.0, 79.75000000000003], [194.0, 110.49732620320857], [195.0, 97.32663316582912], [196.0, 100.68939393939394], [197.0, 98.11377245508989], [198.0, 90.12546125461259], [199.0, 87.18050541516249], [200.0, 108.35937499999997], [201.0, 99.39416058394157], [202.0, 150.83333333333323], [203.0, 97.4770114942529], [204.0, 90.1420664206642], [205.0, 76.5622119815668], [206.0, 80.29569892473128], [207.0, 76.36079545454548], [208.0, 79.52602739726034], [209.0, 78.39851485148516], [210.0, 69.46808510638293], [211.0, 69.52430555555551], [212.0, 75.56495468277953], [213.0, 74.48571428571437], [214.0, 71.50125628140707], [215.0, 127.35521235521237], [216.0, 84.82031249999994], [217.0, 88.69072164948449], [218.0, 81.1327231121281], [219.0, 79.49557522123888], [220.0, 88.15358361774746], [221.0, 92.40972222222224], [222.0, 74.47019867549669], [223.0, 74.32295719844363], [224.0, 86.30851063829783], [225.0, 95.13300492610833], [226.0, 94.84246575342462], [227.0, 78.37463126843659], [228.0, 74.56372549019603], [229.0, 77.87410926365791], [230.0, 69.61818181818185], [231.0, 86.1326815642458], [232.0, 85.75543478260867], [233.0, 96.8338461538462], [234.0, 100.21454545454547], [235.0, 131.3676470588235], [236.0, 103.91176470588229], [237.0, 85.98039215686273], [238.0, 93.0390624999999], [239.0, 100.71960784313727], [240.0, 106.85053380782918], [241.0, 100.10169491525423], [242.0, 84.4320712694877], [243.0, 84.62499999999997], [244.0, 85.74708171206221], [245.0, 92.25384615384607], [246.0, 89.74375000000002], [247.0, 78.66403162055337], [248.0, 94.07633587786259], [249.0, 91.06960556844543], [250.0, 79.33084112149541], [251.0, 80.92519685039368], [252.0, 92.27881040892187], [253.0, 85.11256544502614], [254.0, 100.52016129032258], [255.0, 99.55755395683457], [257.0, 131.66921119592877], [256.0, 157.6486486486488], [258.0, 106.28729281767963], [259.0, 108.94736842105273], [260.0, 111.38095238095235], [261.0, 138.52340425531906], [262.0, 138.83333333333323], [263.0, 131.81249999999997], [264.0, 122.35463258785946], [270.0, 99.91964285714288], [271.0, 124.7093023255814], [268.0, 126.78734177215193], [269.0, 102.57356608478813], [265.0, 118.2536115569824], [266.0, 118.7733333333333], [267.0, 135.31764705882344], [273.0, 115.61181434599162], [272.0, 178.7854251012145], [274.0, 114.66767371601213], [275.0, 104.86641221374045], [276.0, 100.57432432432437], [277.0, 120.83417085427138], [278.0, 116.09937888198759], [279.0, 125.02898550724633], [280.0, 111.16300940438872], [286.0, 119.71903881700544], [287.0, 144.81362007168462], [284.0, 108.54405286343614], [285.0, 111.18457300275493], [281.0, 111.39999999999995], [282.0, 144.95370370370378], [283.0, 114.09821428571438], [289.0, 124.0051150895141], [288.0, 134.68674698795184], [290.0, 166.81443298969057], [291.0, 137.34530386740312], [292.0, 128.91538461538457], [293.0, 132.78544061302682], [294.0, 123.14999999999999], [295.0, 139.33053221288512], [296.0, 140.67407407407404], [302.0, 137.81690140845063], [303.0, 124.55416666666676], [300.0, 88.17081850533805], [301.0, 113.29687500000001], [297.0, 103.12853470437022], [298.0, 94.45695364238418], [299.0, 137.3680203045684], [305.0, 131.84740259740252], [304.0, 137.70319634703205], [306.0, 152.89090909090905], [307.0, 95.49295774647888], [308.0, 99.4980079681275], [309.0, 111.85576923076918], [310.0, 104.44186046511633], [311.0, 93.67796610169488], [312.0, 119.90517241379308], [318.0, 123.13008130081306], [319.0, 125.87775061124687], [316.0, 124.99615384615385], [317.0, 119.68307692307691], [313.0, 105.12233285917497], [314.0, 159.8458149779735], [315.0, 147.14622641509445], [321.0, 119.2965517241379], [320.0, 122.65217391304343], [322.0, 112.07850467289718], [323.0, 115.53642384105966], [324.0, 122.26229508196725], [325.0, 151.57851239669412], [326.0, 102.01094890510956], [327.0, 126.09278350515464], [328.0, 183.96610169491527], [334.0, 128.04248366013073], [335.0, 139.54658385093177], [332.0, 131.39454094292796], [333.0, 149.9666666666667], [329.0, 151.48608137044968], [330.0, 103.57303370786524], [331.0, 103.49354838709681], [337.0, 126.80877742946713], [336.0, 124.83475783475784], [338.0, 138.62593984962396], [339.0, 105.82831325301204], [340.0, 131.5726141078839], [341.0, 143.98694516971275], [342.0, 114.26141078838172], [343.0, 121.58448060075106], [344.0, 109.04193548387101], [350.0, 112.19666048237484], [351.0, 105.57468354430381], [348.0, 176.64248704663225], [349.0, 113.12136752136757], [345.0, 120.50779510022272], [346.0, 100.71108343711083], [347.0, 120.06686046511614], [353.0, 99.53647058823523], [352.0, 106.53191489361713], [354.0, 107.353057199211], [355.0, 124.83105022831049], [356.0, 134.38914027149332], [357.0, 138.94999999999996], [358.0, 127.49029126213593], [359.0, 145.9297520661156], [360.0, 132.91666666666663], [366.0, 168.95665171898347], [367.0, 163.01047120418855], [364.0, 128.70033112582774], [365.0, 139.48192771084345], [361.0, 118.9770833333333], [362.0, 131.61487603305793], [363.0, 139.20441988950284], [369.0, 169.1727019498606], [368.0, 161.71597633136088], [370.0, 204.1800947867298], [371.0, 162.57999999999993], [372.0, 136.18060200668887], [373.0, 130.48943661971828], [374.0, 188.32265446224244], [375.0, 178.25185185185185], [376.0, 161.2222222222224], [382.0, 167.7301829268293], [383.0, 140.0734557595992], [380.0, 139.78846153846155], [381.0, 157.84900284900294], [377.0, 148.23939393939398], [378.0, 148.16559139784945], [379.0, 138.60160965794782], [385.0, 159.0245746691872], [384.0, 151.4390651085142], [386.0, 179.3678391959797], [387.0, 151.63414634146355], [388.0, 139.4381270903008], [389.0, 147.74897959183687], [390.0, 167.92307692307693], [391.0, 202.55405405405392], [392.0, 207.05936073059362], [398.0, 153.79530916844354], [399.0, 166.6], [396.0, 141.98452012383888], [397.0, 161.04728132387717], [393.0, 162.205035971223], [394.0, 146.6960985626283], [395.0, 138.7752808988764], [401.0, 157.00722891566264], [400.0, 158.44594594594597], [402.0, 132.1508196721312], [403.0, 119.39612188365646], [404.0, 138.89232839838485], [405.0, 172.40145985401452], [406.0, 237.27014218009467], [407.0, 240.39189189189202], [408.0, 188.84637268847803], [414.0, 159.14035087719307], [415.0, 203.23829787234047], [412.0, 205.76041666666654], [413.0, 122.31292517006803], [409.0, 165.61538461538441], [410.0, 152.21146953405017], [411.0, 198.0901639344263], [417.0, 139.7673130193906], [416.0, 154.78554502369659], [418.0, 127.09876543209877], [419.0, 152.59392789373803], [420.0, 187.36718749999994], [421.0, 165.73717948717953], [422.0, 145.17653758542113], [423.0, 137.85605536332193], [424.0, 208.0402160864344], [430.0, 163.00280898876417], [431.0, 161.28137931034485], [428.0, 158.25157232704407], [429.0, 205.33815028901725], [425.0, 138.60975609756085], [426.0, 169.6365461847388], [427.0, 156.59674134419544], [433.0, 152.36486486486493], [432.0, 187.71671826625382], [434.0, 182.76684881602907], [435.0, 143.94059405940584], [436.0, 131.76288659793823], [437.0, 240.93305439330544], [438.0, 215.3234265734263], [439.0, 156.42391304347848], [440.0, 179.2827102803739], [446.0, 145.92469879518092], [447.0, 149.15966386554638], [444.0, 149.84253819036442], [445.0, 157.31751227495906], [441.0, 188.21701112877554], [442.0, 180.94311624072571], [443.0, 197.77838427947586], [449.0, 136.72760511883007], [448.0, 134.20111731843588], [450.0, 141.0131578947369], [451.0, 142.23752495010004], [452.0, 166.75510204081635], [453.0, 177.48571428571424], [454.0, 164.7801204819276], [455.0, 183.03629764065332], [456.0, 161.5762711864408], [462.0, 248.94754653130283], [463.0, 150.46984126984114], [460.0, 162.03007518796986], [461.0, 156.26888217522645], [457.0, 187.32598039215682], [458.0, 145.4963503649634], [459.0, 186.93144208037825], [465.0, 154.94843750000015], [464.0, 164.28990825688075], [466.0, 142.8009868421051], [467.0, 138.17549668874156], [468.0, 156.42647058823508], [469.0, 191.71804511278205], [470.0, 179.84883720930233], [471.0, 176.44836956521743], [472.0, 182.53498871331826], [478.0, 225.8653846153845], [479.0, 243.40716612377824], [476.0, 185.17377398720689], [477.0, 152.69421487603302], [473.0, 170.03440702781836], [474.0, 184.78084714548802], [475.0, 179.04287901990807], [481.0, 259.92277992278014], [480.0, 184.1102564102569], [482.0, 252.87964601769917], [483.0, 211.04639543183444], [484.0, 204.45146726862302], [485.0, 162.01768172888004], [486.0, 199.12647058823526], [487.0, 182.53764320785592], [488.0, 172.4938689217763], [494.0, 200.18874172185426], [495.0, 179.87698412698413], [492.0, 217.42977190876374], [493.0, 177.54865424430662], [489.0, 209.71874999999997], [490.0, 163.04536222071755], [491.0, 155.98338870431886], [497.0, 175.95652173913052], [496.0, 172.97922848664695], [498.0, 169.36752136752142], [499.0, 202.40919158360998], [500.0, 231.64613526570034], [501.0, 180.8075144508668], [502.0, 182.24999999999994], [503.0, 188.75620767494362], [504.0, 200.19811320754715], [510.0, 307.45563549160687], [511.0, 193.05099502487553], [508.0, 244.96462264150946], [509.0, 294.97297297297297], [505.0, 236.73333333333335], [506.0, 344.26888888888925], [507.0, 273.92400000000004], [515.0, 198.00700934579436], [512.0, 205.00631199278632], [526.0, 222.59983291562233], [527.0, 189.52682926829263], [524.0, 297.72118959107814], [525.0, 211.31274131274134], [522.0, 210.8106796116505], [523.0, 247.74812593703132], [513.0, 196.05882352941143], [514.0, 180.9400921658984], [516.0, 244.56074766355127], [517.0, 181.52705882352947], [518.0, 181.73807721423157], [519.0, 230.6151761517615], [528.0, 201.22395023328158], [542.0, 176.13709677419357], [543.0, 170.75000000000003], [540.0, 182.40268456375844], [541.0, 191.6212361331221], [538.0, 220.26947368421077], [539.0, 199.6625874125876], [536.0, 206.37070254110589], [537.0, 215.4808510638298], [529.0, 218.90992647058832], [530.0, 209.06091370558357], [531.0, 179.93791574279388], [532.0, 173.5622119815668], [533.0, 208.16434540389974], [534.0, 194.87425149700613], [535.0, 217.85506329113934], [520.0, 183.27225130890048], [521.0, 185.6998706338939], [547.0, 207.043165467626], [544.0, 200.2245810055865], [558.0, 201.51063829787242], [559.0, 252.5613079019074], [556.0, 185.0989795918367], [557.0, 199.75379310344826], [554.0, 183.68067226890773], [555.0, 189.90791366906487], [545.0, 243.9637826961771], [546.0, 228.57639524245195], [548.0, 213.4618745035739], [549.0, 248.95305164319254], [550.0, 317.557133198107], [551.0, 238.30470347648262], [560.0, 240.92046396023227], [574.0, 248.08180839612467], [575.0, 270.33694474539533], [572.0, 201.79922135706352], [573.0, 223.1594252480326], [570.0, 165.21971830985925], [571.0, 199.8803149606299], [568.0, 205.72984749455344], [569.0, 185.2434325744307], [561.0, 176.93592365371515], [562.0, 155.01375515818413], [563.0, 199.0552268244575], [564.0, 226.5093099671414], [565.0, 277.23489932885946], [566.0, 257.5265888456549], [567.0, 451.3836431226762], [552.0, 186.89406779661016], [553.0, 167.76779026217227], [579.0, 242.55460122699392], [576.0, 246.82300884955757], [590.0, 185.63534136546207], [591.0, 188.23714759535662], [588.0, 225.23282442748092], [589.0, 201.4467640918579], [586.0, 245.42911877394613], [587.0, 262.6007067137809], [577.0, 269.3302521008405], [578.0, 242.67318982387474], [580.0, 243.35227272727266], [581.0, 180.71990171990157], [582.0, 234.4406332453825], [583.0, 261.32191780821915], [592.0, 223.1616161616162], [606.0, 310.9627906976743], [607.0, 244.57861635220132], [604.0, 308.4984984984987], [605.0, 244.7586568730327], [602.0, 231.73582089552258], [603.0, 324.39007092198625], [600.0, 242.13852242744073], [601.0, 219.80981595092013], [593.0, 216.22643818849448], [594.0, 190.23428571428576], [595.0, 155.1071428571429], [596.0, 257.86608961303483], [597.0, 217.99765807962538], [598.0, 291.8651980068194], [599.0, 260.1437768240345], [584.0, 262.0690235690232], [585.0, 303.26382978723365], [611.0, 334.21979286536236], [608.0, 280.5267993874426], [622.0, 282.8117306299777], [623.0, 255.66108786610891], [620.0, 199.10471204188482], [621.0, 218.6512907321203], [618.0, 224.8060836501902], [619.0, 204.4350590372387], [609.0, 283.1899736147755], [610.0, 317.7859007832897], [612.0, 229.75816122584928], [613.0, 244.572144288577], [614.0, 287.6618705035971], [615.0, 205.54086538461524], [624.0, 255.73705722070875], [638.0, 221.62415654520933], [639.0, 239.645685997171], [636.0, 253.2781629116116], [637.0, 213.51846073842967], [634.0, 256.1373172282264], [635.0, 211.08833376255447], [632.0, 234.24497991967866], [633.0, 211.56], [625.0, 262.24324324324317], [626.0, 287.44428772919593], [627.0, 213.40534979423876], [628.0, 196.56114483954875], [629.0, 229.3886861313869], [630.0, 247.59107806691452], [631.0, 321.2536254242513], [616.0, 272.9610256410254], [617.0, 258.14094775212595], [643.0, 266.8514851485147], [640.0, 233.23246217331499], [654.0, 194.20717131474112], [655.0, 261.79507475813546], [652.0, 316.51613965744406], [653.0, 258.59108061749555], [650.0, 269.9121863799281], [651.0, 263.30020283975637], [641.0, 248.5117707267144], [642.0, 236.2410256410254], [644.0, 265.9704910812599], [645.0, 232.2720125786163], [646.0, 188.86956521739106], [647.0, 250.54375], [656.0, 271.0018814675445], [670.0, 202.37415730337082], [671.0, 236.26636568848744], [668.0, 251.6238381629301], [669.0, 218.79099328127816], [666.0, 259.9042632759909], [667.0, 255.97335423197526], [664.0, 212.49713818479157], [665.0, 229.15020576131707], [657.0, 252.39431486880497], [658.0, 226.0555555555558], [659.0, 301.1837581505634], [660.0, 250.90787518573546], [661.0, 268.87590361445774], [662.0, 316.5362678239305], [663.0, 206.95735607675897], [648.0, 190.07750631844982], [649.0, 207.53374233128835], [675.0, 215.2149425287357], [672.0, 276.814516129032], [686.0, 195.3572984749454], [687.0, 215.14634146341456], [684.0, 235.53910721098816], [685.0, 260.58233890214814], [682.0, 261.67515923566907], [683.0, 334.6726726726728], [673.0, 252.57565789473693], [674.0, 215.07672849915707], [676.0, 228.48361423221], [677.0, 227.37585705381258], [678.0, 231.4509925558314], [679.0, 318.576011157601], [688.0, 216.0468497576737], [699.0, 261.1385823429544], [700.0, 281.37348845928096], [696.0, 306.0195986934199], [697.0, 240.15675116399373], [698.0, 352.05096418732825], [689.0, 224.42234332425068], [690.0, 252.31483457844186], [691.0, 245.87685843568187], [692.0, 244.6385041551248], [693.0, 214.34305012442206], [694.0, 260.9999999999996], [695.0, 248.40162746627908], [680.0, 319.89062499999983], [681.0, 259.43262411347513], [1.0, 52.90740740740741]], "isOverall": false, "label": "HTTP请求", "isController": false}, {"data": [[621.8121209523787, 248.5260780952437]], "isOverall": false, "label": "HTTP请求-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 700.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 72846.66666666667, "minX": 1.4938065E12, "maxY": 1704327.8166666667, "series": [{"data": [[1.4938068E12, 1704327.8166666667], [1.4938065E12, 214620.0], [1.49380668E12, 1597235.45], [1.49380686E12, 1703736.0833333333], [1.49380656E12, 1664019.4166666667], [1.49380674E12, 1570542.8], [1.49380692E12, 1411354.4333333333], [1.49380662E12, 1646223.5833333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.4938068E12, 577001.35], [1.4938065E12, 72846.66666666667], [1.49380668E12, 540355.0166666667], [1.49380686E12, 576956.75], [1.49380656E12, 564632.2833333333], [1.49380674E12, 532419.9333333333], [1.49380692E12, 478981.7], [1.49380662E12, 557763.8833333333]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380692E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 69.28535714285746, "minX": 1.4938065E12, "maxY": 291.90350607841197, "series": [{"data": [[1.4938068E12, 270.8157227279181], [1.4938065E12, 69.28535714285746], [1.49380668E12, 288.7123456196187], [1.49380686E12, 254.38824362606493], [1.49380656E12, 198.08992957282922], [1.49380674E12, 291.90350607841197], [1.49380692E12, 172.45918620710827], [1.49380662E12, 278.7877377027373]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380692E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 69.27780612244881, "minX": 1.4938065E12, "maxY": 288.96590924951823, "series": [{"data": [[1.4938068E12, 264.68824915348216], [1.4938065E12, 69.27780612244881], [1.49380668E12, 280.86424148287205], [1.49380686E12, 248.90552407931924], [1.49380656E12, 197.3614822615694], [1.49380674E12, 288.96590924951823], [1.49380692E12, 172.14500535390215], [1.49380662E12, 274.5152096446529]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380692E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.3262620462763247, "minX": 1.4938065E12, "maxY": 0.8046246346770335, "series": [{"data": [[1.4938068E12, 0.8046246346770335], [1.4938065E12, 0.7270408163265356], [1.49380668E12, 0.7717885100446036], [1.49380686E12, 0.7555498326036573], [1.49380656E12, 0.44451392088461245], [1.49380674E12, 0.717880720755922], [1.49380692E12, 0.3262620462763247], [1.49380662E12, 0.7493389282978706]], "isOverall": false, "label": "HTTP请求", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380692E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 7.0, "minX": 1.4938065E12, "maxY": 1228.0, "series": [{"data": [[1.4938068E12, 964.0], [1.4938065E12, 614.0], [1.49380668E12, 970.0], [1.49380686E12, 837.0], [1.49380656E12, 1226.0], [1.49380674E12, 1126.0], [1.49380692E12, 1039.0], [1.49380662E12, 1228.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.4938068E12, 27.0], [1.4938065E12, 7.0], [1.49380668E12, 29.0], [1.49380686E12, 29.0], [1.49380656E12, 26.0], [1.49380674E12, 26.0], [1.49380692E12, 26.0], [1.49380662E12, 27.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.4938068E12, 480.0], [1.4938065E12, 98.0], [1.49380668E12, 530.0], [1.49380686E12, 414.0], [1.49380656E12, 432.0], [1.49380674E12, 470.0], [1.49380692E12, 134.0], [1.49380662E12, 418.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.4938068E12, 639.0], [1.4938065E12, 186.0], [1.49380668E12, 692.9900000000016], [1.49380686E12, 671.0], [1.49380656E12, 617.0], [1.49380674E12, 621.0], [1.49380692E12, 217.0], [1.49380662E12, 619.9900000000016]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.4938068E12, 548.0], [1.4938065E12, 120.0], [1.49380668E12, 591.0], [1.49380686E12, 490.0], [1.49380656E12, 489.0], [1.49380674E12, 530.0], [1.49380692E12, 162.0], [1.49380662E12, 497.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380692E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 58.0, "minX": 8878.0, "maxY": 10010.5, "series": [{"data": [[35342.0, 265.0], [35320.0, 234.0], [8878.0, 70.0], [19600.0, 58.0], [23294.0, 277.0], [25501.0, 277.0], [30135.0, 233.0], [31930.0, 249.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[35342.0, 10010.0], [35320.0, 10010.0], [8878.0, 10010.5], [23294.0, 10010.0], [25501.0, 10010.0], [30135.0, 10010.0], [31930.0, 10010.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 35342.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 8878.0, "maxY": 277.0, "series": [{"data": [[35342.0, 265.0], [35320.0, 234.0], [8878.0, 70.0], [19600.0, 58.0], [23294.0, 277.0], [25501.0, 277.0], [30135.0, 233.0], [31930.0, 249.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[35342.0, 0.0], [35320.0, 0.0], [8878.0, 0.0], [23294.0, 0.0], [25501.0, 0.0], [30135.0, 0.0], [31930.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 35342.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency (ms)",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 329.6166666666667, "minX": 1.4938065E12, "maxY": 2589.0333333333333, "series": [{"data": [[1.4938068E12, 2589.0333333333333], [1.4938065E12, 329.6166666666667], [1.49380668E12, 2425.0333333333333], [1.49380686E12, 2586.6666666666665], [1.49380656E12, 2540.883333333333], [1.49380674E12, 2388.233333333333], [1.49380692E12, 2138.3], [1.49380662E12, 2502.233333333333]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380692E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.06666666666666667, "minX": 1.4938065E12, "maxY": 2587.45, "series": [{"data": [[1.4938068E12, 2587.45], [1.4938065E12, 326.6666666666667], [1.49380668E12, 2423.116666666667], [1.49380686E12, 2587.25], [1.49380656E12, 2531.983333333333], [1.49380674E12, 2387.5333333333333], [1.49380692E12, 2147.9], [1.49380662E12, 2501.1833333333334]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.4938068E12, 1.5833333333333333], [1.49380668E12, 1.9], [1.49380686E12, 1.4166666666666667], [1.49380656E12, 0.18333333333333332], [1.49380674E12, 0.7], [1.49380692E12, 0.06666666666666667], [1.49380662E12, 1.0666666666666667]], "isOverall": false, "label": "Non HTTP response code: java.net.SocketTimeoutException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.49380692E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses/sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.06666666666666667, "minX": 1.4938065E12, "maxY": 2587.45, "series": [{"data": [[1.4938068E12, 1.5833333333333333], [1.49380668E12, 1.9], [1.49380686E12, 1.4166666666666667], [1.49380656E12, 0.18333333333333332], [1.49380674E12, 0.7], [1.49380692E12, 0.06666666666666667], [1.49380662E12, 1.0666666666666667]], "isOverall": false, "label": "HTTP请求-failure", "isController": false}, {"data": [[1.4938068E12, 2587.45], [1.4938065E12, 326.6666666666667], [1.49380668E12, 2423.116666666667], [1.49380686E12, 2587.25], [1.49380656E12, 2531.983333333333], [1.49380674E12, 2387.5333333333333], [1.49380692E12, 2147.9], [1.49380662E12, 2501.1833333333334]], "isOverall": false, "label": "HTTP请求-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.49380692E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
